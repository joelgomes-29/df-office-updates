Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Get-DashboardRoot {
  return (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot "..")).Path
}

function Get-DashboardConfig {
  param([string]$Root)
  $configPath = Join-Path $Root "config.json"
  if (-not (Test-Path -LiteralPath $configPath)) {
    Copy-Item -LiteralPath (Join-Path $Root "config.example.json") -Destination $configPath
  }
  return Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
}

function Get-DashboardNode {
  param([string]$Root)
  $bundled = Join-Path $Root "runtime\node.exe"
  if (Test-Path -LiteralPath $bundled) { return $bundled }
  $systemNode = Get-Command node.exe -ErrorAction SilentlyContinue
  if ($null -ne $systemNode) { return $systemNode.Source }
  throw "O runtime do aplicativo não foi encontrado. Extraia novamente o pacote completo."
}

function Get-LocalIpv4 {
  $addresses = [System.Net.NetworkInformation.NetworkInterface]::GetAllNetworkInterfaces() |
    Where-Object { $_.OperationalStatus -eq "Up" -and $_.NetworkInterfaceType -ne "Loopback" } |
    ForEach-Object { $_.GetIPProperties().UnicastAddresses } |
    Where-Object { $_.Address.AddressFamily -eq [System.Net.Sockets.AddressFamily]::InterNetwork } |
    ForEach-Object { $_.Address.IPAddressToString } |
    Where-Object { $_ -notlike "169.254.*" }
  return @($addresses | Select-Object -Unique)
}

function Open-DashboardApp {
  param([string]$Url)
  $edgeCandidates = @(@(
    (Join-Path ${env:ProgramFiles(x86)} "Microsoft\Edge\Application\msedge.exe"),
    (Join-Path $env:ProgramFiles "Microsoft\Edge\Application\msedge.exe")
  ) | Where-Object { $_ -and (Test-Path -LiteralPath $_) })
  if ($edgeCandidates.Count -gt 0) {
    Start-Process -FilePath $edgeCandidates[0] -ArgumentList "--app=$Url", "--start-maximized"
  } else {
    Start-Process $Url
  }
}
