# Dashboard Fiscal Office — versão portátil para escritório contábil

Aplicativo multiusuário para Windows que funciona na rede interna do escritório. Um computador fica como **servidor central** e os demais acessam por um atalho próprio, com aparência de aplicativo. Não exige Google Apps Script, conta Google ou instalação prévia do Node.js.

## O que esta versão entrega

- primeiro acesso sem senha padrão: o escritório cria seu próprio administrador;
- acesso validado por setor, usuário e senha, com identidades `DP OFFICE`, `FISCAL/CONTABIL OFFICE`, `GESTAO OFFICE` e `DF OFFICE`;
- permissões automáticas por setor: DP e Fiscal/Contábil como colaboradores, Gestão como gestor e Admin como administrador;
- cadastro de clientes com CNPJ, I.E., I.M., CPF do responsável, Código Domínio, cidade, atividade e regime tributário;
- carga inicial automática das 102 empresas da carteira FG, sem duplicar registros em reinicializações ou atualizações;
- cadastro de atividades e obrigações fiscais;
- seleção múltipla de CNPJs e responsáveis em atividades e obrigações, com seleção total e criação individual para cada combinação;
- carteira e seletores de clientes agrupados pelos cinco tipos da planilha FG: Simples, Lucro Presumido, Lucro Real, Imunes e MEI;
- busca e filtro por tipo empresarial na aba `Clientes`;
- colaboradores podem cadastrar atividades para si próprios; o cadastro de obrigações permanece restrito à Gestão e ao Admin;
- aba `Administrativo` exclusiva do Admin, com lançamentos flexíveis de valor, categoria e correlação/destino, edição e exclusão, rateio proporcional pelas horas trabalhadas, relatório de origens e exportações em PDF e Excel;
- aba `Orçamentos` exclusiva do Admin, com horas concluídas por CNPJ e competência, detalhamento por setor e funcionário, custo/receita extra e comparação do saldo por hora;
- atividades atribuídas com prazo de 30 minutos para início, atraso automático e registro de começo e término pelo servidor;
- ponto diário com entrada, saída para almoço, retorno e saída final;
- cálculo da jornada sem incluir o intervalo de almoço;
- ajustes de ponto restritos a gestores, sempre com motivo e auditoria;
- acompanhamento de prazos, pendências, horas e produtividade;
- painel ao vivo de produção por colaborador, com atividades, horas, conclusão e presença;
- visão limitada por responsável para colaboradores;
- trilha de auditoria das alterações;
- exportação CSV e cópias de segurança automáticas;
- dados centralizados no PC servidor, com gravação atômica;
- interface responsiva para computadores, tablets e celulares na mesma rede.
- menu lateral com rolagem prÃ³pria e botÃ£o para ocultar ou reabrir as abas; a escolha fica salva no computador.

## Instalação no computador servidor

1. Extraia a pasta completa para um local permanente, por exemplo `C:\DashboardFiscalOffice`. Não execute de dentro do ZIP.
2. Execute `INSTALAR_SERVIDOR.cmd`. Ele cria atalhos de iniciar e parar na Área de Trabalho.
3. Clique com o botão direito em `CONFIGURAR_FIREWALL.cmd` e escolha **Executar como administrador**. A regra aceita conexões somente no perfil de rede privada.
4. Execute `INICIAR_SERVIDOR.cmd`.
5. No primeiro acesso, informe o nome do escritório, o administrador e uma senha forte.

O arquivo `ENDERECOS_DO_ESCRITORIO.txt` será criado na pasta do sistema com os endereços de acesso da rede.

Na primeira inicialização a partir da versão 1.5.0, a carteira FG incorporada ao pacote é conciliada com os clientes existentes por CNPJ, Código Domínio ou razão social. Campos já preenchidos no sistema são preservados e a importação fica registrada na auditoria.

A versão 1.6.0 também cadastra automaticamente a equipe FG informada. Cada conta recebe uma senha temporária aleatória e exige uma nova senha pessoal no primeiro acesso. O arquivo `data\ACESSOS_INICIAIS_EQUIPE_FG.txt` é criado somente no servidor com os acessos iniciais; guarde-o em local seguro e apague-o depois de entregar as credenciais.

### Atualizando uma instalação anterior

1. Baixe o novo pacote ZIP completo sem extraí-lo.
2. Execute `ATUALIZAR_SERVIDOR.cmd` ou o atalho **Dashboard Fiscal - Atualizar**.
3. Selecione o ZIP e aguarde a confirmação.

O atualizador para o servidor, cria backups, preserva `data` e `config.json`, instala a nova versão, reinicia e verifica o funcionamento. Se houver falha, tenta restaurar automaticamente a versão anterior. Os computadores clientes não precisam ser reinstalados.

## Instalação nos outros computadores

1. Confirme que o computador servidor está ligado e que os dois PCs estão na mesma rede.
2. Copie apenas a pasta do pacote ou disponibilize `INSTALAR_CLIENTE.cmd` junto com a pasta `tools` no computador cliente.
3. Execute `INSTALAR_CLIENTE.cmd`.
4. Informe um endereço do arquivo `ENDERECOS_DO_ESCRITORIO.txt`, por exemplo `http://192.168.1.20:8787`.
5. Use o atalho **Dashboard Fiscal Office** criado na Área de Trabalho.

Os usuários devem ser cadastrados pelo administrador em **Usuários**, sempre com o setor correto. No login, a pessoa seleciona o setor e informa usuário e senha. Cada colaborador deve usar sua própria conta; não compartilhe uma conta ADMIN.

## Controle de ponto

No primeiro login do funcionário no dia, a entrada é registrada automaticamente pelo horário do servidor e a tela de Ponto é aberta. Outros logins no mesmo dia não criam novas batidas. Depois, o usuário registra nesta ordem: saída para almoço, retorno do almoço e saída final. Administradores e gestores enxergam o histórico da equipe, exportam CSV e podem corrigir uma marcação mediante justificativa. Toda batida e correção entra na auditoria.

O módulo foi projetado como controle interno de jornada. Antes de utilizá-lo como registro trabalhista oficial, valide com o responsável jurídico ou de departamento pessoal se são necessários requisitos legais ou equipamentos adicionais para a realidade da empresa.

## Atendimento por WhatsApp

A Central de Atendimento reúne as conversas dos clientes em uma fila com as abas **Pendentes**, **Em atendimento** e **Contatos**. Apenas administradores e gestores têm acesso. Cada conversa registra quem atendeu, o horário de início, o de encerramento e o tempo total, que alimentam o histórico e as métricas por funcionário.

Há dois modos de integração, escolhidos em **Atendimento WhatsApp → Configurar WhatsApp**:

- **WhatsApp oficial da Meta** — recebe e responde pelo número da empresa dentro do sistema. Exige uma conta na WhatsApp Business Platform, o token permanente de acesso, a chave secreta do aplicativo e um endereço público com HTTPS apontando para `/api/whatsapp/webhook`. O sistema valida a assinatura `X-Hub-Signature-256` de cada entrega e descarta mensagens repetidas pelo identificador da Meta.
- **Sistema parceiro** — o Gestta ou outro sistema envia os atendimentos para `/api/integrations/v1/attendances` usando uma chave Bearer gerada aqui. Nesse modo o DF Office recebe e distribui, mas não responde ao cliente.

Pontos de atenção:

- O endereço interno `http://192.168.88.229:8787` não serve como webhook. A Meta só entrega em endereços públicos com HTTPS. Use um túnel seguro em vez de abrir a porta 8787 no roteador.
- Preencha **WhatsApp do contato** no cadastro do cliente. É por esse número que o sistema identifica a empresa. A comparação ignora o +55 e o nono dígito.
- A Meta permite resposta livre em texto apenas nas 24 horas seguintes à última mensagem do cliente. Depois disso só valem modelos aprovados por ela, e o sistema avisa na tela.
- Uma conversa encerrada não volta a receber respostas. Uma nova mensagem do cliente abre outro atendimento.

O passo a passo completo de configuração está em `GUIA-ATUALIZACAO-v1.12.0.txt`.

## Rotina recomendada

- Mantenha o PC servidor ligado durante o expediente.
- Configure uma reserva de IP no roteador para o servidor, evitando que o endereço mude.
- Faça uma cópia externa semanal da pasta `data\backups`.
- Use **Backup** na área administrativa antes de alterações grandes.
- Encerre com `PARAR_SERVIDOR.cmd` antes de desligar ou mover a pasta.
- Não exponha a porta 8787 diretamente à internet. Para acesso remoto, use VPN ou uma hospedagem com HTTPS.

## Dados e recuperação

- Base principal: `data\db.json`
- Backups automáticos: `data\backups`
- Logs técnicos: `data\logs`
- Configuração: `config.json`

Para restaurar, pare o servidor, guarde uma cópia do `db.json` atual e copie o conteúdo do backup escolhido para `data\db.json`. Faça esse procedimento apenas com o servidor parado.

## Limites da edição local

Esta arquitetura atende bem um escritório pequeno ou médio em uma única rede. Para filiais, grande volume de acessos simultâneos, acesso externo contínuo ou integrações bancárias/fiscais, a evolução recomendada é hospedar a mesma aplicação com HTTPS e substituir o arquivo JSON por PostgreSQL, mantendo a interface e as regras já construídas.

## Suporte técnico rápido

- Se a tela não abrir no servidor, consulte `data\logs\erros.log`.
- Se abrir no servidor mas não em outro PC, confira rede privada, firewall e o IP em `ENDERECOS_DO_ESCRITORIO.txt`.
- Se a porta 8787 estiver ocupada, altere `port` em `config.json`, configure o firewall novamente e reinstale os atalhos clientes com o novo endereço.
- Os testes automatizados podem ser executados por um técnico com `runtime\node.exe --test tests\api.test.js tests\whatsapp.test.js`.

## Acesso bloqueado por tentativas

Cinco senhas erradas seguidas para o mesmo usuário bloqueiam o login por 15 minutos e a mensagem informa quantos minutos faltam. Um administrador pode liberar na hora: em **Usuários**, a conta aparece com a etiqueta **Bloqueado** e o botão **Liberar bloqueio**. A liberação entra na auditoria. Se o bloqueado for o único administrador, pare e inicie o servidor: a contagem é mantida em memória e some no reinício.
