"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const crypto = require("node:crypto");
const fs = require("node:fs/promises");
const os = require("node:os");
const path = require("node:path");
const { createApplication } = require("../server");
const { phoneCore, extractEvents, describeMessage } = require("../lib/whatsapp-api");

const APP_SECRET = "segredo-de-aplicativo-para-teste";

async function startTestApp(dataDir) {
  const app = await createApplication({
    dataDir, host: "127.0.0.1", port: 0, sessionHours: 1,
    importBundledClients: false, importBundledTeam: false
  });
  const info = await app.listen();
  return { app, baseUrl: info.localUrl.replace("localhost", "127.0.0.1") };
}

async function request(baseUrl, route, options = {}, session = {}) {
  const headers = { Accept: "application/json", ...(options.headers || {}) };
  if (session.cookie) headers.Cookie = session.cookie;
  if (session.csrf && !["GET", "HEAD"].includes(options.method || "GET")) headers["X-CSRF-Token"] = session.csrf;
  let body = options.body;
  if (body && typeof body !== "string" && !Buffer.isBuffer(body)) {
    headers["Content-Type"] = "application/json";
    body = JSON.stringify(body);
  }
  const response = await fetch(`${baseUrl}${route}`, { ...options, headers, body });
  const setCookie = response.headers.get("set-cookie");
  if (setCookie) session.cookie = setCookie.split(";")[0];
  const contentType = response.headers.get("content-type") || "";
  const payload = contentType.includes("application/json") ? await response.json() : await response.text();
  if (payload?.csrf) session.csrf = payload.csrf;
  return { response, payload };
}

function metaPayload(messages, statuses = []) {
  return {
    object: "whatsapp_business_account",
    entry: [{
      id: "111122223333",
      changes: [{
        field: "messages",
        value: {
          messaging_product: "whatsapp",
          metadata: { display_phone_number: "554733330000", phone_number_id: "1234567890123" },
          contacts: messages.map(message => ({ profile: { name: message.profileName || "Cliente" }, wa_id: message.from })),
          messages: messages.map(message => ({
            from: message.from, id: message.id, timestamp: String(Math.floor(Date.now() / 1000)),
            type: message.type || "text",
            ...(message.type === "image"
              ? { image: { id: "media-1", mime_type: "image/jpeg", caption: message.text } }
              : { text: { body: message.text } })
          })),
          ...(statuses.length ? { statuses } : {})
        }
      }]
    }]
  };
}

async function postWebhook(baseUrl, payload, secret = APP_SECRET) {
  const raw = Buffer.from(JSON.stringify(payload), "utf8");
  const signature = crypto.createHmac("sha256", secret).update(raw).digest("hex");
  return fetch(`${baseUrl}/api/whatsapp/webhook`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-Hub-Signature-256": `sha256=${signature}` },
    body: raw
  });
}

test("normaliza telefones brasileiros escritos de formas diferentes", () => {
  assert.equal(phoneCore("+55 (47) 99876-5432"), "4798765432");
  assert.equal(phoneCore("5547998765432"), "4798765432");
  assert.equal(phoneCore("4798765432"), "4798765432");
  assert.equal(phoneCore("47 3333-0000"), "4733330000");
  assert.equal(phoneCore("123"), "");
  assert.equal(phoneCore(""), "");
});

test("lê mensagens e confirmações de entrega do formato da Meta", () => {
  const events = extractEvents(metaPayload(
    [{ from: "5547998765432", id: "wamid.1", text: "Bom dia" }],
    [{ id: "wamid.out", status: "delivered", timestamp: "1700000000", recipient_id: "5547998765432" }]
  ));
  assert.equal(events.messages.length, 1);
  assert.equal(events.messages[0].profileName, "Cliente");
  assert.equal(events.statuses.length, 1);
  assert.equal(describeMessage({ type: "text", text: { body: "Olá" } }).text, "Olá");
  assert.equal(describeMessage({ type: "image", image: { id: "m1", mime_type: "image/png", caption: "nota" } }).mediaId, "m1");
  assert.deepEqual(extractEvents({}), { messages: [], statuses: [] });
});

test("webhook oficial só aceita verificação e assinatura corretas", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "df-whatsapp-webhook-"));
  const { app, baseUrl } = await startTestApp(dataDir);
  t.after(async () => { await app.close().catch(() => {}); await fs.rm(dataDir, { recursive: true, force: true }); });

  const admin = {};
  await request(baseUrl, "/api/setup", { method: "POST", body: { officeName: "FG Teste", name: "Admin", username: "admin", password: "Senha!Forte123" } }, admin);

  // Sem configuração, o webhook recusa qualquer entrega.
  let response = await postWebhook(baseUrl, metaPayload([{ from: "5547998765432", id: "wamid.0", text: "oi" }]));
  assert.equal(response.status, 409);

  const saved = await request(baseUrl, "/api/whatsapp-integration", {
    method: "POST",
    body: {
      provider: "META_CLOUD", name: "FG Atendimento", phoneNumberId: "1234567890123",
      businessAccountId: "111122223333", accessToken: "x".repeat(60), appSecret: APP_SECRET,
      publicWebhookUrl: "https://atendimento.fgteste.com.br/api/whatsapp/webhook"
    }
  }, admin);
  assert.equal(saved.response.status, 200);
  assert.equal(saved.payload.connected, true);
  assert.equal(saved.payload.canSend, true);
  assert.match(saved.payload.verifyToken, /^dfv_/);
  assert.equal(saved.payload.publicWebhookUrl, "https://atendimento.fgteste.com.br/api/whatsapp/webhook");

  // A verificação da Meta devolve o desafio apenas com o token certo.
  const verifyToken = saved.payload.verifyToken;
  let verify = await fetch(`${baseUrl}/api/whatsapp/webhook?hub.mode=subscribe&hub.verify_token=${encodeURIComponent(verifyToken)}&hub.challenge=desafio-123`);
  assert.equal(verify.status, 200);
  assert.equal(await verify.text(), "desafio-123");
  verify = await fetch(`${baseUrl}/api/whatsapp/webhook?hub.mode=subscribe&hub.verify_token=errado&hub.challenge=desafio-123`);
  assert.equal(verify.status, 403);

  // Assinatura inválida é rejeitada antes de tocar no banco.
  response = await postWebhook(baseUrl, metaPayload([{ from: "5547998765432", id: "wamid.1", text: "oi" }]), "segredo-errado-de-teste");
  assert.equal(response.status, 401);
  let conversations = await request(baseUrl, "/api/whatsapp/conversations?tab=all", {}, admin);
  assert.equal(conversations.payload.items.length, 0);

  // Endereço público precisa ser HTTPS.
  const badUrl = await request(baseUrl, "/api/whatsapp-integration", {
    method: "POST",
    body: { provider: "META_CLOUD", phoneNumberId: "1234567890123", accessToken: "x".repeat(60), appSecret: APP_SECRET, publicWebhookUrl: "http://192.168.88.229:8787/api/whatsapp/webhook" }
  }, admin);
  assert.equal(badUrl.response.status, 400);
});

test("mensagem recebida abre conversa, vincula o cliente pelo telefone e não duplica", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "df-whatsapp-fila-"));
  const { app, baseUrl } = await startTestApp(dataDir);
  t.after(async () => { await app.close().catch(() => {}); await fs.rm(dataDir, { recursive: true, force: true }); });

  const admin = {};
  await request(baseUrl, "/api/setup", { method: "POST", body: { officeName: "FG Teste", name: "Admin", username: "admin", password: "Senha!Forte123" } }, admin);
  await request(baseUrl, "/api/whatsapp-integration", {
    method: "POST",
    body: { provider: "META_CLOUD", phoneNumberId: "1234567890123", accessToken: "x".repeat(60), appSecret: APP_SECRET }
  }, admin);

  const client = await request(baseUrl, "/api/clients", {
    method: "POST",
    body: { name: "Vertice Lab Ltda", cnpj: "11222333000181", taxRegime: "SIMPLES NACIONAL", whatsappPhone: "47 99876-5432" }
  }, admin);
  assert.equal(client.response.status, 201);
  assert.equal(client.payload.item.whatsappPhone, "47998765432");

  let response = await postWebhook(baseUrl, metaPayload([{ from: "5547998765432", id: "wamid.100", text: "Preciso da guia do Simples", profileName: "Victor" }]));
  assert.equal(response.status, 200);
  assert.deepEqual(await response.json(), { ok: true, received: 1, statuses: 0 });

  let conversations = await request(baseUrl, "/api/whatsapp/conversations?tab=pending", {}, admin);
  assert.equal(conversations.payload.items.length, 1);
  assert.equal(conversations.payload.counts.pending, 1);
  const conversation = conversations.payload.items[0];
  assert.equal(conversation.clientName, "Vertice Lab Ltda", "o telefone do cadastro deve vincular o cliente mesmo sem o 55");
  assert.equal(conversation.contactName, "Victor");
  assert.equal(conversation.unread, 1);
  assert.equal(conversation.windowOpen, true);

  // A mesma wamid chegando de novo não cria outra mensagem.
  response = await postWebhook(baseUrl, metaPayload([{ from: "5547998765432", id: "wamid.100", text: "Preciso da guia do Simples" }]));
  assert.deepEqual(await response.json(), { ok: true, received: 0, statuses: 0 });

  // Mensagem seguinte entra na mesma conversa aberta.
  await postWebhook(baseUrl, metaPayload([{ from: "5547998765432", id: "wamid.101", text: "Pode ser hoje?" }]));
  let thread = await request(baseUrl, `/api/whatsapp/conversations/${conversation.id}`, {}, admin);
  assert.equal(thread.payload.item.messages.length, 2);
  assert.equal(thread.payload.item.subject, "Preciso da guia do Simples");
  assert.equal(thread.payload.item.unread, 2);

  conversations = await request(baseUrl, "/api/whatsapp/conversations?tab=all", {}, admin);
  assert.equal(conversations.payload.items.length, 1, "duas mensagens do mesmo número formam um atendimento só");

  // Marcar como lida zera o contador; a busca encontra pelo nome do cliente.
  await request(baseUrl, `/api/whatsapp/conversations/${conversation.id}/read`, { method: "POST", body: {} }, admin);
  thread = await request(baseUrl, `/api/whatsapp/conversations/${conversation.id}`, {}, admin);
  assert.equal(thread.payload.item.unread, 0);
  const busca = await request(baseUrl, "/api/whatsapp/conversations?tab=all&q=vertice", {}, admin);
  assert.equal(busca.payload.items.length, 1);
  const vazia = await request(baseUrl, "/api/whatsapp/conversations?tab=all&q=inexistente", {}, admin);
  assert.equal(vazia.payload.items.length, 0);

  // Número desconhecido fica sem cliente e pode ser vinculado pela Gestão.
  await postWebhook(baseUrl, metaPayload([{ from: "5511911112222", id: "wamid.200", text: "Sou cliente novo" }]));
  conversations = await request(baseUrl, "/api/whatsapp/conversations?tab=pending", {}, admin);
  const desconhecido = conversations.payload.items.find(item => item.waid === "5511911112222");
  assert.equal(desconhecido.clientId, "");
  const vinculado = await request(baseUrl, `/api/whatsapp/conversations/${desconhecido.id}/client`, {
    method: "POST", body: { clientId: client.payload.item.id }
  }, admin);
  assert.equal(vinculado.payload.item.clientId, client.payload.item.id);
});

test("responder exige integração ativa e respeita a janela de 24 horas", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "df-whatsapp-envio-"));
  const { app, baseUrl } = await startTestApp(dataDir);
  t.after(async () => { await app.close().catch(() => {}); await fs.rm(dataDir, { recursive: true, force: true }); });

  const admin = {};
  await request(baseUrl, "/api/setup", { method: "POST", body: { officeName: "FG Teste", name: "Admin", username: "admin", password: "Senha!Forte123" } }, admin);
  const client = await request(baseUrl, "/api/clients", {
    method: "POST", body: { name: "Cliente Teste", cnpj: "11222333000181", taxRegime: "MEI", whatsappPhone: "5547988887777" }
  }, admin);
  const manual = await request(baseUrl, "/api/attendances", {
    method: "POST",
    body: { clientId: client.payload.item.id, subject: "Solicitação por telefone", contactPhone: "5547988887777", message: "Registro manual" }
  }, admin);
  assert.equal(manual.response.status, 201);

  // Sem integração oficial, o envio é recusado com explicação.
  let send = await request(baseUrl, `/api/whatsapp/conversations/${manual.payload.item.id}/messages`, {
    method: "POST", body: { text: "Bom dia" }
  }, admin);
  assert.equal(send.response.status, 409);
  assert.match(send.payload.error, /integração oficial/i);

  await request(baseUrl, "/api/whatsapp-integration", {
    method: "POST",
    body: { provider: "META_CLOUD", phoneNumberId: "1234567890123", accessToken: "x".repeat(60), appSecret: APP_SECRET }
  }, admin);

  // O registro manual não tem mensagem recebida do cliente, então a janela está fechada.
  send = await request(baseUrl, `/api/whatsapp/conversations/${manual.payload.item.id}/messages`, {
    method: "POST", body: { text: "Bom dia" }
  }, admin);
  assert.equal(send.response.status, 409);
  assert.match(send.payload.error, /24 horas/);

  // Sem token CSRF nenhum envio passa.
  const semToken = await fetch(`${baseUrl}/api/whatsapp/conversations/${manual.payload.item.id}/messages`, {
    method: "POST", headers: { "Content-Type": "application/json", Cookie: admin.cookie }, body: JSON.stringify({ text: "oi" })
  });
  assert.equal(semToken.status, 403);
});

test("api do parceiro recebe atendimentos por chave e ignora repetições", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "df-whatsapp-parceiro-"));
  const { app, baseUrl } = await startTestApp(dataDir);
  t.after(async () => { await app.close().catch(() => {}); await fs.rm(dataDir, { recursive: true, force: true }); });

  const admin = {};
  await request(baseUrl, "/api/setup", { method: "POST", body: { officeName: "FG Teste", name: "Admin", username: "admin", password: "Senha!Forte123" } }, admin);
  await request(baseUrl, "/api/clients", {
    method: "POST", body: { name: "Empresa Parceira", cnpj: "11222333000181", taxRegime: "LUCRO PRESUMIDO" }
  }, admin);
  await request(baseUrl, "/api/whatsapp-integration", { method: "POST", body: { provider: "PARCEIRO", name: "Gestta" } }, admin);
  const keyResult = await request(baseUrl, "/api/whatsapp-integration/key", { method: "POST", body: {} }, admin);
  const key = keyResult.payload.key;
  assert.match(key, /^dfi_/);
  assert.equal(keyResult.payload.canSend, false, "o modo parceiro recebe, mas não responde pelo sistema");

  const push = (body, token = key) => fetch(`${baseUrl}/api/integrations/v1/attendances`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify(body)
  });

  const semChave = await fetch(`${baseUrl}/api/integrations/v1/health`);
  assert.equal(semChave.status, 401);
  const saude = await fetch(`${baseUrl}/api/integrations/v1/health`, { headers: { Authorization: `Bearer ${key}` } });
  assert.equal(saude.status, 200);

  const body = { externalId: "gestta-9001", cnpj: "11222333000181", subject: "Envio de documentos", message: "Segue a folha", contactName: "Rodrigo", contactPhone: "5547977776666" };
  let created = await push(body);
  assert.equal(created.status, 201);
  assert.equal((await created.json()).duplicate, false);
  created = await push(body);
  assert.equal((await created.json()).duplicate, true, "o mesmo externalId com o mesmo conteúdo não duplica");
  const conflito = await push({ ...body, subject: "Outro assunto" });
  assert.equal(conflito.status, 409);

  const conversations = await request(baseUrl, "/api/whatsapp/conversations?tab=pending", {}, admin);
  assert.equal(conversations.payload.items.length, 1);
  assert.equal(conversations.payload.items[0].clientName, "Empresa Parceira");
  assert.equal(conversations.payload.items[0].messageCount, 1);

  // Desligar a integração invalida a chave imediatamente.
  await request(baseUrl, "/api/whatsapp-integration", { method: "DELETE" }, admin);
  const depois = await push({ ...body, externalId: "gestta-9002" });
  assert.equal(depois.status, 401);
});

test("gestor enxerga a central, colaborador não", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "df-whatsapp-acesso-"));
  const { app, baseUrl } = await startTestApp(dataDir);
  t.after(async () => { await app.close().catch(() => {}); await fs.rm(dataDir, { recursive: true, force: true }); });

  const admin = {};
  await request(baseUrl, "/api/setup", { method: "POST", body: { officeName: "FG Teste", name: "Admin", username: "admin", password: "Senha!Forte123" } }, admin);
  for (const [username, sector, expected] of [["rebeca", "GESTAO", 200], ["wesley", "FISCAL/CONTABIL", 403]]) {
    const created = await request(baseUrl, "/api/users", { method: "POST", body: { name: username, username, sector, password: "Inicial!Teste123" } }, admin);
    const session = {};
    await request(baseUrl, "/api/login", { method: "POST", body: { sector, username, password: "Inicial!Teste123" } }, session);
    await request(baseUrl, `/api/users/${created.payload.item.id}/password`, { method: "PUT", body: { password: "Definitiva!Teste123" } }, session);
    const result = await request(baseUrl, "/api/whatsapp/conversations?tab=pending", {}, session);
    assert.equal(result.response.status, expected);
    const settings = await request(baseUrl, "/api/whatsapp-integration", { method: "POST", body: { provider: "PARCEIRO" } }, session);
    assert.equal(settings.response.status, expected === 200 ? 200 : 403, "Gestão configura a integração; colaborador não");
  }
});

test("reeditar a integração preserva token e segredo já gravados", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "df-whatsapp-reedicao-"));
  const { app, baseUrl } = await startTestApp(dataDir);
  t.after(async () => { await app.close().catch(() => {}); await fs.rm(dataDir, { recursive: true, force: true }); });

  const admin = {};
  await request(baseUrl, "/api/setup", { method: "POST", body: { officeName: "FG Teste", name: "Admin", username: "admin", password: "Senha!Forte123" } }, admin);
  const primeiro = await request(baseUrl, "/api/whatsapp-integration", {
    method: "POST",
    body: { provider: "META_CLOUD", phoneNumberId: "1234567890123", accessToken: "x".repeat(60), appSecret: APP_SECRET }
  }, admin);
  const verifyToken = primeiro.payload.verifyToken;

  // Salvar de novo sem repetir os segredos mantém a conexão e o mesmo token de verificação.
  const segundo = await request(baseUrl, "/api/whatsapp-integration", {
    method: "POST",
    body: { provider: "META_CLOUD", phoneNumberId: "1234567890123", accessToken: "", appSecret: "", publicWebhookUrl: "https://novo.fgteste.com.br/api/whatsapp/webhook" }
  }, admin);
  assert.equal(segundo.payload.connected, true);
  assert.equal(segundo.payload.verifyToken, verifyToken);
  assert.equal(segundo.payload.publicWebhookUrl, "https://novo.fgteste.com.br/api/whatsapp/webhook");

  // E a assinatura continua sendo validada com o segredo original.
  const response = await postWebhook(baseUrl, metaPayload([{ from: "5547998765432", id: "wamid.reedicao", text: "ainda funciona" }]));
  assert.equal(response.status, 200);
  assert.equal((await response.json()).received, 1);

  // O ADMIN consegue reler o token de verificação para colar no painel da Meta.
  const leitura = await request(baseUrl, "/api/whatsapp-integration", {}, admin);
  assert.equal(leitura.payload.verifyToken, verifyToken);

  // Trocar para o modo parceiro descarta os segredos da Meta.
  await request(baseUrl, "/api/whatsapp-integration", { method: "POST", body: { provider: "PARCEIRO" } }, admin);
  const parceiro = await request(baseUrl, "/api/whatsapp-integration", {}, admin);
  assert.equal(parceiro.payload.canSend, false);
  assert.equal(parceiro.payload.hasAppSecret, false);
});
