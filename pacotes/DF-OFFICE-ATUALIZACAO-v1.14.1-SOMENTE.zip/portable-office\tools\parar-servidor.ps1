. (Join-Path $PSScriptRoot "common.ps1")

$root = Get-DashboardRoot
$pidFile = Join-Path $root "data\server.pid"
if (-not (Test-Path -LiteralPath $pidFile)) {
  Write-Host "O servidor já está parado." -ForegroundColor Yellow
  return
}

$serverPidText = (Get-Content -LiteralPath $pidFile -Raw).Trim()
$parsedPid = 0
if (-not [int]::TryParse($serverPidText, [ref]$parsedPid) -or $parsedPid -le 0) {
  throw "O arquivo de controle do servidor é inválido."
}

$process = Get-Process -Id $parsedPid -ErrorAction SilentlyContinue
if ($null -eq $process) {
  Remove-Item -LiteralPath $pidFile -Force
  Write-Host "O servidor já estava parado; o controle antigo foi removido." -ForegroundColor Yellow
  return
}

$expectedNode = [System.IO.Path]::GetFullPath((Get-DashboardNode -Root $root))
$actualProcessPath = [System.IO.Path]::GetFullPath($process.Path)
if (-not [string]::Equals($actualProcessPath, $expectedNode, [System.StringComparison]::OrdinalIgnoreCase)) {
  throw "O processo registrado não corresponde ao Dashboard Fiscal. Nenhum processo foi encerrado."
}

Stop-Process -Id $parsedPid
Wait-Process -Id $parsedPid -Timeout 10 -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $pidFile -Force -ErrorAction SilentlyContinue
Write-Host "Dashboard Fiscal encerrado." -ForegroundColor Green
