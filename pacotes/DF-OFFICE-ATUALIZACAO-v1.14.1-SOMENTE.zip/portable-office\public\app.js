"use strict";

const state = {
  csrf: "",
  user: null,
  officeName: "",
  activityStatus: [],
  obligationStatus: [],
  timeClockTypes: [],
  clients: [],
  team: [],
  activities: [],
  obligations: [],
  obligationCatalog: [],
  attendances: [],
  attendanceMetrics: null,
  demands: [],
  attendanceQueueStatus: "",
  chat: { tab: "pending", search: "", conversationId: "", items: [], counts: { pending: 0, active: 0, total: 0 }, integration: null, thread: null },
  attendanceTimer: null,
  users: [],
  administrative: { period: "", summary: null, administrative: null, entries: [], items: [] },
  budgets: { period: "", summary: null, items: [] },
  audit: [],
  branding: { companyName: "", primaryColor: "", logoUrl: "" },
  obligationPanel: null,
  recurrences: [],
  obligationSelection: new Set(),
  stepTemplates: [],
  exportPreview: null,
  timeClock: null,
  activityBusy: null,
  installPrompt: null
};

const $ = selector => document.querySelector(selector);
const $$ = selector => [...document.querySelectorAll(selector)];
const SECTOR_IDENTITIES = {
  DP: { mark: "DP", name: "DP OFFICE" },
  "FISCAL/CONTABIL": { mark: "FC", name: "FISCAL/CONTABIL OFFICE" },
  GESTAO: { mark: "GE", name: "GESTAO OFFICE" },
  ADMIN: { mark: "DF", name: "DF OFFICE" }
};
const SIDEBAR_STORAGE_KEY = "dashboardFiscalSidebarCollapsed";
const COMPANY_TYPES = [
  { value: "SIMPLES NACIONAL", singular: "EMPRESA SIMPLES", plural: "EMPRESAS SIMPLES" },
  { value: "LUCRO PRESUMIDO", singular: "EMPRESA LUCRO PRESUMIDO", plural: "EMPRESAS LUCRO PRESUMIDO" },
  { value: "LUCRO REAL", singular: "EMPRESA LUCRO REAL", plural: "EMPRESAS LUCRO REAL" },
  { value: "IMUNE", singular: "EMPRESA IMUNE", plural: "EMPRESAS IMUNES" },
  { value: "MEI", singular: "EMPRESA MEI", plural: "EMPRESAS MEI" }
];
const COMPANY_TYPE_ORDER = new Map(COMPANY_TYPES.map((item, index) => [item.value, index]));

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>'"]/g, character => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;"
  })[character]);
}

function toast(message, error = false) {
  const element = $("#toast");
  element.textContent = message;
  element.classList.toggle("error", error);
  element.hidden = false;
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => { element.hidden = true; }, 3800);
}

async function api(url, options = {}) {
  const method = options.method || "GET";
  const headers = { Accept: "application/json", ...(options.headers || {}) };
  if (options.body && typeof options.body !== "string") {
    headers["Content-Type"] = "application/json";
    options.body = JSON.stringify(options.body);
  }
  if (!["GET", "HEAD"].includes(method) && state.csrf) headers["X-CSRF-Token"] = state.csrf;
  let response;
  try {
    response = await fetch(url, { ...options, method, headers, credentials: "same-origin" });
  } catch {
    $("#connection-banner").hidden = false;
    throw new Error("Servidor indisponível. Verifique a conexão de rede.");
  }
  $("#connection-banner").hidden = true;
  const payload = await response.json().catch(() => ({ ok: false, error: "Resposta inválida do servidor." }));
  if (response.status === 401 && !url.endsWith("/login")) showLogin();
  if (!response.ok || payload.ok === false) throw new Error(payload.error || `Erro ${response.status}`);
  return payload;
}

function formData(form) {
  const data = Object.fromEntries(new FormData(form));
  for (const checkbox of form.querySelectorAll('input[type="checkbox"]')) data[checkbox.name] = checkbox.checked;
  return data;
}

function showOnly(id) {
  $("#setup-view").hidden = id !== "setup-view";
  $("#login-view").hidden = id !== "login-view";
  $("#app-view").hidden = id !== "app-view";
}

function showLogin() {
  state.csrf = "";
  state.user = null;
  $("#login-office-name").textContent = state.officeName || "Entrar";
  applySectorIdentity($('#login-form select[name="sector"]').value);
  showOnly("login-view");
}

function shadeColor(hex, amount) {
  const value = String(hex || "").replace("#", "");
  if (!/^[0-9a-f]{6}$/i.test(value)) return hex;
  const channels = [0, 2, 4].map(index => parseInt(value.slice(index, index + 2), 16));
  const mixed = channels.map(channel => {
    const next = amount < 0 ? channel * (1 + amount) : channel + (255 - channel) * amount;
    return Math.max(0, Math.min(255, Math.round(next))).toString(16).padStart(2, "0");
  });
  return `#${mixed.join("")}`;
}

function applyBranding(branding = state.branding) {
  state.branding = { ...state.branding, ...branding };
  const root = document.documentElement;
  if (state.branding.primaryColor) {
    root.style.setProperty("--primary", state.branding.primaryColor);
    root.style.setProperty("--primary-strong", shadeColor(state.branding.primaryColor, -0.25));
  } else {
    root.style.removeProperty("--primary");
    root.style.removeProperty("--primary-strong");
  }
  applySectorIdentity(state.currentSector || $('#login-form select[name="sector"]').value);
}

function brandMark(element, initials) {
  if (!element) return;
  if (state.branding.logoUrl) {
    element.innerHTML = `<img src="${escapeHtml(state.branding.logoUrl)}" alt="Logo da empresa">`;
    element.classList.add("has-logo");
  } else {
    element.textContent = initials;
    element.classList.remove("has-logo");
  }
}

function applySectorIdentity(sector) {
  const identity = SECTOR_IDENTITIES[sector] || SECTOR_IDENTITIES.ADMIN;
  state.currentSector = sector;
  brandMark($("#login-brand-mark"), identity.mark);
  brandMark($("#sidebar-brand-mark"), identity.mark);
  const nome = state.branding.companyName || identity.name;
  $("#login-product-name").textContent = nome;
  $("#sidebar-product-name").textContent = nome;
  document.title = nome;
}

function applyRoleVisibility() {
  $$('[data-role]').forEach(element => {
    const roles = element.dataset.role.split(",");
    element.hidden = !roles.includes(state.user.role);
  });
  $$('[data-manager-field]').forEach(element => { element.hidden = state.user.role === "COLABORADOR"; });
  // Gestão e administração enxergam e podem tudo, inclusive criar outra conta administrativa.
  $$("#user-form option[data-admin-only]").forEach(option => {
    option.hidden = false;
    option.disabled = false;
  });
}

function isMobileSidebar() {
  return window.matchMedia("(max-width: 760px)").matches;
}

function readSidebarPreference() {
  try { return window.localStorage.getItem(SIDEBAR_STORAGE_KEY) === "1"; }
  catch { return false; }
}

function saveSidebarPreference(collapsed) {
  try { window.localStorage.setItem(SIDEBAR_STORAGE_KEY, collapsed ? "1" : "0"); }
  catch {}
}

function updateSidebarToggle() {
  const app = $("#app-view");
  const button = $("#sidebar-toggle");
  const mobile = isMobileSidebar();
  const expanded = mobile ? app.classList.contains("menu-open") : !app.classList.contains("sidebar-collapsed");
  button.textContent = mobile ? (expanded ? "×" : "☰") : (expanded ? "‹" : "☰");
  button.setAttribute("aria-expanded", String(expanded));
  button.setAttribute("aria-label", expanded ? "Ocultar menu lateral" : "Abrir menu lateral");
}

function restoreSidebarPreference() {
  const app = $("#app-view");
  const mobile = isMobileSidebar();
  app.classList.remove("menu-open");
  app.classList.toggle("sidebar-collapsed", !mobile && readSidebarPreference());
  app.dataset.sidebarLayout = mobile ? "mobile" : "desktop";
  updateSidebarToggle();
}

function toggleSidebar() {
  const app = $("#app-view");
  if (isMobileSidebar()) {
    app.classList.toggle("menu-open");
  } else {
    const collapsed = app.classList.toggle("sidebar-collapsed");
    saveSidebarPreference(collapsed);
  }
  updateSidebarToggle();
}

function showApp(initialView) {
  showOnly("app-view");
  restoreSidebarPreference();
  const collaborator = state.user.role === "COLABORADOR";
  $("#app-view").classList.toggle("collaborator-mode", collaborator);
  applySectorIdentity(state.user.sector);
  $("#office-name").textContent = state.officeName;
  $("#current-user").textContent = state.user.name;
  $("#current-role").textContent = `${state.user.sector} • ${state.user.role}`;
  $("#activity-form-title").textContent = collaborator ? "Adicionar minha atividade" : "Atribuir atividade";
  $("#activity-user-label").textContent = collaborator ? "Responsável (você)" : "Colaborador";
  $("#activity-form-note").textContent = collaborator
    ? "A atividade será vinculada ao seu usuário. Depois de salvar, clique nela para iniciar em até 30 minutos."
    : "Após a atribuição, o colaborador terá 30 minutos para clicar e iniciar. Os horários serão registrados pelo servidor.";
  $("#activity-submit").textContent = collaborator ? "Adicionar atividade" : "Atribuir atividade";
  applyRoleVisibility();
  navigate(initialView || "dashboard");
}

function navigate(view) {
  let button = $(`#main-nav button[data-view="${view}"]`);
  if (!button || button.hidden) {
    button = $$("#main-nav button[data-view]").find(item => !item.hidden);
    if (!button) return;
    view = button.dataset.view;
  }
  $$("#main-nav button").forEach(item => item.classList.toggle("active", item.dataset.view === view));
  $$(".view").forEach(item => item.classList.toggle("active", item.id === `view-${view}`));
  const titles = {
    dashboard: ["Painel gerencial", "Visão geral"], "time-clock": ["Jornada da equipe", "Ponto"],
    activities: ["Operação diária", "Atividades"],
    obligations: ["Controle fiscal", "Obrigações"], clients: ["Cadastro mestre", "Clientes"],
    administrative: ["Custos e rateio", "Administrativo"],
    budgets: ["Rentabilidade por CNPJ", "Orçamentos"],
    "attendance-inbox": ["Comunicação com clientes", "Atendimento WhatsApp"],
    "attendance-history": ["Rastreabilidade do atendimento", "Histórico de atendimentos"],
    "attendance-metrics": ["Desempenho da equipe", "Métricas de atendimento"],
    "manager-demands": ["Trabalho entre setores", "Demandas e anexos"],
    "obligations-panel": ["Controle mensal", "Painel de obrigações"],
    exports: ["Movimentações", "Exportações"],
    branding: ["Aparência do sistema", "Identidade visual"],
    users: ["Segurança", "Usuários"], audit: ["Rastreabilidade", "Auditoria"]
  };
  $("#page-eyebrow").textContent = titles[view][0];
  $("#page-title").textContent = titles[view][1];
  $("#app-view").classList.remove("menu-open");
  updateSidebarToggle();
  if (view === "audit") loadAudit().catch(handleError);
  if (view === "time-clock") loadTimeClock().catch(handleError);
  if (view === "administrative") loadAdministrative().catch(handleError);
  if (view === "budgets") loadBudgets().catch(handleError);
  if (view === "attendance-inbox") loadAttendanceInbox().catch(handleError);
  if (view === "attendance-history") loadAttendanceHistory().catch(handleError);
  if (view === "attendance-metrics") loadAttendanceMetrics().catch(handleError);
  if (view === "manager-demands") loadDemands().catch(handleError);
  if (view === "obligations-panel") loadObligationsPanel().catch(handleError);
  if (view === "exports") loadExports().catch(handleError);
  if (view === "branding") loadBranding().catch(handleError);
}

function handleError(error) {
  console.error(error);
  toast(error.message || "Não foi possível concluir a operação.", true);
}

function clientName(id) {
  const client = state.clients.find(item => item.id === id);
  return client ? clientReference(client) : "Cliente não encontrado";
}

function clientReference(client) {
  const reference = client.domainCode || cnpjLabel(client.cnpj) || client.code;
  return reference && reference !== "—" ? `${reference} — ${client.name}` : client.name;
}

function searchKey(value) {
  return String(value || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("pt-BR");
}

function companyTypeLabel(value, plural = true) {
  const type = COMPANY_TYPES.find(item => item.value === value);
  return type ? type[plural ? "plural" : "singular"] : "SEM CLASSIFICAÇÃO";
}

function userName(id) {
  return state.team.find(item => item.id === id)?.name || "Não definido";
}

function minutesLabel(value) {
  const minutes = Number(value || 0);
  return `${Math.floor(minutes / 60)}h ${String(minutes % 60).padStart(2, "0")}min`;
}

function moneyLabel(value) {
  return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(Number(value || 0));
}

function dateLabel(value) {
  if (!value) return "—";
  const [year, month, day] = value.split("-");
  return `${day}/${month}/${year}`;
}

function dateTimeLabel(value) {
  if (!value) return "—";
  return new Intl.DateTimeFormat("pt-BR", { dateStyle: "short", timeStyle: "medium" }).format(new Date(value));
}

function todayValue() {
  const parts = new Intl.DateTimeFormat("en-CA", { year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(new Date());
  const values = Object.fromEntries(parts.filter(part => part.type !== "literal").map(part => [part.type, part.value]));
  return `${values.year}-${values.month}-${values.day}`;
}

function timeClockLabel(type) {
  return state.timeClockTypes.find(item => item.value === type)?.label || type || "";
}

function cnpjLabel(value) {
  const digits = String(value || "").replace(/\D/g, "");
  if (digits.length !== 14) return digits || "—";
  return digits.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, "$1.$2.$3/$4-$5");
}

function cpfLabel(value) {
  const digits = String(value || "").replace(/\D/g, "");
  if (digits.length !== 11) return digits || "—";
  return digits.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/, "$1.$2.$3-$4");
}

function statusBadge(status) {
  const value = String(status || "");
  const className = /CANCEL|ATRAS|PENDENTE/.test(value) ? "danger" : /ATIVIDADE|ANDAMENTO|PAUSADA|CONFERÊNCIA|TRANSMISSÃO/.test(value) ? "warning" : /CONCLU|TRANSMIT|ENVIADO|DISPENSADO|NÃO PRECISA/.test(value) ? "" : "muted";
  return `<span class="badge ${className}">${escapeHtml(value)}</span>`;
}

// A atividade e iniciada por quem a executa: colaborador ou gestor.
function activityIsMine(item) {
  return ["COLABORADOR", "GESTOR"].includes(state.user?.role) && item.userId === state.user.id;
}

function activityCanStart(item) {
  return activityIsMine(item) && ["EM ANDAMENTO", "EM ATRASO"].includes(item.status);
}

function activityTimingLabel(item) {
  if (item.status === "EM ANDAMENTO" && item.startDeadlineAt) {
    const remaining = Math.max(0, Math.ceil((Date.parse(item.startDeadlineAt) - Date.now()) / 60000));
    return `<strong>Iniciar em até ${remaining} min</strong><small class="cell-subtitle">Prazo: ${dateTimeLabel(item.startDeadlineAt)}</small>`;
  }
  if (item.status === "EM ATRASO") {
    const lateMinutes = item.startDeadlineAt ? Math.max(0, Math.floor((Date.now() - Date.parse(item.startDeadlineAt)) / 60000)) : 0;
    return `<strong class="danger-text">Atrasada há ${lateMinutes} min</strong><small class="cell-subtitle">Clique para iniciar</small>`;
  }
  if (item.status === "EM ATIVIDADE" && item.startedAt) {
    const elapsed = Math.max(0, Math.floor((Date.now() - Date.parse(item.startedAt)) / 60000));
    return `<strong>${minutesLabel(elapsed)}</strong><small class="cell-subtitle">Início: ${dateTimeLabel(item.startedAt)}</small>`;
  }
  if (item.status === "CONCLUÍDO") {
    return `<strong>${minutesLabel(item.totalMinutes)}</strong><small class="cell-subtitle">Fim: ${dateTimeLabel(item.finishedAt)}</small>`;
  }
  return `<strong>${minutesLabel(item.totalMinutes)}</strong>`;
}

function activityTaskMarkup(item) {
  const task = `<strong>${escapeHtml(item.task)}</strong>`;
  if (activityCanStart(item)) return `${task}<small class="cell-subtitle">Clique na atividade para iniciar</small>`;
  if (state.user?.role === "COLABORADOR" && item.status === "EM ATIVIDADE") {
    return `<button class="activity-task-button" data-action="finish-activity" data-id="${escapeHtml(item.id)}">${escapeHtml(item.task)}</button><small class="cell-subtitle">Em atividade • clique para editar/finalizar</small>`;
  }
  return task;
}

function activityRowAttributes(item) {
  return activityCanStart(item) ? ` class="activity-row-clickable" data-start-activity="${escapeHtml(item.id)}"` : "";
}

function presenceBadge(status) {
  const classes = status === "EM EXPEDIENTE" ? "" : status === "EM ALMOÇO" ? "warning" : status === "JORNADA CONCLUÍDA" ? "muted" : "danger";
  return `<span class="badge ${classes}">${escapeHtml(status)}</span>`;
}

function fillSelect(select, items, placeholder, valueKey = "id", label = item => item.name) {
  const current = select.value;
  select.innerHTML = `<option value="">${escapeHtml(placeholder)}</option>` + items.map(item => `<option value="${escapeHtml(item[valueKey])}">${escapeHtml(label(item))}</option>`).join("");
  if ([...select.options].some(option => option.value === current)) select.value = current;
}

function pickerValues(picker) {
  try {
    const value = JSON.parse(picker.querySelector(".multi-picker-value").value || "[]");
    return Array.isArray(value) ? [...new Set(value.map(String).filter(Boolean))] : [];
  } catch {
    return [];
  }
}

function updatePickerState(picker) {
  const optionInputs = [...picker.querySelectorAll(".multi-picker-option input")];
  const selected = optionInputs.filter(input => input.checked).map(input => input.value);
  picker.querySelector(".multi-picker-value").value = JSON.stringify(selected);
  const selectedItems = selected.map(id => picker._pickerItems?.find(item => String(item.id) === id)).filter(Boolean);
  const trigger = picker.querySelector(".multi-picker-trigger");
  trigger.textContent = selectedItems.length === 1
    ? picker._pickerLabel(selectedItems[0])
    : selectedItems.length > 1 ? `${selectedItems.length} selecionados` : picker.dataset.placeholder;
  trigger.title = selectedItems.length ? selectedItems.map(item => picker._pickerLabel(item)).join("\n") : picker.dataset.placeholder;
  const all = picker.querySelector(".multi-picker-all input");
  all.checked = Boolean(optionInputs.length && selected.length === optionInputs.length);
  all.indeterminate = selected.length > 0 && selected.length < optionInputs.length;
}

function setPickerValues(picker, values) {
  const selected = new Set((values || []).map(String));
  for (const input of picker.querySelectorAll(".multi-picker-option input")) input.checked = selected.has(input.value);
  updatePickerState(picker);
}

function renderMultiPicker(picker, items, config) {
  const previous = new Set(pickerValues(picker));
  picker._pickerItems = items;
  picker._pickerLabel = config.label;
  const groups = new Map();
  for (const item of items) {
    const group = config.group(item) || "";
    if (!groups.has(group)) groups.set(group, []);
    groups.get(group).push(item);
  }
  const orderedGroups = [...groups].sort(([groupA], [groupB]) => config.groupOrder(groupA) - config.groupOrder(groupB));
  picker.querySelector(".multi-picker-options").innerHTML = orderedGroups.length ? orderedGroups.map(([group, groupItems]) => `
    <section class="multi-picker-group">
      <div class="multi-picker-group-title"><span>${escapeHtml(config.groupLabel(group))} <small>(${groupItems.length})</small></span><button type="button" data-picker-group-toggle="${escapeHtml(group)}">Selecionar grupo</button></div>
      ${groupItems.sort(config.compare || ((a, b) => config.label(a).localeCompare(config.label(b), "pt-BR"))).map(item => {
        const label = config.label(item);
        const detail = config.detail(item);
        return `<label class="multi-picker-option" data-picker-search="${escapeHtml(searchKey(`${label} ${detail} ${config.groupLabel(group)}`))}"><input type="checkbox" value="${escapeHtml(item.id)}" data-picker-group="${escapeHtml(group)}"><span><strong>${escapeHtml(label)}</strong><small>${escapeHtml(detail)}</small></span></label>`;
      }).join("")}
    </section>`).join("") : '<div class="multi-picker-empty">Nenhuma opção disponível.</div>';
  setPickerValues(picker, items.filter(item => previous.has(String(item.id))).map(item => item.id));
  picker.querySelector(".multi-picker-search").value = "";
}

function renderClientPicker(selector, clients) {
  renderMultiPicker($(selector), clients, {
    label: clientReference,
    detail: client => `${cnpjLabel(client.cnpj)} • ${companyTypeLabel(client.taxRegime)}`,
    compare: (a, b) => String(a.name).localeCompare(String(b.name), "pt-BR"),
    group: client => client.taxRegime || "",
    groupLabel: group => companyTypeLabel(group),
    groupOrder: group => COMPANY_TYPE_ORDER.has(group) ? COMPANY_TYPE_ORDER.get(group) : COMPANY_TYPES.length
  });
}

function renderUserPicker(selector, users) {
  const sectorOrder = new Map(["DP", "FISCAL/CONTABIL", "GESTAO", "ADMIN"].map((sector, index) => [sector, index]));
  renderMultiPicker($(selector), users, {
    label: user => user.name,
    detail: user => `${user.sector} • ${user.role}`,
    group: user => user.sector || "",
    groupLabel: group => group || "SEM SETOR",
    groupOrder: group => sectorOrder.has(group) ? sectorOrder.get(group) : sectorOrder.size
  });
}

function initializeMultiPickers() {
  for (const picker of $$(".multi-picker")) {
    const trigger = picker.querySelector(".multi-picker-trigger");
    const menu = picker.querySelector(".multi-picker-menu");
    trigger.addEventListener("click", event => {
      event.stopPropagation();
      const willOpen = menu.hidden;
      for (const other of $$(".multi-picker")) {
        other.classList.remove("open");
        other.querySelector(".multi-picker-menu").hidden = true;
        other.querySelector(".multi-picker-trigger").setAttribute("aria-expanded", "false");
      }
      menu.hidden = !willOpen;
      picker.classList.toggle("open", willOpen);
      trigger.setAttribute("aria-expanded", String(willOpen));
      if (willOpen) picker.querySelector(".multi-picker-search").focus();
    });
    menu.addEventListener("click", event => {
      event.stopPropagation();
      const groupButton = event.target.closest("button[data-picker-group-toggle]");
      if (!groupButton) return;
      const inputs = [...picker.querySelectorAll(`.multi-picker-option input[data-picker-group="${CSS.escape(groupButton.dataset.pickerGroupToggle)}"]`)];
      const select = inputs.some(input => !input.checked);
      inputs.forEach(input => { input.checked = select; });
      updatePickerState(picker);
    });
    picker.querySelector(".multi-picker-options").addEventListener("change", event => {
      if (event.target.matches(".multi-picker-option input")) updatePickerState(picker);
    });
    picker.querySelector(".multi-picker-all input").addEventListener("change", event => {
      picker.querySelectorAll(".multi-picker-option input").forEach(input => { input.checked = event.target.checked; });
      updatePickerState(picker);
    });
    picker.querySelector(".multi-picker-search").addEventListener("input", event => {
      const query = searchKey(event.target.value);
      for (const option of picker.querySelectorAll(".multi-picker-option")) option.hidden = Boolean(query && !option.dataset.pickerSearch.includes(query));
      for (const group of picker.querySelectorAll(".multi-picker-group")) group.hidden = ![...group.querySelectorAll(".multi-picker-option")].some(option => !option.hidden);
    });
  }
  document.addEventListener("click", () => {
    for (const picker of $$(".multi-picker")) {
      picker.classList.remove("open");
      picker.querySelector(".multi-picker-menu").hidden = true;
      picker.querySelector(".multi-picker-trigger").setAttribute("aria-expanded", "false");
    }
  });
}

function populateForms() {
  const activeClients = state.clients.filter(item => item.active);
  renderClientPicker("#activity-client-picker", activeClients);
  renderClientPicker("#obligation-client-picker", activeClients);
  // Gestão também executa atividades, então entra na lista de responsáveis.
  const activityUsers = state.user.role === "COLABORADOR"
    ? [state.user]
    : state.team.filter(item => item.active && ["COLABORADOR", "GESTOR"].includes(item.role));
  renderUserPicker("#activity-user-picker", activityUsers);
  renderUserPicker("#obligation-user-picker", state.team.filter(item => item.active));
  if (state.user.role === "COLABORADOR") setPickerValues($("#activity-user-picker"), [state.user.id]);
  const obligationSelect = $('#obligation-form select[name="status"]');
  obligationSelect.innerHTML = state.obligationStatus.map(status => `<option>${escapeHtml(status)}</option>`).join("");
  fillSelect($('#time-adjust-form select[name="userId"]'), state.team.filter(item => item.active), "Selecione o colaborador");
  fillSelect($("#time-user-filter"), state.team.filter(item => item.active), "Toda a equipe");
  fillSelect($("#export-user"), state.team.filter(item => item.active), "Todos os usuários");
  fillSelect($("#bulk-responsible"), state.team.filter(item => item.active), "Responsável (não alterar)");
  $("#bulk-status").innerHTML = '<option value="">Status (não alterar)</option>'
    + state.obligationStatus.map(status => `<option>${escapeHtml(status)}</option>`).join("");
  if (["ADMIN", "GESTOR"].includes(state.user.role)) {
    const clients = [...activeClients].sort((a, b) => a.name.localeCompare(b.name, "pt-BR"));
    const team = state.team.filter(item => item.active);
    fillSelect($('#attendance-form select[name="clientId"]'), clients, "Selecione a empresa", "id", clientReference);
    fillSelect($("#attendance-history-client"), clients, "Todos os clientes", "id", clientReference);
    fillSelect($("#attendance-history-user"), team, "Todos os funcionários");
    fillSelect($("#attendance-metrics-user"), team, "Todos os funcionários");
    fillSelect($('#attendance-convert-form select[name="responsibleId"]'), team.filter(item => item.sector === "DP"), "Selecione no DP");
    populateDemandUsers();
  }
}

async function loadBase() {
  const [clients, team, activities, obligations] = await Promise.all([
    api("/api/clients?all=1"), api("/api/team"), api("/api/activities"), api("/api/obligations")
  ]);
  state.clients = clients.items;
  state.team = team.items;
  state.activities = activities.items;
  state.obligations = obligations.items;
  if (["ADMIN", "GESTOR"].includes(state.user.role)) state.users = (await api("/api/users")).items;
  if (["ADMIN", "GESTOR"].includes(state.user.role)) {
    state.obligationCatalog = (await api("/api/obligation-catalog")).items;
    renderObligationCatalog();
    await loadStepTemplates().catch(() => {});
    await loadRecurrences().catch(() => {});
  } else state.obligationCatalog = [];
  populateForms();
  renderClients();
  renderActivities();
  renderObligations();
  renderUsers();
}

function catalogNotes(item) {
  return [`Título original: ${item.title}`, `Departamento de origem: ${item.departmentGroup}`,
    ...item.sources.map(source => `Origem: ${source.sourceId}\nPeriodicidade original: ${source.periodicity || "Não preenchida"}${source.notes ? `\nObservação original: ${source.notes}` : ""}${source.warnings.length ? `\nConferir: ${source.warnings.join(" ")}` : ""}`)
  ].join("\n\n");
}

function renderObligationCatalog() {
  const department = $("#catalog-department").value;
  const normalize = value => String(value).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
  const query = normalize($("#catalog-search").value.trim());
  const items = state.obligationCatalog.filter(item => (!department || item.departmentGroup === department) && normalize(item.title).includes(query));
  const select = $("#catalog-item");
  const previous = select.value;
  select.innerHTML = '<option value="">Selecione uma obrigação do catálogo</option>' + ["DP", "FISCAL/CONTABIL", "ADM_FIN"].map(group => {
    const rows = items.filter(item => item.departmentGroup === group).sort((a, b) => a.title.localeCompare(b.title, "pt-BR"));
    return rows.length ? `<optgroup label="${escapeHtml(group)}">${rows.map(item => `<option value="${escapeHtml(item.id)}">${escapeHtml(item.title)}</option>`).join("")}</optgroup>` : "";
  }).join("");
  if (items.some(item => item.id === previous)) select.value = previous;
  $("#catalog-count").textContent = `${items.length} de ${state.obligationCatalog.length} modelos`;
  showCatalogDetail();
}

function showCatalogDetail() {
  const item = state.obligationCatalog.find(item => item.id === $("#catalog-item").value);
  $("#catalog-detail").textContent = item ? catalogNotes(item) : "";
  $("#catalog-prepare").disabled = !item;
}

function prepareCatalogDistribution() {
  const item = state.obligationCatalog.find(item => item.id === $("#catalog-item").value);
  if (!item) return;
  const form = $("#obligation-form");
  if (!confirm("Preparar esta obrigação no formulário abaixo? O preenchimento atual será substituído. Nada será salvo até clicar em Salvar obrigação.")) return;
  resetEdit(form);
  form.elements.type.value = item.title.length > 120 ? item.title.slice(0, 117) + "..." : item.title;
  form.elements.notes.value = catalogNotes(item).slice(0, 800);
  form.elements.period.value = "";
  form.elements.dueDate.value = "";
  form.elements.status.value = "PENDENTE";
  form.scrollIntoView({ behavior: "smooth", block: "start" });
  form.elements.period.focus({ preventScroll: true });
}

const ATTENDANCE_STATUS_LABEL = {
  PENDENTE: "Pendente", "EM ATENDIMENTO": "Em atendimento",
  FINALIZADO: "Concluído", DESCONSIDERADO: "Desconsiderado"
};

function phoneLabel(value) {
  const digits = String(value || "").replace(/\D/g, "");
  if (!digits) return "—";
  const local = digits.length > 11 && digits.startsWith("55") ? digits.slice(2) : digits;
  if (local.length === 11) return `(${local.slice(0, 2)}) ${local.slice(2, 7)}-${local.slice(7)}`;
  if (local.length === 10) return `(${local.slice(0, 2)}) ${local.slice(2, 6)}-${local.slice(6)}`;
  return digits;
}

function initials(value) {
  const parts = String(value || "").trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return "--";
  return (parts[0][0] + (parts.at(-1)[0] || "")).toLocaleUpperCase("pt-BR");
}

function shortTime(value) {
  if (!value) return "";
  const date = new Date(value);
  const today = new Date();
  const sameDay = date.toDateString() === today.toDateString();
  return sameDay
    ? date.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })
    : date.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" });
}

function attendanceQuery(mode) {
  const params = new URLSearchParams();
  if (mode === "history") {
    const fields = { from: "attendance-history-from", to: "attendance-history-to", userId: "attendance-history-user", status: "attendance-history-status", clientId: "attendance-history-client" };
    for (const [key, id] of Object.entries(fields)) if ($(`#${id}`).value) params.set(key, $(`#${id}`).value);
  } else if (mode === "metrics") {
    const range = metricsRange();
    if (range.from) params.set("from", range.from);
    if (range.to) params.set("to", range.to);
    if ($("#attendance-metrics-user").value) params.set("userId", $("#attendance-metrics-user").value);
  }
  return params;
}

function metricsRange() {
  const mode = $("#attendance-metrics-range").value;
  const iso = date => new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
  const today = new Date();
  if (mode === "custom") return { from: $("#attendance-metrics-from").value, to: $("#attendance-metrics-to").value, label: "Período personalizado" };
  if (mode === "week") {
    const first = new Date(today);
    first.setDate(today.getDate() - ((today.getDay() + 6) % 7));
    const last = new Date(first);
    last.setDate(first.getDate() + 6);
    return { from: iso(first), to: iso(last), label: `Semana atual (${iso(first).slice(8)}/${iso(first).slice(5, 7)} - ${iso(last).slice(8)}/${iso(last).slice(5, 7)})` };
  }
  const offset = mode === "previous-month" ? -1 : 0;
  const first = new Date(today.getFullYear(), today.getMonth() + offset, 1);
  const last = new Date(today.getFullYear(), today.getMonth() + offset + 1, 0);
  return { from: iso(first), to: iso(last), label: first.toLocaleDateString("pt-BR", { month: "long", year: "numeric" }) };
}

// ---------------------------------------------------------------- Central de atendimento
function renderIntegrationPill(integration) {
  const pill = $("#whatsapp-integration-status");
  state.chat.integration = integration;
  if (!pill) return;
  pill.className = `integration-pill ${integration.connected ? "online" : integration.configured ? "offline" : ""}`;
  const detail = integration.displayPhoneNumber ? ` · ${integration.displayPhoneNumber}` : "";
  pill.innerHTML = `<span><strong>${escapeHtml(integration.providerLabel)}</strong>${escapeHtml(detail)} — ${escapeHtml(integration.message)}</span>`;
}

function renderChatList() {
  const list = $("#chat-list");
  const items = state.chat.items;
  for (const [tab, count] of Object.entries(state.chat.counts)) {
    const badge = $(`#chat-tabs [data-count="${tab}"]`);
    if (badge) badge.textContent = count;
  }
  const navBadge = $('[data-badge="attendance-inbox"]');
  if (navBadge) {
    navBadge.textContent = state.chat.counts.pending;
    navBadge.hidden = !state.chat.counts.pending;
  }
  if (!items.length) {
    list.innerHTML = '<div class="empty-state">Nenhuma conversa nesta aba.</div>';
    return;
  }
  list.innerHTML = items.map(item => {
    const title = item.clientName || item.contactName || phoneLabel(item.contactPhone) || "Contato sem nome";
    const subtitle = item.preview || item.subject || phoneLabel(item.contactPhone);
    return `<button type="button" class="chat-item ${item.id === state.chat.conversationId ? "active" : ""}" data-conversation="${escapeHtml(item.id)}">
      <span class="chat-avatar">${escapeHtml(initials(title))}</span>
      <span class="chat-item-body"><strong>${escapeHtml(title)}</strong><small>${escapeHtml(subtitle)}</small></span>
      <span class="chat-item-meta"><time>${escapeHtml(shortTime(item.lastMessageAt))}</time>${item.unread ? `<span class="chat-unread">${item.unread}</span>` : ""}</span>
    </button>`;
  }).join("");
}

function chatHeaderActions(item) {
  const buttons = [];
  if (item.status === "PENDENTE") buttons.push(`<button class="table-button" data-action="start-attendance" data-id="${item.id}">Assumir</button>`);
  if (["PENDENTE", "EM ATENDIMENTO"].includes(item.status)) buttons.push(`<button class="table-button" data-action="finish-attendance" data-id="${item.id}">Encerrar</button>`);
  if (!item.clientId) buttons.push(`<button class="table-button" data-action="link-attendance-client" data-id="${item.id}">Vincular cliente</button>`);
  buttons.push(`<button class="table-button" data-action="convert-attendance" data-id="${item.id}">Enviar ao DP</button>`);
  return buttons.join("");
}

function renderThread(item) {
  $("#chat-empty").hidden = true;
  $("#chat-header").hidden = false;
  $("#chat-thread").hidden = false;
  const client = state.clients.find(entry => entry.id === item.clientId);
  const title = client?.name || item.contactName || phoneLabel(item.contactPhone) || "Contato";
  $("#chat-avatar").textContent = initials(title);
  $("#chat-contact-name").textContent = title;
  $("#chat-contact-detail").textContent = [
    phoneLabel(item.contactPhone || item.waid),
    ATTENDANCE_STATUS_LABEL[item.status] || item.status,
    item.assignedUserId ? `Atendente: ${userName(item.assignedUserId)}` : "Sem atendente"
  ].filter(Boolean).join(" · ");
  $("#chat-header-actions").innerHTML = chatHeaderActions(item);

  const thread = $("#chat-thread");
  const messages = item.messages || [];
  if (!messages.length) {
    thread.innerHTML = '<div class="empty-state">Nenhuma mensagem trocada. O texto da solicitação aparece no detalhe do atendimento.</div>';
  } else {
    let lastDay = "";
    thread.innerHTML = messages.map(message => {
      const day = new Date(message.at).toLocaleDateString("pt-BR");
      const separator = day !== lastDay ? `<div class="chat-day">${escapeHtml(day)}</div>` : "";
      lastDay = day;
      const media = message.mediaId
        ? `<a class="media-link" href="/api/whatsapp/conversations/${encodeURIComponent(item.id)}/media/${encodeURIComponent(message.id)}" target="_blank" rel="noopener">Abrir ${escapeHtml(message.mediaName || message.type)}</a>`
        : "";
      const author = message.direction === "OUT" ? userName(message.userId) : "";
      return `${separator}<article class="chat-bubble ${message.direction === "OUT" ? "outbound" : "inbound"} ${message.status === "FALHOU" ? "failed" : ""}">
        <p>${escapeHtml(message.text || `[${message.type}]`)}</p>${media}
        <footer>${escapeHtml([author, new Date(message.at).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }), message.direction === "OUT" ? message.status : ""].filter(Boolean).join(" · "))}${message.error ? ` · ${escapeHtml(message.error)}` : ""}</footer>
      </article>`;
    }).join("");
    thread.scrollTop = thread.scrollHeight;
  }

  const composer = $("#chat-composer");
  const canSend = item.canSend && !["FINALIZADO", "DESCONSIDERADO"].includes(item.status);
  composer.hidden = !item.waid;
  const warning = $("#chat-window-warning");
  if (!item.waid) return;
  $("#chat-send").disabled = !canSend;
  $("#chat-message").disabled = !canSend;
  if (!state.chat.integration?.canSend) {
    warning.hidden = false;
    warning.textContent = "Responder pelo sistema exige a integração oficial da Meta configurada em Configurar WhatsApp.";
  } else if (["FINALIZADO", "DESCONSIDERADO"].includes(item.status)) {
    warning.hidden = false;
    warning.textContent = "Atendimento encerrado. Uma nova mensagem do cliente abre outro atendimento.";
  } else if (!item.windowOpen) {
    warning.hidden = false;
    warning.textContent = "Passaram-se mais de 24 horas desde a última mensagem do cliente. Nesse caso a Meta só aceita modelos aprovados.";
  } else warning.hidden = true;
}

async function openConversation(id) {
  state.chat.conversationId = id;
  const result = await api(`/api/whatsapp/conversations/${encodeURIComponent(id)}`);
  state.chat.thread = result.item;
  renderThread(result.item);
  renderChatList();
  if (result.item.unread) {
    await api(`/api/whatsapp/conversations/${encodeURIComponent(id)}/read`, { method: "POST", body: {} }).catch(() => {});
  }
}

async function loadAttendanceInbox() {
  const params = new URLSearchParams({ tab: state.chat.tab });
  if (state.chat.search) params.set("q", state.chat.search);
  const result = await api(`/api/whatsapp/conversations?${params}`);
  state.chat.items = result.items;
  state.chat.counts = result.counts;
  renderIntegrationPill(result.integration);
  renderChatList();
  if (state.chat.conversationId && result.items.some(item => item.id === state.chat.conversationId)) {
    await openConversation(state.chat.conversationId);
  } else if (!result.items.some(item => item.id === state.chat.conversationId)) {
    state.chat.conversationId = "";
    state.chat.thread = null;
    $("#chat-empty").hidden = false;
    $("#chat-header").hidden = true;
    $("#chat-thread").hidden = true;
    $("#chat-composer").hidden = true;
  }
}

// ---------------------------------------------------------------- Histórico
function historyChips() {
  const chips = [];
  const push = (key, label, value) => { if (value) chips.push({ key, label, value }); };
  push("attendance-history-from", "De", $("#attendance-history-from").value);
  push("attendance-history-to", "Até", $("#attendance-history-to").value);
  const userSelect = $("#attendance-history-user");
  push("attendance-history-user", "Funcionário", userSelect.value ? userSelect.selectedOptions[0].textContent : "");
  push("attendance-history-status", "Status", $("#attendance-history-status").value);
  const clientSelect = $("#attendance-history-client");
  push("attendance-history-client", "Cliente", clientSelect.value ? clientSelect.selectedOptions[0].textContent : "");
  $("#attendance-history-chips").innerHTML = chips.length
    ? chips.map(chip => `<span class="filter-chip">${escapeHtml(chip.label)}: ${escapeHtml(chip.value)}<button type="button" data-clear-filter="${chip.key}" aria-label="Remover filtro">×</button></span>`).join("")
    : '<span class="filter-chip">Todos os atendimentos</span>';
}

async function loadAttendanceHistory() {
  const params = attendanceQuery("history");
  const result = await api(`/api/attendances?${params}`);
  state.attendances = result.items;
  historyChips();
  $("#attendance-history-export").href = `/api/export/attendances?${params}`;
  $("#attendance-history-count").textContent = `Atendimentos (${result.items.length})`;
  $("#attendance-history-table").innerHTML = result.items.length ? result.items.map(item => `<tr>
    <td>${escapeHtml(item.clientId ? clientName(item.clientId) : "—")}</td>
    <td>${escapeHtml(item.contactName || phoneLabel(item.contactPhone))}</td>
    <td><strong>${escapeHtml(item.subject || "—")}</strong></td>
    <td>${statusBadge(item.status)}</td>
    <td>${escapeHtml(userName(item.assignedUserId))}</td>
    <td>${dateTimeLabel(item.createdAt)}</td>
    <td>${dateTimeLabel(item.startedAt)}</td>
    <td>${dateTimeLabel(item.finishedAt)}</td>
    <td>${minutesLabel(item.totalMinutes)}</td>
    <td><button class="row-icon-button" type="button" data-action="detail-attendance" data-id="${item.id}" title="Ver dados"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5c-5 0-9 4.5-9 7s4 7 9 7 9-4.5 9-7-4-7-9-7zm0 11a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm0-2a2 2 0 1 0 0-4 2 2 0 0 0 0 4z"/></svg></button></td>
  </tr>`).join("") : '<tr><td colspan="10"><div class="empty-state">Nenhum atendimento encontrado com este filtro.</div></td></tr>';
}

function openAttendanceDetail(item) {
  if (!item) return;
  $("#attendance-detail-title").textContent = item.subject || "Atendimento";
  $("#attendance-detail-subtitle").textContent = [item.clientId ? clientName(item.clientId) : "Sem cliente vinculado", phoneLabel(item.contactPhone)].join(" · ");
  const rows = [
    ["Contato", item.contactName || "—"], ["Telefone", phoneLabel(item.contactPhone)],
    ["Situação", ATTENDANCE_STATUS_LABEL[item.status] || item.status], ["Atendido por", userName(item.assignedUserId)],
    ["Recebido em", dateTimeLabel(item.createdAt)], ["Início", dateTimeLabel(item.startedAt)],
    ["Finalização", dateTimeLabel(item.finishedAt)], ["Tempo total", minutesLabel(item.totalMinutes)],
    ["Origem", item.source || "—"], ["Mensagens trocadas", String((item.messages || []).length)]
  ];
  $("#attendance-detail-body").innerHTML = `<dl class="detail-grid">${rows.map(([label, value]) => `<div><dt>${escapeHtml(label)}</dt><dd>${escapeHtml(value)}</dd></div>`).join("")}</dl>
    ${item.message ? `<p class="panel-note"><strong>Mensagem:</strong> ${escapeHtml(item.message)}</p>` : ""}
    ${item.closingNotes ? `<p class="panel-note"><strong>Observações finais:</strong> ${escapeHtml(item.closingNotes)}</p>` : ""}
    ${item.generatedItems?.length ? `<p class="panel-note"><strong>Gerou no DP:</strong> ${escapeHtml(item.generatedItems.map(entry => entry.kind).join(", "))}</p>` : ""}`;
  $("#attendance-detail-dialog").showModal();
}

// ---------------------------------------------------------------- Métricas
function rankingCard(title, rows, valueClass, formatter) {
  const body = rows.length
    ? rows.map(row => `<div class="ranking-row"><span class="ranking-avatar">${escapeHtml(initials(row.name))}</span><span>${escapeHtml(row.name)}</span><span class="ranking-value ${valueClass}">${escapeHtml(formatter(row))}</span></div>`).join("")
    : '<p class="ranking-empty">Sem dados no período.</p>';
  return `<article class="ranking-card"><header>${escapeHtml(title)}</header>${body}</article>`;
}

async function loadAttendanceMetrics() {
  const params = attendanceQuery("metrics");
  const result = await api(`/api/attendance-metrics?${params}`);
  state.attendanceMetrics = result;
  $("#attendance-metrics-range-label").textContent = metricsRange().label;
  $("#attendance-metrics-export").href = `/api/export/attendances?${params}`;
  const employees = result.employees.filter(item => item.userId);
  const byAverage = employees.filter(item => item.averageMinutes > 0).sort((a, b) => a.averageMinutes - b.averageMinutes).slice(0, 3);
  const byOpen = employees.map(item => ({ ...item, open: item.total - item.completed - item.disregarded }))
    .filter(item => item.open > 0).sort((a, b) => b.open - a.open).slice(0, 3);
  const byCompleted = employees.filter(item => item.completed > 0).sort((a, b) => b.completed - a.completed).slice(0, 3);
  $("#attendance-ranking").innerHTML = [
    rankingCard("Menor tempo médio de atendimento", byAverage, "time", row => minutesLabel(row.averageMinutes)),
    rankingCard("Mais atendimentos abertos", byOpen, "open", row => String(row.open).padStart(2, "0")),
    rankingCard("Mais atendimentos concluídos", byCompleted, "done", row => String(row.completed).padStart(2, "0"))
  ].join("");
  const cards = [["Atendimentos", String(result.metrics.total)], ["Em atendimento", String(result.metrics.inProgress)],
    ["Concluídos", String(result.metrics.completed)], ["Tempo médio", minutesLabel(result.metrics.averageMinutes)]];
  $("#attendance-metric-cards").innerHTML = cards.map(([label, value]) => `<article class="metric-card"><small>${escapeHtml(label)}</small><strong>${escapeHtml(value)}</strong></article>`).join("");
  $("#attendance-metrics-count").textContent = `Funcionários (${result.employees.length})`;
  $("#attendance-metrics-table").innerHTML = result.employees.length ? result.employees.map(item => {
    const open = item.total - item.completed - item.disregarded;
    return `<tr><td><strong>${escapeHtml(item.name)}</strong></td><td>${minutesLabel(item.averageMinutes)}</td>
      <td>${String(open).padStart(2, "0")}</td><td>${String(item.initiated).padStart(2, "0")}</td>
      <td>${String(item.completed).padStart(2, "0")}</td><td>${String(item.disregarded).padStart(2, "0")}</td>
      <td>${minutesLabel(item.totalMinutes)}</td></tr>`;
  }).join("") : '<tr><td colspan="7"><div class="empty-state">Nenhum atendimento no período.</div></td></tr>';
}

// ---------------------------------------------------------------- Configuração da integração
async function openWhatsAppSettings() {
  const integration = await api("/api/whatsapp-integration");
  const form = $("#whatsapp-settings-form");
  form.elements.provider.value = integration.provider || "META_CLOUD";
  form.elements.name.value = integration.name || "Atendimento WhatsApp";
  form.elements.phoneNumberId.value = integration.phoneNumberId || "";
  form.elements.businessAccountId.value = integration.businessAccountId || "";
  form.elements.publicWebhookUrl.value = integration.publicWebhookUrl || "";
  form.elements.accessToken.value = "";
  form.elements.appSecret.value = "";
  renderWhatsAppReadout(integration, { verifyToken: integration.verifyToken });
  updateWhatsAppFields();
  $("#whatsapp-settings-dialog").showModal();
}

function updateWhatsAppFields() {
  const meta = $("#whatsapp-provider").value === "META_CLOUD";
  $$("#whatsapp-settings-form .meta-fields > *").forEach(element => { element.hidden = !meta; });
  $("#whatsapp-test").hidden = !meta;
  $("#whatsapp-key").hidden = meta;
}

function renderWhatsAppReadout(integration, extra = {}) {
  const base = integration.publicWebhookUrl || `${location.origin}${integration.webhookPath}`;
  $("#whatsapp-settings-state").textContent = integration.message || "";
  $("#whatsapp-readout").innerHTML = `<dl>
    <dt>Situação</dt><dd>${escapeHtml(integration.providerLabel)} — ${integration.connected ? "conectado" : "não conectado"}${integration.displayPhoneNumber ? ` (${escapeHtml(integration.displayPhoneNumber)})` : ""}</dd>
    <dt>URL de retorno de chamada (Callback URL)</dt><dd><code>${escapeHtml(base)}</code></dd>
    <dt>Token de verificação</dt><dd><code>${escapeHtml(extra.verifyToken || "gerado ao salvar; aparece uma única vez")}</code></dd>
    ${extra.key ? `<dt>Chave do parceiro</dt><dd><code>${escapeHtml(extra.key)}</code> — copie agora, ela não será exibida de novo.</dd>` : ""}
    <dt>Endpoint do parceiro</dt><dd><code>${escapeHtml(`${location.origin}${integration.partnerEndpoint}`)}</code></dd>
    <dt>Última mensagem recebida</dt><dd>${escapeHtml(dateTimeLabel(integration.lastReceivedAt))}</dd>
    <dt>Última resposta enviada</dt><dd>${escapeHtml(dateTimeLabel(integration.lastSentAt))}</dd>
    ${integration.lastError ? `<dt>Último erro</dt><dd class="danger-text">${escapeHtml(integration.lastError)}</dd>` : ""}
  </dl>`;
}


// ---------------------------------------------------------------- Painel mensal de obrigações
function panelBar(row) {
  return `<div class="status-row">
    <span title="${escapeHtml(row.label)}">${escapeHtml(row.label)}</span>
    <span class="status-track"><span class="status-fill" style="width:${row.percent}%"></span></span>
    <span>${row.percent}%</span>
    <small class="cell-subtitle">${row.concluded}/${row.total} concluídas${row.late ? ` · ${row.late} atrasada(s)` : ""}</small>
  </div>`;
}

function panelRows() {
  const panel = state.obligationPanel;
  if (!panel) return [];
  const filtro = $("#panel-status").value;
  const busca = searchKey($("#panel-search").value.trim());
  return panel.items.filter(item => {
    if (filtro === "pendentes" && item.concluded) return false;
    if (filtro === "atrasadas" && !item.late) return false;
    if (filtro === "concluidas" && !item.concluded) return false;
    if (!busca) return true;
    return searchKey(`${item.clientName} ${item.type} ${item.responsibleName}`).includes(busca);
  });
}

function renderObligationPanel() {
  const panel = state.obligationPanel;
  if (!panel) return;
  const cards = [
    ["Obrigações", String(panel.summary.total)],
    ["Concluídas", `${panel.summary.concluded} (${panel.summary.percent}%)`],
    ["Pendentes", String(panel.summary.pending)],
    ["Atrasadas", String(panel.summary.late)]
  ];
  $("#panel-metrics").innerHTML = cards.map(([label, value]) => `<article class="metric-card"><small>${escapeHtml(label)}</small><strong>${escapeHtml(value)}</strong></article>`).join("");
  $("#panel-by-responsible").innerHTML = panel.byResponsible.length ? panel.byResponsible.map(panelBar).join("") : '<div class="empty-state">Sem obrigações nesta competência.</div>';
  $("#panel-by-type").innerHTML = panel.byType.length ? panel.byType.map(panelBar).join("") : '<div class="empty-state">Sem obrigações nesta competência.</div>';

  const rows = panelRows();
  $("#panel-count").textContent = `Obrigações (${rows.length})`;
  $("#panel-table").innerHTML = rows.length ? rows.map(item => {
    const situacao = item.concluded ? '<span class="badge">Concluída</span>'
      : item.late ? '<span class="badge danger">Atrasada</span>'
      : '<span class="badge warning">Pendente</span>';
    const etapas = item.progress.total
      ? `<span class="completion-value">${item.progress.done}/${item.progress.total}</span><small class="cell-subtitle">${escapeHtml(item.progress.current || "Todas concluídas")}</small>`
      : "—";
    return `<tr>
      <td>${dateLabel(item.dueDate)}</td>
      <td><strong>${escapeHtml(item.clientName)}</strong><small class="cell-subtitle">${escapeHtml(item.clientCode || item.taxRegime || "")}</small></td>
      <td>${escapeHtml(item.type)}</td>
      <td>${escapeHtml(item.responsibleName)}</td>
      <td>${statusBadge(item.status)}</td>
      <td>${etapas}</td>
      <td>${situacao}</td>
      <td class="actions">${item.progress.total ? `<button class="table-button" data-action="open-steps" data-id="${item.id}">Etapas</button>` : ""}</td>
    </tr>`;
  }).join("") : '<tr><td colspan="8"><div class="empty-state">Nenhuma obrigação para este filtro.</div></td></tr>';
}

async function loadObligationsPanel() {
  const period = $("#panel-period").value || todayValue().slice(0, 7);
  $("#panel-period").value = period;
  const result = await api(`/api/obligations-panel?period=${encodeURIComponent(period)}`);
  state.obligationPanel = result;
  $("#panel-export").href = `/api/export/movimentacoes?type=obrigacoes`;
  renderObligationPanel();
}

// ---------------------------------------------------------------- Passo a passo das obrigações
async function loadStepTemplates() {
  const result = await api("/api/obligation-steps");
  state.stepTemplates = result.items;
  const corpo = $("#step-template-table");
  if (!corpo) return;
  $("#step-template-count").textContent = `${result.items.length} obrigação(ões) com etapas`;
  corpo.innerHTML = result.items.length ? result.items.map(item => `<tr>
    <td><strong>${escapeHtml(item.name)}</strong></td>
    <td>${escapeHtml(item.steps.join(" › "))}</td>
    <td class="actions"><button class="table-button" data-action="edit-step-template" data-id="${item.id}">Editar</button><button class="table-button danger" data-action="delete-step-template" data-id="${item.id}">Excluir</button></td>
  </tr>`).join("") : '<tr><td colspan="3"><div class="empty-state">Nenhum passo a passo cadastrado.</div></td></tr>';
}


// ---------------------------------------------------------------- Periodicidade das obrigações
function fillRecurrenceSelects() {
  const opcoes = state.recurrences;
  const campo = $("#obligation-recurrence");
  const anterior = campo.value;
  campo.innerHTML = '<option value="">Sem periodicidade</option>' + opcoes.map(nome => `<option>${escapeHtml(nome)}</option>`).join("");
  if (opcoes.includes(anterior)) campo.value = anterior;
  const lote = $("#bulk-recurrence");
  lote.innerHTML = '<option value="">Periodicidade (não alterar)</option>' + opcoes.map(nome => `<option>${escapeHtml(nome)}</option>`).join("");
}

function renderRecurrenceList() {
  const lista = $("#recurrence-list");
  if (!lista) return;
  lista.innerHTML = state.recurrences.map(nome => `<span class="recurrence-chip">${escapeHtml(nome)}<button type="button" data-action="delete-recurrence" data-id="${escapeHtml(nome)}" title="Excluir periodicidade">×</button></span>`).join("")
    || '<span class="panel-note">Nenhuma periodicidade cadastrada.</span>';
}

async function loadRecurrences() {
  state.recurrences = (await api("/api/recurrences")).items;
  fillRecurrenceSelects();
  renderRecurrenceList();
}

// ---------------------------------------------------------------- Seleção em lote das obrigações
function selectedObligations() {
  const existentes = new Set(state.obligations.map(item => item.id));
  for (const id of [...state.obligationSelection]) if (!existentes.has(id)) state.obligationSelection.delete(id);
  return [...state.obligationSelection];
}

function updateBulkBar() {
  const barra = $("#obligation-bulk-bar");
  if (!barra) return;
  const selecionadas = selectedObligations();
  const gestor = ["ADMIN", "GESTOR"].includes(state.user?.role);
  barra.hidden = !gestor || selecionadas.length === 0;
  $("#obligation-bulk-count").textContent = `${selecionadas.length} selecionada(s)`;
  const todas = $("#obligations-select-all");
  if (todas) {
    const total = state.obligations.length;
    todas.checked = total > 0 && selecionadas.length === total;
    todas.indeterminate = selecionadas.length > 0 && selecionadas.length < total;
  }
}

async function applyBulk(corpo, mensagem) {
  const ids = selectedObligations();
  if (!ids.length) return;
  const result = await api("/api/obligations/bulk", { method: "POST", body: { ids, ...corpo } });
  state.obligationSelection.clear();
  toast(`${mensagem}: ${result.affected} obrigação(ões).`);
  await loadBase();
  if ($("#view-obligations-panel").classList.contains("active")) await loadObligationsPanel();
}

function obligationStepsCell(item) {
  const steps = item.steps || [];
  if (!steps.length) return "—";
  const done = steps.filter(step => step.done).length;
  const pendente = steps.find(step => !step.done);
  return `<button class="table-button" data-action="open-steps" data-id="${item.id}">${done}/${steps.length}</button><small class="cell-subtitle">${escapeHtml(pendente ? pendente.name : "Todas concluídas")}</small>`;
}

function obligationById(id) {
  return state.obligations.find(item => item.id === id)
    || state.obligationPanel?.items.find(item => item.id === id);
}

function renderStepDialog(item) {
  const steps = item.steps || [];
  const done = steps.filter(step => step.done).length;
  const faltam = steps.length - done;
  const atual = steps.find(step => !step.done);
  $("#obligation-steps-title").textContent = item.type || "Etapas";
  $("#obligation-steps-subtitle").textContent = `${clientName(item.clientId)} · ${item.period || ""} · ${done}/${steps.length} concluídas`;
  const resumo = $("#obligation-steps-progress");
  if (resumo) {
    const percentual = steps.length ? Math.round((done / steps.length) * 100) : 0;
    resumo.innerHTML = steps.length ? `<div class="status-track"><span class="status-fill" style="width:${percentual}%"></span></div>
      <p>${faltam ? `<strong>Parou em:</strong> ${escapeHtml(atual.name)} · faltam ${faltam} etapa(s)` : "<strong>Todas as etapas concluídas.</strong>"}</p>` : "";
  }
  $("#obligation-steps-list").innerHTML = steps.length ? steps.map(step => `<label class="step-item ${step.done ? "done" : ""}">
    <input type="checkbox" data-step="${escapeHtml(step.id)}" data-obligation="${escapeHtml(item.id)}" ${step.done ? "checked" : ""}>
    <span><strong>${escapeHtml(step.name)}</strong>${step.done ? `<small class="cell-subtitle">${escapeHtml(userName(step.userId))} · ${dateTimeLabel(step.doneAt)}</small>` : ""}</span>
  </label>`).join("") : '<div class="empty-state">Esta obrigação não tem etapas cadastradas.</div>';
}

function openStepsDialog(id) {
  const item = obligationById(id);
  if (!item) return;
  renderStepDialog(item);
  $("#obligation-steps-dialog").showModal();
}

// ---------------------------------------------------------------- Exportações
function exportQuery() {
  const params = new URLSearchParams({ type: $("#export-type").value });
  for (const [chave, id] of [["userId", "export-user"], ["from", "export-from"], ["to", "export-to"]]) {
    if ($(`#${id}`).value) params.set(chave, $(`#${id}`).value);
  }
  return params;
}

async function loadExports() {
  const params = exportQuery();
  const result = await api(`/api/movimentacoes?${params}`);
  state.exportPreview = result;
  $("#export-download").href = `/api/export/movimentacoes?${params}`;
  $("#export-count").textContent = `Registros (${result.total})`;
  $("#export-note").textContent = result.truncated
    ? `A prévia mostra os 200 primeiros de ${result.total} registros. O CSV traz todos.`
    : "A prévia abaixo mostra todos os registros do filtro.";
  $("#export-head").innerHTML = `<tr>${result.columns.map(column => `<th>${escapeHtml(column.label)}</th>`).join("")}</tr>`;
  $("#export-table").innerHTML = result.items.length
    ? result.items.map(row => `<tr>${result.columns.map(column => `<td>${escapeHtml(String(row[column.key] ?? ""))}</td>`).join("")}</tr>`).join("")
    : `<tr><td colspan="${result.columns.length}"><div class="empty-state">Nenhum registro neste filtro.</div></td></tr>`;
}

// ---------------------------------------------------------------- Identidade visual
function renderBrandingPreview() {
  const cor = $('#branding-form input[name="primaryColor"]').value;
  const nome = $('#branding-form input[name="companyName"]').value || state.officeName || "DF Office";
  const logo = state.branding.logoUrl
    ? `<img src="${escapeHtml(state.branding.logoUrl)}" alt="Logo">`
    : `<span>${escapeHtml(nome.slice(0, 2).toLocaleUpperCase("pt-BR"))}</span>`;
  $("#branding-preview").innerHTML = `<div class="branding-sample" style="background:${escapeHtml(cor)}">
    <div class="branding-logo">${logo}</div>
    <div><strong>${escapeHtml(nome)}</strong><small>Menu lateral e tela de login</small></div>
  </div>`;
}

async function loadBranding() {
  const result = await api("/api/branding");
  applyBranding(result);
  const form = $("#branding-form");
  form.elements.companyName.value = result.companyName || "";
  form.elements.primaryColor.value = result.primaryColor || "#2d2e6e";
  renderBrandingPreview();
}

function populateDemandUsers() {
  const form = $("#demand-form");
  const destination = form.elements.destinationSector.value;
  const users = state.team.filter(item => item.active && (destination === "GESTORES" ? ["ADMIN", "GESTOR"].includes(item.role) : item.sector === destination));
  fillSelect(form.elements.assignedUserId, users, "Sem responsável definido");
}

function demandAttachments(item) {
  return item.attachments?.length ? item.attachments.map(file => `<a class="attachment-link" target="_blank" rel="noopener" href="/api/demands/${item.id}/attachments/${file.id}">${escapeHtml(file.name)}</a>`).join("") : "—";
}

async function loadDemands() {
  const result = await api("/api/demands");
  state.demands = result.items;
  $("#demands-table").innerHTML = result.items.length ? result.items.map(item => `<tr><td>${dateTimeLabel(item.createdAt)}</td><td><strong>${escapeHtml(item.title)}</strong><small class="cell-subtitle wrap-text">${escapeHtml(item.description || "—")}</small></td><td>${escapeHtml(item.destinationSector)}</td><td>${escapeHtml(userName(item.assignedUserId))}</td><td>${statusBadge(item.priority)}</td><td>${statusBadge(item.status)}</td><td class="attachment-list">${demandAttachments(item)}</td><td class="actions">${item.status === "PENDENTE" ? `<button class="table-button" data-action="start-demand" data-id="${item.id}">Iniciar</button>` : ""}${item.status === "EM ANDAMENTO" ? `<button class="table-button" data-action="finish-demand" data-id="${item.id}">Concluir</button>` : ""}</td></tr>`).join("") : '<tr><td colspan="8"><div class="empty-state">Nenhuma demanda interna.</div></td></tr>';
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve({ name: file.name, type: file.type, data: reader.result });
    reader.onerror = () => reject(new Error(`Não foi possível ler ${file.name}.`));
    reader.readAsDataURL(file);
  });
}

async function demandPayload(form) {
  const data = formData(form);
  delete data.attachments;
  const files = [...form.elements.attachments.files];
  if (files.length > 3) throw new Error("Selecione no máximo 3 anexos.");
  if (files.some(file => file.size > 5 * 1024 * 1024)) throw new Error("Cada anexo deve ter no máximo 5 MB.");
  data.attachments = await Promise.all(files.map(readFileAsDataUrl));
  return data;
}

function attendanceById(id) {
  if (state.chat.thread?.id === id) return state.chat.thread;
  return state.attendances.find(item => item.id === id) || state.chat.items.find(item => item.id === id);
}

function openAttendanceFinish(item) {
  const form = $("#attendance-finish-form");
  form.reset();
  form.elements.attendanceId.value = item.id;
  $("#attendance-finish-dialog").showModal();
}

function updateConversionFields() {
  const obligation = $('#attendance-convert-form select[name="kind"]').value === "OBRIGAÇÃO";
  $$(".conversion-obligation-field").forEach(element => { element.hidden = !obligation; });
  $$(".conversion-activity-field").forEach(element => { element.hidden = obligation; });
}

function openAttendanceConversion(item) {
  const form = $("#attendance-convert-form");
  form.reset();
  form.elements.attendanceId.value = item.id;
  form.elements.title.value = item.subject;
  form.elements.instructions.value = item.message || "";
  form.elements.date.value = todayValue();
  form.elements.period.value = todayValue().slice(0, 7);
  updateConversionFields();
  $("#attendance-convert-dialog").showModal();
}

async function refreshActivityState() {
  const result = await api("/api/activities");
  state.activities = result.items;
  renderActivities();
  if ($("#view-dashboard").classList.contains("active")) await loadDashboard();
}

async function loadDashboard() {
  const params = new URLSearchParams();
  if ($("#dashboard-from").value) params.set("from", $("#dashboard-from").value);
  if ($("#dashboard-to").value) params.set("to", $("#dashboard-to").value);
  const data = await api(`/api/dashboard?${params}`);
  const collaboratorView = state.user.role === "COLABORADOR";
  $("#dashboard-obligations-title").textContent = collaboratorView ? "Minhas obrigações" : "Próximos prazos";
  $("#dashboard-activities-title").textContent = collaboratorView ? "Minhas atividades" : "Atividades recentes";
  $("#upcoming-obligations").innerHTML = data.upcomingObligations.length ? data.upcomingObligations.map(item => `<div class="compact-item"><div><strong>${escapeHtml(item.type)}</strong><small>${escapeHtml(clientName(item.clientId))}</small></div><div><span>${dateLabel(item.dueDate)}</span>${statusBadge(item.status)}</div></div>`).join("") : '<div class="empty-state">Nenhuma obrigação atribuída.</div>';
  $("#recent-activities").innerHTML = data.recentActivities.length ? data.recentActivities.map(item => `<tr${activityRowAttributes(item)}><td>${dateLabel(item.date)}</td><td>${escapeHtml(userName(item.userId))}</td><td>${escapeHtml(clientName(item.clientId))}</td><td>${activityTaskMarkup(item)}</td><td>${statusBadge(item.status)}</td><td>${dateTimeLabel(item.startedAt)}</td><td>${dateTimeLabel(item.finishedAt)}</td><td>${escapeHtml(item.notes || "—")}</td><td>${activityTimingLabel(item)}</td></tr>`).join("") : '<tr><td colspan="9"><div class="empty-state">Nenhuma atividade registrada.</div></td></tr>';
  if (collaboratorView) return;
  const cards = [
    ["Horas registradas", `${data.metrics.totalHours.toLocaleString("pt-BR")}h`],
    ["Atividades", data.metrics.activities],
    ["Conclusão", `${data.metrics.completionRate}%`],
    ["Clientes ativos", data.metrics.activeClients],
    ["Equipe ativa", data.metrics.activeUsers],
    ["Presentes agora", data.metrics.employeesPresent],
    ["Obrigações pendentes", data.metrics.pendingObligations],
    ["Obrigações atrasadas", data.metrics.overdueObligations]
  ];
  $("#metrics").innerHTML = cards.map(([label, value]) => `<article class="metric-card"><small>${escapeHtml(label)}</small><strong>${escapeHtml(value)}</strong></article>`).join("");
  const statusEntries = Object.entries(data.obligationStatus);
  const max = Math.max(1, ...statusEntries.map(([, count]) => count));
  $("#status-bars").innerHTML = statusEntries.length ? statusEntries.map(([status, count]) => `<div class="status-row"><span>${escapeHtml(status)}</span><div class="status-track"><div class="status-fill" style="width:${Math.max(4, count / max * 100)}%"></div></div><strong>${count}</strong></div>`).join("") : '<div class="empty-state">Nenhuma obrigação registrada no período.</div>';
  $("#team-production").innerHTML = data.teamProduction.length ? data.teamProduction.map(item => `<tr>
    <td><strong>${escapeHtml(item.name)}</strong><small class="cell-subtitle">${escapeHtml(item.role)}</small></td>
    <td>${presenceBadge(item.presence)}</td><td>${item.activities}</td><td>${item.concluded}</td><td>${item.inProgress}</td>
    <td><strong>${minutesLabel(item.totalMinutes)}</strong></td><td><span class="completion-value">${item.completionRate}%</span></td>
    <td>${item.lastActivity ? `<strong>${escapeHtml(item.lastActivity.task)}</strong><small class="cell-subtitle">${dateLabel(item.lastActivity.date)} • ${escapeHtml(item.lastActivity.status)}</small>` : "—"}</td>
  </tr>`).join("") : '<tr><td colspan="8"><div class="empty-state">Nenhuma produção encontrada no período.</div></td></tr>';
  $("#dashboard-updated").textContent = `Atualizado às ${new Intl.DateTimeFormat("pt-BR", { hour: "2-digit", minute: "2-digit", second: "2-digit" }).format(new Date())}`;
}

async function loadTimeClock() {
  const params = new URLSearchParams();
  if ($("#time-from").value) params.set("from", $("#time-from").value);
  if ($("#time-to").value) params.set("to", $("#time-to").value);
  if (state.user.role !== "COLABORADOR" && $("#time-user-filter").value) params.set("userId", $("#time-user-filter").value);
  const data = await api(`/api/time-clock?${params}`);
  state.timeClock = data;
  renderTimeClock();
  $("#time-export").href = `/api/export/time-clock?${params}`;
}

function renderTimeClock() {
  const data = state.timeClock;
  if (!data) return;
  const todayByType = Object.fromEntries(data.today.entries.map(item => [item.type, item]));
  $("#clock-date").textContent = dateLabel(data.today.date);
  $("#today-punches").innerHTML = state.timeClockTypes.map((type, index) => {
    const entry = todayByType[type.value];
    return `<div class="punch-step ${entry ? "done" : ""}"><span>${index + 1}</span><div><strong>${escapeHtml(type.label)}</strong><small>${entry ? `${escapeHtml(entry.time)}${entry.automatic === false ? " • ajustado" : ""}` : "Aguardando"}</small></div></div>`;
  }).join("");
  const button = $("#punch-button");
  button.dataset.type = data.today.nextAction || "";
  button.disabled = !data.today.nextAction || data.today.invalidOrder;
  button.textContent = data.today.invalidOrder ? "Jornada precisa de ajuste" : data.today.nextAction ? `Registrar ${timeClockLabel(data.today.nextAction)}` : "Jornada concluída";
  $("#punch-message").textContent = data.today.invalidOrder
    ? "Os horários estão fora de ordem. Solicite a correção a um gestor."
    : data.today.complete
    ? `Marcações concluídas • ${minutesLabel(data.today.totalMinutes)} trabalhadas.`
    : data.today.entries.length ? `Próxima etapa: ${timeClockLabel(data.today.nextAction)}.` : "Registre sua entrada ao iniciar o expediente.";

  $("#time-clock-table").innerHTML = data.days.length ? data.days.map(day => `<tr>
    <td>${dateLabel(day.date)}</td><td>${escapeHtml(userName(day.userId))}</td>
    <td>${escapeHtml(day.times.ENTRADA || "—")}</td><td>${escapeHtml(day.times.SAIDA_ALMOCO || "—")}</td>
    <td>${escapeHtml(day.times.RETORNO_ALMOCO || "—")}</td><td>${escapeHtml(day.times.SAIDA || "—")}</td>
    <td><strong>${minutesLabel(day.totalMinutes)}</strong></td>
    <td>${day.complete ? '<span class="badge">Completo</span>' : '<span class="badge warning">Incompleto</span>'}${day.corrected ? '<span class="badge muted clock-adjusted">Ajustado</span>' : ""}</td>
  </tr>`).join("") : '<tr><td colspan="8"><div class="empty-state">Nenhuma marcação encontrada no período.</div></td></tr>';
}

function renderClients() {
  const query = searchKey($("#client-search").value);
  const selectedType = $("#client-type-filter").value;
  const filtered = state.clients.filter(item => {
    const searchable = searchKey(`${item.name} ${item.cnpj || ""} ${item.domainCode || ""} ${item.city || ""} ${item.businessActivity || ""}`);
    return (!selectedType || item.taxRegime === selectedType) && (!query || searchable.includes(query));
  });
  const groups = [...COMPANY_TYPES.map(type => ({ value: type.value, label: type.plural })), { value: "", label: "SEM CLASSIFICAÇÃO" }];
  const rows = groups.flatMap(group => {
    const clients = filtered.filter(item => (item.taxRegime || "") === group.value).sort((a, b) => String(a.name).localeCompare(String(b.name), "pt-BR"));
    if (!clients.length) return [];
    return [
      `<tr class="client-group-row"><td colspan="12">${escapeHtml(group.label)} <span>${clients.length} cliente(s)</span></td></tr>`,
      ...clients.map(item => `<tr><td><strong>${escapeHtml(item.domainCode || "—")}</strong></td><td>${escapeHtml(item.name)}</td><td>${cnpjLabel(item.cnpj)}</td><td>${escapeHtml(item.stateRegistration || "—")}</td><td>${escapeHtml(item.municipalRegistration || "—")}</td><td>${cpfLabel(item.responsibleCpf)}</td><td>${escapeHtml(phoneLabel(item.whatsappPhone))}</td><td>${escapeHtml(item.city || "—")}</td><td>${escapeHtml(item.businessActivity || "—")}</td><td>${escapeHtml(companyTypeLabel(item.taxRegime, false))}</td><td>${item.active ? '<span class="badge">Ativo</span>' : '<span class="badge muted">Inativo</span>'}</td><td class="actions">${state.user.role !== "COLABORADOR" ? `<button class="table-button" data-action="edit-client" data-id="${item.id}">Editar</button><button class="table-button danger" data-action="delete-client" data-id="${item.id}">Excluir</button>` : ""}</td></tr>`)
    ];
  });
  $("#clients-table").innerHTML = rows.length ? rows.join("") : '<tr><td colspan="12"><div class="empty-state">Nenhum cliente encontrado para os filtros informados.</div></td></tr>';
}

function renderActivities() {
  const ordered = [...state.activities].sort((a, b) => String(b.date).localeCompare(String(a.date)));
  const manager = state.user.role !== "COLABORADOR";
  $("#activities-table").innerHTML = ordered.length ? ordered.map(item => {
    let actions = "";
    if (activityCanStart(item)) {
      actions = `<button class="table-button" data-action="start-activity" data-id="${item.id}">Iniciar</button>`;
    } else if (activityIsMine(item) && item.status === "EM ATIVIDADE") {
      actions = `<button class="table-button" data-action="finish-activity" data-id="${item.id}">Editar</button>`;
    } else if (manager) {
      const editable = !["EM ATIVIDADE", "CONCLUÍDO"].includes(item.status);
      actions = `${editable ? `<button class="table-button" data-action="edit-activity" data-id="${item.id}">Editar</button>` : ""}<button class="table-button danger" data-action="delete-activity" data-id="${item.id}">Excluir</button>`;
    } else if (activityCanStart(item)) {
      actions = `<button class="table-button" data-action="start-activity" data-id="${item.id}">Iniciar</button>`;
    } else if (item.status === "EM ATIVIDADE") {
      actions = `<button class="table-button" data-action="finish-activity" data-id="${item.id}">Editar</button>`;
    }
    // Depois de concluída, quem executou ou a gestão pode corrigir a observação.
    if (item.status === "CONCLUÍDO" && (activityIsMine(item) || manager)) {
      actions = `<button class="table-button" data-action="fix-activity-notes" data-id="${item.id}">Corrigir observação</button>${actions}`;
    }
    return `<tr${activityRowAttributes(item)}><td>${dateLabel(item.date)}</td><td>${escapeHtml(userName(item.userId))}</td><td>${escapeHtml(clientName(item.clientId))}</td><td>${activityTaskMarkup(item)}</td><td>${statusBadge(item.status)}</td><td>${dateTimeLabel(item.startedAt)}</td><td>${dateTimeLabel(item.finishedAt)}</td><td>${escapeHtml(item.notes || "—")}</td><td>${activityTimingLabel(item)}</td><td class="actions">${actions}</td></tr>`;
  }).join("") : '<tr><td colspan="10"><div class="empty-state">Nenhuma atividade registrada.</div></td></tr>';
}

function renderObligations() {
  const manager = state.user.role !== "COLABORADOR";
  const ordered = [...state.obligations].sort((a, b) => String(a.dueDate).localeCompare(String(b.dueDate)));
  $("#obligations-table").innerHTML = ordered.length ? ordered.map(item => {
    const marcada = state.obligationSelection.has(item.id);
    const selecao = manager
      ? `<td class="select-column"><input type="checkbox" data-select-obligation="${item.id}" ${marcada ? "checked" : ""}></td>`
      : "";
    const acoes = manager
      ? `<button class="table-button" data-action="edit-obligation" data-id="${item.id}">Editar</button><button class="table-button danger" data-action="delete-obligation" data-id="${item.id}">Excluir</button>`
      : `<button class="table-button" data-action="status-obligation" data-id="${item.id}">Atualizar</button>`;
    return `<tr class="${marcada ? "row-selected" : ""}">${selecao}
      <td>${escapeHtml(clientName(item.clientId))}</td>
      <td><strong>${escapeHtml(item.type)}</strong></td>
      <td>${escapeHtml(item.period)}</td>
      <td>${item.recurrence ? `<span class="badge muted">${escapeHtml(item.recurrence)}</span>` : "—"}</td>
      <td>${dateLabel(item.dueDate)}</td>
      <td>${escapeHtml(userName(item.responsibleId))}</td>
      <td>${statusBadge(item.status)}</td>
      <td>${obligationStepsCell(item)}</td>
      <td class="actions">${acoes}</td></tr>`;
  }).join("") : '<tr><td colspan="10"><div class="empty-state">Nenhuma obrigação registrada.</div></td></tr>';
  updateBulkBar();
}

function renderUsers() {
  if (!["ADMIN", "GESTOR"].includes(state.user.role)) return;
  $("#users-table").innerHTML = state.users.map(item => `<tr><td>${escapeHtml(item.name)}</td><td>${escapeHtml(item.username)}</td><td><strong>${escapeHtml(item.sector)}</strong></td><td>${escapeHtml(item.role)}</td><td>${item.mustChangePassword ? '<span class="badge warning">Troca pendente</span>' : '<span class="badge">Definida</span>'}</td><td>${item.locked ? '<span class="badge danger">Bloqueado</span>' : item.active ? '<span class="badge">Ativo</span>' : '<span class="badge muted">Inativo</span>'}</td><td class="actions">${item.locked ? `<button class="table-button danger" data-action="unlock-user" data-id="${item.id}">Liberar bloqueio</button>` : ""}<button class="table-button" data-action="password-user" data-id="${item.id}">Senha</button>${item.id !== state.user.id ? `<button class="table-button" data-action="toggle-user" data-id="${item.id}">${item.active ? "Desativar" : "Ativar"}</button>` : ""}</td></tr>`).join("");
}

function updateAdministrativeExportLinks(period) {
  const query = encodeURIComponent(period);
  $("#administrative-export-pdf").href = `/api/administrative/export.pdf?period=${query}`;
  $("#administrative-export-excel").href = `/api/administrative/export.xls?period=${query}`;
}

function resetAdministrativeForm() {
  const form = $("#administrative-form");
  form.reset();
  form.elements.id.value = "";
  form.elements.period.value = state.administrative.period || $("#administrative-period").value;
  $("#administrative-submit").textContent = "Adicionar despesa";
  $("#administrative-cancel").hidden = true;
}

function editAdministrativeEntry(id) {
  const item = state.administrative.administrative?.entries?.find(entry => entry.id === id);
  if (!item) return;
  const form = $("#administrative-form");
  form.elements.id.value = item.id;
  form.elements.period.value = item.period;
  form.elements.amount.value = item.amount;
  form.elements.category.value = item.category;
  form.elements.correlation.value = item.correlation;
  $("#administrative-submit").textContent = "Salvar alteração";
  $("#administrative-cancel").hidden = false;
  form.scrollIntoView({ behavior: "smooth", block: "start" });
  form.elements.amount.focus();
}

async function loadAdministrative() {
  if (!["ADMIN", "GESTOR"].includes(state.user.role)) return;
  const period = $("#administrative-period").value || todayValue().slice(0, 7);
  const data = await api(`/api/administrative?period=${encodeURIComponent(period)}`);
  state.administrative = {
    period: data.period, summary: data.summary, administrative: data.administrative,
    entries: data.entries, items: data.items
  };
  resetAdministrativeForm();
  updateAdministrativeExportLinks(data.period);
  renderAdministrative();
}

function renderAdministrative() {
  const { summary, entries } = state.administrative;
  if (!summary) return;
  $("#administrative-metrics").innerHTML = [
    ["Despesas gerais", moneyLabel(summary.generalAdministrativeCost)],
    ["Custo administrativo/hora", summary.administrativeCostPerHour === null ? "—" : moneyLabel(summary.administrativeCostPerHour)],
    ["Custos extras dos CNPJs", moneyLabel(summary.totalExtraCost)],
    ["Receitas extras dos CNPJs", moneyLabel(summary.totalExtraRevenue)]
  ].map(([label, value]) => `<article class="metric-card"><small>${escapeHtml(label)}</small><strong>${escapeHtml(value)}</strong></article>`).join("");
  $("#administrative-entries-table").innerHTML = entries.length ? entries.map(item => {
    const revenue = item.type === "RECEITA EXTRA";
    const actions = item.editable ? `<div class="actions"><button class="table-button" data-action="edit-administrative" data-id="${escapeHtml(item.id)}">Editar</button><button class="table-button" data-action="delete-administrative" data-id="${escapeHtml(item.id)}">Excluir</button></div>` : "";
    return `<tr><td><span class="badge ${revenue ? "" : "warning"}">${escapeHtml(item.type)}</span></td><td><strong>${escapeHtml(item.origin)}</strong><small class="cell-subtitle">${escapeHtml(item.description || "—")}</small></td><td>${escapeHtml(item.clientName)}</td><td>${cnpjLabel(item.cnpj)}</td><td class="${revenue ? "money-positive" : "money-negative"}">${revenue ? "+ " : "- "}${moneyLabel(item.amount)}</td><td>${actions}</td></tr>`;
  }).join("") : '<tr><td colspan="6"><div class="empty-state">Nenhuma despesa ou receita extra registrada nesta competência.</div></td></tr>';
}

async function loadBudgets() {
  if (!["ADMIN", "GESTOR"].includes(state.user.role)) return;
  const period = $("#budget-period").value || todayValue().slice(0, 7);
  const data = await api(`/api/budgets?period=${encodeURIComponent(period)}`);
  state.budgets = { period: data.period, summary: data.summary, items: data.items };
  renderBudgets();
}

function renderBudgets() {
  const summary = state.budgets.summary;
  if (!summary) return;
  $("#budget-metrics").innerHTML = [
    ["CNPJs com horas", `${summary.clientsWithHours} de ${summary.clients}`],
    ["Horas trabalhadas", minutesLabel(summary.totalMinutes)],
    ["Custo administrativo/hora", summary.administrativeCostPerHour === null ? "—" : moneyLabel(summary.administrativeCostPerHour)],
    ["Saldo após despesas", moneyLabel(summary.result)]
  ].map(([label, value]) => `<article class="metric-card"><small>${escapeHtml(label)}</small><strong>${escapeHtml(value)}</strong></article>`).join("");
  const search = $("#budget-search").value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("pt-BR");
  const items = state.budgets.items.filter(item => {
    const haystack = `${item.name} ${item.cnpj || ""} ${item.domainCode || ""}`.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("pt-BR");
    return !search || haystack.includes(search);
  });
  $("#budgets-table").innerHTML = items.length ? items.map(item => {
    const resultClass = item.resultPerHour !== null && item.resultPerHour >= 0 ? "money-positive" : "money-negative";
    return `<tr><td>${cnpjLabel(item.cnpj)}</td><td><strong>${escapeHtml(item.name)}</strong><small class="cell-subtitle">Cód. ${escapeHtml(item.domainCode || "—")}</small></td><td>${minutesLabel(item.totalMinutes)}</td><td>${item.activityCount}</td><td>${item.administrativeCostPerHour === null ? "—" : moneyLabel(item.administrativeCostPerHour)}</td><td>${moneyLabel(item.extraCost)}</td><td>${moneyLabel(item.extraRevenue)}</td><td class="${resultClass}">${item.resultPerHour === null ? "—" : moneyLabel(item.resultPerHour)}</td><td class="actions"><button class="table-button" data-action="open-budget" data-id="${escapeHtml(item.clientId)}">Detalhar</button></td></tr>`;
  }).join("") : '<tr><td colspan="9"><div class="empty-state">Nenhum CNPJ encontrado para o filtro.</div></td></tr>';
}

function openBudgetDialog(clientId) {
  const item = state.budgets.items.find(entry => entry.clientId === clientId);
  if (!item) return;
  const dialog = $("#budget-dialog");
  const form = $("#budget-form");
  form.reset();
  form.elements.clientId.value = item.clientId;
  form.elements.period.value = state.budgets.period;
  form.elements.extraCost.value = item.extraCost;
  form.elements.extraRevenue.value = item.extraRevenue;
  form.elements.extraCostDescription.value = item.extraCostDescription || "";
  form.elements.extraRevenueDescription.value = item.extraRevenueDescription || "";
  $("#budget-dialog-title").textContent = item.name;
  $("#budget-dialog-subtitle").textContent = `${cnpjLabel(item.cnpj)} • competência ${state.budgets.period.split("-").reverse().join("/")}`;
  $("#budget-detail-metrics").innerHTML = [
    ["Horas trabalhadas", minutesLabel(item.totalMinutes)],
    ["Custo administrativo rateado", moneyLabel(item.allocatedAdministrativeCost)],
    ["Custo total por hora", item.costPerHour === null ? "—" : moneyLabel(item.costPerHour)],
    ["Saldo por hora", item.resultPerHour === null ? "—" : moneyLabel(item.resultPerHour)]
  ].map(([label, value]) => `<article class="metric-card"><small>${escapeHtml(label)}</small><strong>${escapeHtml(value)}</strong></article>`).join("");
  const departmentRows = item.departments.flatMap(department => department.employees.map((employee, index) => `<tr><td>${index === 0 ? `<strong>${escapeHtml(department.sector)}</strong><small class="cell-subtitle">Total: ${minutesLabel(department.totalMinutes)}</small>` : ""}</td><td>${escapeHtml(employee.name)}</td><td>${employee.activityCount}</td><td>${minutesLabel(employee.totalMinutes)}</td></tr>`));
  $("#budget-departments-table").innerHTML = departmentRows.length ? departmentRows.join("") : '<tr><td colspan="4"><div class="empty-state">Nenhuma atividade concluída nesta competência.</div></td></tr>';
  dialog.showModal();
}

async function loadAudit() {
  if (!["ADMIN", "GESTOR"].includes(state.user.role)) return;
  state.audit = (await api("/api/audit")).items;
  $("#audit-table").innerHTML = state.audit.length ? state.audit.map(item => `<tr><td>${dateTimeLabel(item.at)}</td><td>${escapeHtml(item.username)}</td><td>${escapeHtml(item.action)}</td><td>${escapeHtml(item.entity)}</td><td>${escapeHtml(item.details)}</td><td>${escapeHtml(item.ip || "—")}</td></tr>`).join("") : '<tr><td colspan="6"><div class="empty-state">Nenhum evento registrado.</div></td></tr>';
}

function assignmentPayload(data, form, kind) {
  const clientIds = pickerValues(form.querySelector(kind === "activity" ? "#activity-client-picker" : "#obligation-client-picker"));
  if (!clientIds.length) throw new Error("Selecione ao menos um CNPJ.");
  data.clientIds = clientIds;
  const userPicker = form.querySelector(kind === "activity" ? "#activity-user-picker" : "#obligation-user-picker");
  const responsibleIds = pickerValues(userPicker);
  if (kind === "activity" && !responsibleIds.length) throw new Error("Selecione ao menos um responsável.");
  if (kind === "activity") data.userIds = responsibleIds;
  else data.responsibleIds = responsibleIds;
  if (data.id) {
    if (clientIds.length !== 1 || responsibleIds.length > 1 || (kind === "activity" && responsibleIds.length !== 1)) {
      throw new Error("Na edição de um registro, selecione somente um CNPJ e um responsável.");
    }
    data.clientId = clientIds[0];
    if (kind === "activity") data.userId = responsibleIds[0];
    else data.responsibleId = responsibleIds[0] || "";
    delete data.clientIds;
    delete data.userIds;
    delete data.responsibleIds;
  }
  return data;
}

function resetEdit(form) {
  form.reset();
  form.elements.id.value = "";
  form.classList.remove("editing");
  const today = new Date().toISOString().slice(0, 10);
  if (form.getAttribute("id") === "activity-form") {
    form.elements.date.value = today;
    setPickerValues($("#activity-client-picker"), []);
    setPickerValues($("#activity-user-picker"), state.user.role === "COLABORADOR" ? [state.user.id] : []);
  }
  if (form.getAttribute("id") === "obligation-form") {
    form.elements.period.value = today.slice(0, 7);
    setPickerValues($("#obligation-client-picker"), []);
    setPickerValues($("#obligation-user-picker"), []);
  }
}

function fillForm(form, item) {
  if (form.getAttribute("id") === "activity-form") {
    setPickerValues($("#activity-client-picker"), [item.clientId]);
    setPickerValues($("#activity-user-picker"), [item.userId]);
  }
  if (form.getAttribute("id") === "obligation-form") {
    setPickerValues($("#obligation-client-picker"), [item.clientId]);
    setPickerValues($("#obligation-user-picker"), item.responsibleId ? [item.responsibleId] : []);
  }
  for (const [key, value] of Object.entries(item)) {
    const field = form.elements.namedItem(key);
    if (!field) continue;
    if (field.type === "checkbox") field.checked = Boolean(value);
    else field.value = value ?? "";
  }
  form.classList.add("editing");
  form.scrollIntoView({ behavior: "smooth", block: "start" });
}

async function saveEntity(form, endpoint, normalize = value => value) {
  const data = normalize(formData(form), form);
  const id = data.id;
  delete data.id;
  const response = await api(id ? `${endpoint}/${id}` : endpoint, { method: id ? "PUT" : "POST", body: data });
  resetEdit(form);
  const activityCreated = state.user.role === "COLABORADOR"
    ? "Atividade adicionada. Clique nela para iniciar em até 30 minutos."
    : "Atividade atribuída. O prazo de 30 minutos foi iniciado.";
  const count = Number(response.count || 1);
  const createdMessage = count > 1
    ? `${count} ${endpoint === "/api/activities" ? "atividades atribuídas" : "obrigações criadas"} com sucesso.`
    : endpoint === "/api/activities" ? activityCreated : "Registro criado.";
  toast(id ? "Registro atualizado." : createdMessage);
  await loadBase();
  await loadDashboard();
  return response.item;
}

async function startActivity(id) {
  if (state.activityBusy) return;
  state.activityBusy = id;
  try {
    const result = await api(`/api/activities/${id}/start`, { method: "POST" });
    toast(`Atividade iniciada às ${result.item.start}.`);
    await loadBase();
    await loadDashboard();
  } finally {
    state.activityBusy = null;
  }
}

function openActivityFinishDialog(item) {
  const dialog = $("#activity-finish-dialog");
  const form = $("#activity-finish-form");
  form.reset();
  form.elements.activityId.value = item.id;
  $("#activity-finish-label").textContent = `${item.task} • iniciada em ${dateTimeLabel(item.startedAt)}`;
  dialog.showModal();
}

function openPasswordDialog(user, required = false) {
  const dialog = $("#password-dialog");
  const form = $("#password-form");
  form.reset();
  form.elements.userId.value = user.id;
  dialog.dataset.required = required ? "1" : "";
  $("#password-dialog-close").hidden = required;
  $("#password-target-label").textContent = required
    ? `Primeiro acesso de ${user.name}. Crie uma nova senha pessoal para continuar.`
    : `Nova senha para ${user.name} (${user.username}).`;
  dialog.showModal();
}

function attachEvents() {
  initializeMultiPickers();
  $("#catalog-department").addEventListener("change", renderObligationCatalog);
  $("#catalog-search").addEventListener("input", renderObligationCatalog);
  $("#catalog-item").addEventListener("change", showCatalogDetail);
  $("#catalog-prepare").addEventListener("click", prepareCatalogDistribution);
  $('#login-form select[name="sector"]').addEventListener("change", event => applySectorIdentity(event.currentTarget.value));
  $("#setup-form").addEventListener("submit", async event => {
    event.preventDefault();
    const data = formData(event.currentTarget);
    if (data.password !== data.confirmPassword) return toast("As senhas não conferem.", true);
    delete data.confirmPassword;
    try {
      const result = await api("/api/setup", { method: "POST", body: data });
      Object.assign(state, { csrf: result.csrf, user: result.user, officeName: data.officeName });
      await afterAuthentication();
    } catch (error) { handleError(error); }
  });

  $("#login-form").addEventListener("submit", async event => {
    event.preventDefault();
    const form = event.currentTarget;
    try {
      const result = await api("/api/login", { method: "POST", body: formData(form) });
      state.csrf = result.csrf;
      state.user = result.user;
      form.reset();
      await afterAuthentication();
    } catch (error) { handleError(error); }
  });

  $("#logout").addEventListener("click", async () => {
    try { await api("/api/logout", { method: "POST" }); } catch {}
    showLogin();
  });
  $("#change-password").addEventListener("click", () => openPasswordDialog(state.user));
  $("#sidebar-toggle").addEventListener("click", toggleSidebar);
  $("#main-nav").addEventListener("click", event => {
    const button = event.target.closest("button[data-view]");
    if (button) navigate(button.dataset.view);
  });
  $("#refresh-dashboard").addEventListener("click", () => loadDashboard().catch(handleError));
  $("#refresh-administrative").addEventListener("click", () => loadAdministrative().catch(handleError));
  $("#administrative-period").addEventListener("change", () => loadAdministrative().catch(handleError));
  $("#refresh-budgets").addEventListener("click", () => loadBudgets().catch(handleError));
  $("#budget-period").addEventListener("change", () => loadBudgets().catch(handleError));
  $("#budget-search").addEventListener("input", renderBudgets);
  $("#client-search").addEventListener("input", renderClients);
  $("#client-type-filter").addEventListener("change", renderClients);
  $("#refresh-time-clock").addEventListener("click", () => loadTimeClock().catch(handleError));
  $("#time-user-filter").addEventListener("change", () => loadTimeClock().catch(handleError));
  $("#punch-button").addEventListener("click", async event => {
    const button = event.currentTarget;
    const type = button.dataset.type;
    if (!type || !confirm(`Registrar ${timeClockLabel(type)} agora?`)) return;
    button.disabled = true;
    try {
      const result = await api("/api/time-clock/punch", { method: "POST", body: { type } });
      toast(`${timeClockLabel(result.item.type)} registrada às ${result.item.time}.`);
      await loadTimeClock();
    } catch (error) {
      handleError(error);
      await loadTimeClock().catch(() => {});
    }
  });
  $("#time-adjust-form").addEventListener("submit", async event => {
    event.preventDefault();
    const form = event.currentTarget;
    try {
      await api("/api/time-clock/manual", { method: "POST", body: formData(form) });
      form.elements.reason.value = "";
      form.elements.time.value = "";
      toast("Marcação ajustada e registrada na auditoria.");
      await loadTimeClock();
    } catch (error) { handleError(error); }
  });

  $("#obligations-table").addEventListener("change", event => {
    const caixa = event.target.closest("input[data-select-obligation]");
    if (!caixa) return;
    const id = caixa.dataset.selectObligation;
    if (caixa.checked) state.obligationSelection.add(id);
    else state.obligationSelection.delete(id);
    caixa.closest("tr").classList.toggle("row-selected", caixa.checked);
    updateBulkBar();
  });

  $("#obligations-select-all").addEventListener("change", event => {
    state.obligationSelection.clear();
    if (event.target.checked) for (const item of state.obligations) state.obligationSelection.add(item.id);
    renderObligations();
  });

  $("#bulk-clear").addEventListener("click", () => {
    state.obligationSelection.clear();
    renderObligations();
  });

  $("#bulk-apply").addEventListener("click", async () => {
    const corpo = {};
    if ($("#bulk-responsible").value) corpo.responsibleId = $("#bulk-responsible").value;
    if ($("#bulk-status").value) corpo.status = $("#bulk-status").value;
    if ($("#bulk-recurrence").value) corpo.recurrence = $("#bulk-recurrence").value;
    if ($("#bulk-due-date").value) corpo.dueDate = $("#bulk-due-date").value;
    if (!Object.keys(corpo).length) {
      toast("Escolha ao menos um campo para alterar.", true);
      return;
    }
    const quantas = selectedObligations().length;
    if (!confirm(`Aplicar as alterações em ${quantas} obrigação(ões)?`)) return;
    try {
      await applyBulk(corpo, "Alteração aplicada");
      for (const id of ["bulk-responsible", "bulk-status", "bulk-recurrence", "bulk-due-date"]) $(`#${id}`).value = "";
    } catch (error) { handleError(error); }
  });

  $("#bulk-delete").addEventListener("click", async () => {
    const quantas = selectedObligations().length;
    if (!confirm(`Excluir ${quantas} obrigação(ões)? Esta ação não pode ser desfeita.`)) return;
    try {
      await applyBulk({ action: "EXCLUIR" }, "Excluídas");
    } catch (error) { handleError(error); }
  });

  $("#recurrence-add").addEventListener("click", async () => {
    const campo = $("#recurrence-new");
    const nome = campo.value.trim();
    if (!nome) return;
    try {
      await api("/api/recurrences", { method: "POST", body: { name: nome } });
      campo.value = "";
      await loadRecurrences();
      toast("Periodicidade incluída.");
    } catch (error) { handleError(error); }
  });

  $("#activity-notes-form").addEventListener("submit", async event => {
    event.preventDefault();
    const data = formData(event.currentTarget);
    try {
      await api(`/api/activities/${data.activityId}/notes`, { method: "POST", body: { notes: data.notes } });
      $("#activity-notes-dialog").close();
      toast("Observação corrigida. O texto anterior ficou na auditoria.");
      await refreshActivityState();
    } catch (error) { handleError(error); }
  });

  $("#refresh-panel").addEventListener("click", () => loadObligationsPanel().catch(handleError));
  $("#panel-period").addEventListener("change", () => loadObligationsPanel().catch(handleError));
  $("#panel-status").addEventListener("change", renderObligationPanel);
  $("#panel-search").addEventListener("input", renderObligationPanel);

  $("#refresh-exports").addEventListener("click", () => loadExports().catch(handleError));
  for (const id of ["export-type", "export-user", "export-from", "export-to"]) {
    $(`#${id}`).addEventListener("change", () => loadExports().catch(handleError));
  }

  $("#step-template-form").addEventListener("submit", async event => {
    event.preventDefault();
    const form = event.currentTarget;
    try {
      await api("/api/obligation-steps", { method: "POST", body: formData(form) });
      form.reset();
      toast("Passo a passo salvo. Novas obrigações desse tipo já nascem com as etapas.");
      await loadStepTemplates();
    } catch (error) { handleError(error); }
  });

  $("#obligation-steps-list").addEventListener("change", async event => {
    const box = event.target.closest("input[type=checkbox][data-step]");
    if (!box) return;
    box.disabled = true;
    try {
      const result = await api(`/api/obligations/${encodeURIComponent(box.dataset.obligation)}/steps/${encodeURIComponent(box.dataset.step)}`, {
        method: "POST", body: { done: box.checked }
      });
      const atualizado = result.item;
      const naLista = state.obligations.findIndex(item => item.id === atualizado.id);
      if (naLista >= 0) state.obligations[naLista] = atualizado;
      renderStepDialog(atualizado);
      renderObligations();
      if ($("#view-obligations-panel").classList.contains("active")) await loadObligationsPanel();
    } catch (error) {
      box.checked = !box.checked;
      handleError(error);
    } finally { box.disabled = false; }
  });

  $("#branding-form").addEventListener("submit", async event => {
    event.preventDefault();
    const form = event.currentTarget;
    try {
      const payload = { companyName: form.elements.companyName.value, primaryColor: form.elements.primaryColor.value };
      const arquivo = form.elements.logo.files[0];
      if (arquivo) {
        if (arquivo.size > 1024 * 1024) throw new Error("A logo deve ter no máximo 1 MB.");
        payload.logo = await readFileAsDataUrl(arquivo);
      }
      const result = await api("/api/branding", { method: "POST", body: payload });
      applyBranding(result);
      form.elements.logo.value = "";
      renderBrandingPreview();
      toast("Identidade visual salva. Peça Ctrl + F5 nos outros computadores.");
    } catch (error) { handleError(error); }
  });

  $("#branding-remove-logo").addEventListener("click", async () => {
    if (!confirm("Voltar para a logo padrão da FG Consultoria?")) return;
    try {
      const result = await api("/api/branding", { method: "POST", body: { removeLogo: true, companyName: $('#branding-form input[name="companyName"]').value, primaryColor: $('#branding-form input[name="primaryColor"]').value } });
      applyBranding(result);
      renderBrandingPreview();
      toast("Logo padrão restaurada.");
    } catch (error) { handleError(error); }
  });

  $('#branding-form input[name="primaryColor"]').addEventListener("input", renderBrandingPreview);
  $('#branding-form input[name="companyName"]').addEventListener("input", renderBrandingPreview);

  $("#refresh-attendance-inbox").addEventListener("click", () => loadAttendanceInbox().catch(handleError));
  $("#chat-tabs").addEventListener("click", event => {
    const button = event.target.closest("button[data-tab]");
    if (!button) return;
    state.chat.tab = button.dataset.tab === "contacts" ? "all" : button.dataset.tab;
    $$("#chat-tabs button").forEach(item => item.classList.toggle("active", item === button));
    loadAttendanceInbox().catch(handleError);
  });
  $("#chat-search").addEventListener("input", event => {
    state.chat.search = event.target.value.trim();
    clearTimeout(state.chat.searchTimer);
    state.chat.searchTimer = setTimeout(() => loadAttendanceInbox().catch(handleError), 300);
  });
  $("#chat-list").addEventListener("click", event => {
    const button = event.target.closest("button[data-conversation]");
    if (!button) return;
    openConversation(button.dataset.conversation).catch(handleError);
  });
  $("#chat-message").addEventListener("keydown", event => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      $("#chat-composer").requestSubmit();
    }
  });
  $("#chat-composer").addEventListener("submit", async event => {
    event.preventDefault();
    const box = $("#chat-message");
    const message = box.value.trim();
    if (!message || !state.chat.conversationId) return;
    const button = $("#chat-send");
    button.disabled = true;
    try {
      await api(`/api/whatsapp/conversations/${encodeURIComponent(state.chat.conversationId)}/messages`, { method: "POST", body: { text: message } });
      box.value = "";
      await openConversation(state.chat.conversationId);
    } catch (error) { handleError(error); } finally { button.disabled = false; }
  });
  $("#open-attendance-form").addEventListener("click", () => { $("#attendance-form").reset(); $("#attendance-form-dialog").showModal(); });
  $("#open-whatsapp-settings").addEventListener("click", () => openWhatsAppSettings().catch(handleError));
  $("#whatsapp-provider").addEventListener("change", updateWhatsAppFields);
  $("#whatsapp-settings-form").addEventListener("submit", async event => {
    event.preventDefault();
    try {
      const result = await api("/api/whatsapp-integration", { method: "POST", body: formData(event.currentTarget) });
      renderWhatsAppReadout(result, { verifyToken: result.verifyToken });
      toast("Integração salva. Copie a URL e o token de verificação para a Meta.");
      await loadAttendanceInbox();
    } catch (error) { handleError(error); }
  });
  $("#whatsapp-test").addEventListener("click", async () => {
    try {
      const result = await api("/api/whatsapp-integration/test", { method: "POST", body: {} });
      renderWhatsAppReadout(result);
      toast(`Conexão confirmada com o número ${result.displayPhoneNumber || "oficial"}.`);
    } catch (error) { handleError(error); }
  });
  $("#whatsapp-key").addEventListener("click", async () => {
    try {
      const result = await api("/api/whatsapp-integration/key", { method: "POST", body: {} });
      renderWhatsAppReadout(result, { key: result.key });
      toast("Chave gerada. Copie agora: ela não será exibida novamente.");
    } catch (error) { handleError(error); }
  });
  $("#whatsapp-disconnect").addEventListener("click", async () => {
    if (!confirm("Desligar a integração de WhatsApp? As conversas já recebidas continuam no sistema.")) return;
    try {
      const result = await api("/api/whatsapp-integration", { method: "DELETE" });
      renderWhatsAppReadout(result);
      toast("Integração desligada.");
      await loadAttendanceInbox();
    } catch (error) { handleError(error); }
  });
  $$("[data-close-dialog]").forEach(button => button.addEventListener("click", () => button.closest("dialog").close()));
  $("#toggle-attendance-filter").addEventListener("click", () => {
    const drawer = $("#attendance-history-filters");
    drawer.hidden = !drawer.hidden;
  });
  $("#clear-attendance-filter").addEventListener("click", () => {
    for (const id of ["attendance-history-from", "attendance-history-to", "attendance-history-user", "attendance-history-status", "attendance-history-client"]) $(`#${id}`).value = "";
    loadAttendanceHistory().catch(handleError);
  });
  $("#attendance-history-chips").addEventListener("click", event => {
    const button = event.target.closest("button[data-clear-filter]");
    if (!button) return;
    $(`#${button.dataset.clearFilter}`).value = "";
    loadAttendanceHistory().catch(handleError);
  });
  $("#refresh-attendance-history").addEventListener("click", () => loadAttendanceHistory().catch(handleError));
  $("#attendance-metrics-range").addEventListener("change", () => {
    const custom = $("#attendance-metrics-range").value === "custom";
    $$(".metrics-custom").forEach(element => { element.hidden = !custom; });
    if (!custom) loadAttendanceMetrics().catch(handleError);
  });
  $("#refresh-attendance-metrics").addEventListener("click", () => loadAttendanceMetrics().catch(handleError));
  $('#demand-form select[name="destinationSector"]').addEventListener("change", populateDemandUsers);
  $("#refresh-demands").addEventListener("click", () => loadDemands().catch(handleError));
  $("#attendance-form").addEventListener("submit", async event => {
    event.preventDefault();
    const form = event.currentTarget;
    try {
      await api("/api/attendances", { method: "POST", body: formData(form) });
      form.reset();
      populateForms();
      $("#attendance-form-dialog").close();
      toast("Solicitação adicionada à fila de atendimento.");
      await loadAttendanceInbox();
    } catch (error) { handleError(error); }
  });
  $("#demand-form").addEventListener("submit", async event => {
    event.preventDefault();
    const form = event.currentTarget;
    try {
      const payload = await demandPayload(form);
      await api("/api/demands", { method: "POST", body: payload });
      form.reset();
      populateDemandUsers();
      toast("Demanda enviada com os anexos.");
      await loadDemands();
    } catch (error) { handleError(error); }
  });
  $('#attendance-convert-form select[name="kind"]').addEventListener("change", updateConversionFields);
  $("#attendance-finish-form").addEventListener("submit", async event => {
    event.preventDefault();
    const data = formData(event.currentTarget);
    try {
      await api(`/api/attendances/${data.attendanceId}/finish`, { method: "POST", body: data });
      $("#attendance-finish-dialog").close();
      toast("Atendimento encerrado e tempo registrado.");
      state.chat.conversationId = "";
      await loadAttendanceInbox();
      if ($("#view-attendance-history").classList.contains("active")) await loadAttendanceHistory();
    } catch (error) { handleError(error); }
  });
  $("#attendance-convert-form").addEventListener("submit", async event => {
    event.preventDefault();
    const data = formData(event.currentTarget);
    try {
      await api(`/api/attendances/${data.attendanceId}/convert`, { method: "POST", body: data });
      $("#attendance-convert-dialog").close();
      toast(`${data.kind} criada no DP com vínculo ao atendimento.`);
      await loadBase();
      await loadAttendanceInbox();
    } catch (error) { handleError(error); }
  });

  $("#client-form").addEventListener("submit", event => {
    event.preventDefault();
    saveEntity(event.currentTarget, "/api/clients").catch(handleError);
  });
  $("#activity-form").addEventListener("submit", event => {
    event.preventDefault();
    saveEntity(event.currentTarget, "/api/activities", (data, form) => assignmentPayload(data, form, "activity")).catch(handleError);
  });
  $("#obligation-form").addEventListener("submit", event => {
    event.preventDefault();
    saveEntity(event.currentTarget, "/api/obligations", (data, form) => assignmentPayload(data, form, "obligation")).catch(handleError);
  });
  $("#user-form").addEventListener("submit", async event => {
    event.preventDefault();
    const form = event.currentTarget;
    try {
      const result = await api("/api/users", { method: "POST", body: formData(form) });
      form.reset();
      toast(`Acesso liberado para ${result.item.username}. O usuário já pode entrar.`);
      await loadBase();
    } catch (error) { handleError(error); }
  });
  $$(".cancel-edit").forEach(button => button.addEventListener("click", () => resetEdit(button.closest("form"))));

  document.body.addEventListener("click", async event => {
    const startRow = event.target.closest("tr[data-start-activity]");
    if (startRow && !event.target.closest("button, a")) {
      try { await startActivity(startRow.dataset.startActivity); } catch (error) { handleError(error); }
      return;
    }
    const button = event.target.closest("button[data-action]");
    if (!button) return;
    const { action, id } = button.dataset;
    try {
      if (action === "edit-client") fillForm($("#client-form"), state.clients.find(item => item.id === id));
      if (action === "edit-activity") fillForm($("#activity-form"), state.activities.find(item => item.id === id));
      if (action === "start-activity") await startActivity(id);
      if (action === "finish-activity") openActivityFinishDialog(state.activities.find(item => item.id === id));
      if (action === "open-budget") openBudgetDialog(id);
      if (action === "open-steps") openStepsDialog(id);
      if (action === "fix-activity-notes") {
        const atividade = state.activities.find(item => item.id === id);
        if (atividade) {
          const form = $("#activity-notes-form");
          form.reset();
          form.elements.activityId.value = atividade.id;
          form.elements.notes.value = atividade.notes || "";
          $("#activity-notes-label").textContent = `${atividade.task} · ${clientName(atividade.clientId)}`;
          $("#activity-notes-dialog").showModal();
        }
      }
      if (action === "delete-recurrence" && confirm(`Excluir a periodicidade ${id}?`)) {
        await api(`/api/recurrences/${encodeURIComponent(id)}`, { method: "DELETE" });
        await loadRecurrences();
        toast("Periodicidade excluída.");
      }
      if (action === "edit-step-template") {
        const modelo = state.stepTemplates.find(item => item.id === id);
        if (modelo) {
          const form = $("#step-template-form");
          form.elements.name.value = modelo.name;
          form.elements.steps.value = modelo.steps.join("\n");
          form.scrollIntoView({ behavior: "smooth", block: "center" });
        }
      }
      if (action === "delete-step-template" && confirm("Excluir este passo a passo? As obrigações já criadas mantêm as etapas delas.")) {
        await api(`/api/obligation-steps/${id}`, { method: "DELETE" });
        toast("Passo a passo excluído.");
        await loadStepTemplates();
      }
      if (action === "edit-administrative") editAdministrativeEntry(id);
      if (action === "delete-administrative" && confirm("Excluir esta despesa administrativa?")) {
        await api(`/api/administrative/entries/${id}`, { method: "DELETE" });
        toast("Despesa administrativa excluída e rateio recalculado.");
        await loadAdministrative();
      }
      if (action === "edit-obligation") fillForm($("#obligation-form"), state.obligations.find(item => item.id === id));
      if (action === "delete-client" && confirm("Excluir este cliente?")) await removeEntity("/api/clients", id);
      if (action === "delete-activity" && confirm("Excluir esta atividade?")) await removeEntity("/api/activities", id);
      if (action === "delete-obligation" && confirm("Excluir esta obrigação?")) await removeEntity("/api/obligations", id);
      if (action === "password-user") openPasswordDialog(state.users.find(item => item.id === id));
      if (action === "unlock-user") {
        const result = await api(`/api/users/${id}/unlock`, { method: "POST", body: {} });
        toast(`Acesso de ${result.username} liberado. Ele já pode tentar entrar de novo.`);
        await loadBase();
      }
      if (action === "toggle-user") {
        const user = state.users.find(item => item.id === id);
        await api(`/api/users/${id}`, { method: "PUT", body: { active: !user.active } });
        toast(user.active ? "Usuário desativado." : "Usuário ativado.");
        await loadBase();
      }
      if (action === "status-obligation") {
        const item = state.obligations.find(entry => entry.id === id);
        const next = prompt(`Novo status:\n${state.obligationStatus.join("\n")}`, item.status);
        if (next) {
          await api(`/api/obligations/${id}`, { method: "PUT", body: { status: next, notes: item.notes } });
          toast("Status atualizado.");
          await loadBase();
          await loadDashboard();
        }
      }
      if (action === "start-attendance") {
        await api(`/api/attendances/${id}/start`, { method: "POST", body: { assignedUserId: state.user.id } });
        toast("Atendimento assumido; o cronômetro está contando.");
        await loadAttendanceInbox();
      }
      if (action === "finish-attendance") openAttendanceFinish(attendanceById(id));
      if (action === "convert-attendance") openAttendanceConversion(attendanceById(id));
      if (action === "detail-attendance") openAttendanceDetail(attendanceById(id));
      if (action === "link-attendance-client") {
        const options = state.clients.filter(item => item.active).map(item => `${item.code || item.domainCode || ""} ${item.name}`.trim());
        const chosen = prompt(`Informe o nome ou código do cliente:\n${options.slice(0, 30).join("\n")}`, "");
        if (chosen) {
          const key = searchKey(chosen);
          const matches = state.clients.filter(item => item.active && searchKey(`${item.code} ${item.domainCode} ${item.name}`).includes(key));
          if (matches.length !== 1) throw new Error("Refine a busca: encontrei " + matches.length + " clientes.");
          await api(`/api/whatsapp/conversations/${encodeURIComponent(id)}/client`, { method: "POST", body: { clientId: matches[0].id } });
          toast("Cliente vinculado ao número.");
          await loadAttendanceInbox();
        }
      }
      if (action === "start-demand") {
        const demand = state.demands.find(item => item.id === id);
        await api(`/api/demands/${id}`, { method: "PUT", body: { status: "EM ANDAMENTO", assignedUserId: demand.assignedUserId || state.user.id } });
        toast("Demanda iniciada.");
        await loadDemands();
      }
      if (action === "finish-demand") {
        await api(`/api/demands/${id}`, { method: "PUT", body: { status: "CONCLUÍDA" } });
        toast("Demanda concluída.");
        await loadDemands();
      }
    } catch (error) { handleError(error); }
  });

  $("#budget-form").addEventListener("submit", async event => {
    event.preventDefault();
    const form = event.currentTarget;
    const data = formData(form);
    try {
      await api(`/api/budgets/${data.clientId}`, { method: "PUT", body: data });
      $("#budget-dialog").close();
      toast("Custos e receitas extras salvos. Comparação por hora recalculada.");
      await loadBudgets();
    } catch (error) { handleError(error); }
  });

  $("#administrative-form").addEventListener("submit", async event => {
    event.preventDefault();
    const form = event.currentTarget;
    const data = formData(form);
    const editing = Boolean(data.id);
    try {
      await api(editing ? `/api/administrative/entries/${data.id}` : "/api/administrative/entries", {
        method: editing ? "PUT" : "POST", body: data
      });
      toast(editing ? "Despesa atualizada e rateio recalculado." : "Despesa adicionada e rateio recalculado.");
      await loadAdministrative();
    } catch (error) { handleError(error); }
  });
  $("#administrative-cancel").addEventListener("click", resetAdministrativeForm);

  $("#password-form").addEventListener("submit", async event => {
    event.preventDefault();
    const data = formData(event.currentTarget);
    if (data.password !== data.confirmPassword) return toast("As senhas não conferem.", true);
    try {
      await api(`/api/users/${data.userId}/password`, { method: "PUT", body: { password: data.password } });
      const dialog = $("#password-dialog");
      const required = dialog.dataset.required === "1";
      if (data.userId === state.user.id) state.user.mustChangePassword = false;
      dialog.dataset.required = "";
      $("#password-dialog-close").hidden = false;
      dialog.close();
      toast("Senha alterada com sucesso.");
      if (required) {
        await loadBase();
        await loadDashboard();
      }
    } catch (error) { handleError(error); }
  });
  $("#password-dialog").addEventListener("cancel", event => {
    if (event.currentTarget.dataset.required === "1") event.preventDefault();
  });

  $("#activity-finish-form").addEventListener("submit", async event => {
    event.preventDefault();
    const data = formData(event.currentTarget);
    try {
      const result = await api(`/api/activities/${data.activityId}/finish`, { method: "POST", body: { notes: data.notes } });
      $("#activity-finish-dialog").close();
      toast(`Atividade finalizada às ${result.item.end}. Tempo registrado: ${minutesLabel(result.item.totalMinutes)}.`);
      await loadBase();
      await loadDashboard();
    } catch (error) { handleError(error); }
  });

  $("#install-app").addEventListener("click", async () => {
    if (!state.installPrompt) return;
    state.installPrompt.prompt();
    await state.installPrompt.userChoice;
    state.installPrompt = null;
    $("#install-app").hidden = true;
  });
}

async function removeEntity(endpoint, id) {
  await api(`${endpoint}/${id}`, { method: "DELETE" });
  toast("Registro excluído.");
  await loadBase();
  await loadDashboard();
}

async function afterAuthentication(initialView = "dashboard") {
  const me = await api("/api/me");
  Object.assign(state, {
    csrf: me.csrf, user: me.user, officeName: me.officeName,
    activityStatus: me.activityStatus, obligationStatus: me.obligationStatus,
    timeClockTypes: me.timeClockTypes
  });
  showApp(initialView);
  if (state.user.mustChangePassword) {
    openPasswordDialog(state.user, true);
    return;
  }
  await loadBase();
  await loadDashboard();
}

async function initialize() {
  attachEvents();
  await api("/api/branding").then(applyBranding).catch(() => {});
  const today = todayValue();
  $("#dashboard-from").value = `${today.slice(0, 7)}-01`;
  $("#dashboard-to").value = today;
  $("#activity-form").elements.date.value = today;
  $("#obligation-form").elements.period.value = today.slice(0, 7);
  $("#time-from").value = `${today.slice(0, 7)}-01`;
  $("#time-to").value = today;
  $("#time-adjust-form").elements.date.value = today;
  $("#administrative-period").value = today.slice(0, 7);
  $("#panel-period").value = today.slice(0, 7);
  $("#export-from").value = `${today.slice(0, 7)}-01`;
  $("#export-to").value = today;
  $("#budget-period").value = today.slice(0, 7);
  $("#attendance-history-from").value = `${today.slice(0, 7)}-01`;
  $("#attendance-history-to").value = today;
  $("#attendance-metrics-from").value = `${today.slice(0, 7)}-01`;
  $("#attendance-metrics-to").value = today;

  const updateClock = () => {
    $("#clock-live").textContent = new Intl.DateTimeFormat("pt-BR", { hour: "2-digit", minute: "2-digit", second: "2-digit" }).format(new Date());
  };
  updateClock();
  setInterval(updateClock, 1000);
  setInterval(() => {
    if (state.user && $("#view-dashboard").classList.contains("active") && !document.hidden) loadDashboard().catch(() => {});
  }, 30000);
  setInterval(() => {
    if (state.user && $("#view-activities").classList.contains("active") && !document.hidden) refreshActivityState().catch(() => {});
  }, 30000);
  setInterval(() => {
    if (!state.user || document.hidden || !["ADMIN", "GESTOR"].includes(state.user.role)) return;
    if ($("#view-attendance-inbox").classList.contains("active")) loadAttendanceInbox().catch(() => {});
  }, 15000);

  window.addEventListener("online", () => { $("#connection-banner").hidden = true; });
  window.addEventListener("offline", () => { $("#connection-banner").hidden = false; });
  window.addEventListener("resize", () => {
    const layout = isMobileSidebar() ? "mobile" : "desktop";
    if ($("#app-view").dataset.sidebarLayout !== layout) restoreSidebarPreference();
  });
  window.addEventListener("beforeinstallprompt", event => {
    event.preventDefault();
    state.installPrompt = event;
    $("#install-app").hidden = false;
  });
  if ("serviceWorker" in navigator && window.isSecureContext) navigator.serviceWorker.register("/service-worker.js").catch(console.warn);

  try {
    const status = await api("/api/status");
    state.officeName = status.officeName;
    if (status.setupRequired) return showOnly("setup-view");
    try { await afterAuthentication(); } catch { showLogin(); }
  } catch (error) {
    showLogin();
    handleError(error);
  }
}

initialize();
