@echo off
setlocal
cd /d "%~dp0"
echo.
echo  Libera acesso bloqueado por tentativas de senha.
echo  Use com o servidor PARADO.
echo.
runtime\node.exe tools\liberar-acesso.js %*
echo.
pause
endlocal
