param([switch]$NoOpen)

. (Join-Path $PSScriptRoot "common.ps1")

$root = Get-DashboardRoot
$config = Get-DashboardConfig -Root $root
$port = [int]$config.port
$localUrl = "http://127.0.0.1:$port"
$healthUrl = "$localUrl/api/health"

try {
  $health = Invoke-RestMethod -Uri $healthUrl -TimeoutSec 2
  if ($health.ok) {
    Write-Host "O Dashboard Fiscal já está em execução." -ForegroundColor Green
    if (-not $NoOpen) { Open-DashboardApp -Url $localUrl }
    return
  }
} catch {}

$node = Get-DashboardNode -Root $root
$dataDir = Join-Path $root "data"
$logDir = Join-Path $dataDir "logs"
New-Item -ItemType Directory -Path $logDir -Force | Out-Null

$stderr = Join-Path $logDir "erros.log"
$startInfo = New-Object System.Diagnostics.ProcessStartInfo
$startInfo.FileName = $node
$startInfo.Arguments = "server.js"
$startInfo.WorkingDirectory = $root
$startInfo.UseShellExecute = $false
$startInfo.CreateNoWindow = $true
$process = [System.Diagnostics.Process]::Start($startInfo)

$ready = $false
for ($attempt = 0; $attempt -lt 30; $attempt++) {
  Start-Sleep -Milliseconds 300
  if ($process.HasExited) { break }
  try {
    $health = Invoke-RestMethod -Uri $healthUrl -TimeoutSec 1
    if ($health.ok) { $ready = $true; break }
  } catch {}
}

if (-not $ready) {
  if (-not $process.HasExited) {
    $process.Kill()
    $process.WaitForExit(5000)
  }
  $detail = if (Test-Path -LiteralPath $stderr) { Get-Content -LiteralPath $stderr -Tail 8 -ErrorAction SilentlyContinue | Out-String } else { "" }
  throw "Não foi possível iniciar o servidor. Consulte data\logs\erros.log. $detail"
}

$networkUrls = @(Get-LocalIpv4 | ForEach-Object { "http://${_}:$port" })
$addressFile = Join-Path $root "ENDERECOS_DO_ESCRITORIO.txt"
$addressLines = @(
  "DASHBOARD FISCAL OFFICE",
  "",
  "Neste computador: http://localhost:$port",
  "",
  "Endereços para os outros computadores:"
) + $networkUrls + @(
  "",
  "Use INSTALAR_CLIENTE.cmd nos demais computadores e informe um dos endereços acima.",
  "Mantenha este computador ligado enquanto a equipe estiver usando o sistema."
)
$addressLines | Set-Content -LiteralPath $addressFile -Encoding UTF8

Write-Host "Dashboard Fiscal iniciado com segurança." -ForegroundColor Green
Write-Host "Acesso local: http://localhost:$port"
foreach ($url in $networkUrls) { Write-Host "Acesso na rede: $url" -ForegroundColor Cyan }
if (-not $NoOpen) { Open-DashboardApp -Url $localUrl }
