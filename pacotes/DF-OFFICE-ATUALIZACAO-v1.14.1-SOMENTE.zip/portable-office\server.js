"use strict";

const http = require("node:http");
const fs = require("node:fs/promises");
const path = require("node:path");
const crypto = require("node:crypto");
const os = require("node:os");
const { URL } = require("node:url");
const { JsonStore } = require("./lib/store");
const { createWhatsAppApi } = require("./lib/whatsapp-api");
const { buildAdministrativeExcel, buildAdministrativePdf } = require("./lib/report-exports");
const { buildObligationPanel, buildMovements, MOVEMENT_TYPES } = require("./lib/gestao");
const {
  createToken,
  hashPassword,
  hashInitialPassword,
  normalizeUsername,
  parseCookies,
  safeUser,
  verifyPassword
} = require("./lib/security");

const APP_VERSION = "1.14.1";
const obligationCatalog = require("./seed/obrigacoes-mapeamento.json");
const CLIENT_SEED_FILE = "empresas-fg-julho-2026.json";
const TEAM_SEED_FILE = "equipe-fg.json";
const COOKIE_NAME = "df_session";
const ROLES = ["ADMIN", "GESTOR", "COLABORADOR"];
const SECTORS = ["DP", "FISCAL/CONTABIL", "GESTAO", "ADMIN"];
const SECTOR_ROLES = {
  DP: "COLABORADOR",
  "FISCAL/CONTABIL": "COLABORADOR",
  GESTAO: "GESTOR",
  ADMIN: "ADMIN"
};
const COMPANY_TYPES = ["SIMPLES NACIONAL", "LUCRO PRESUMIDO", "LUCRO REAL", "IMUNE", "MEI"];
const COMPANY_TYPE_ALIASES = {
  "SIMPLES": "SIMPLES NACIONAL",
  "EMPRESA SIMPLES": "SIMPLES NACIONAL",
  "EMPRESAS SIMPLES": "SIMPLES NACIONAL",
  "EMPRESA SILMPLES": "SIMPLES NACIONAL",
  "EMPRESAS SILMPLES": "SIMPLES NACIONAL",
  "EMPRESA LUCRO PRESUMIDO": "LUCRO PRESUMIDO",
  "EMPRESAS LUCRO PRESUMIDO": "LUCRO PRESUMIDO",
  "EMPRESA LUCRO REAL": "LUCRO REAL",
  "EMPRESAS LUCRO REAL": "LUCRO REAL",
  "EMPRESA IMUNE": "IMUNE",
  "EMPRESAS IMUNES": "IMUNE",
  "EMPRESA MEI": "MEI",
  "EMPRESAS MEI": "MEI"
};
const ADMINISTRATIVE_COST_FIELDS = [
  { key: "structureCost", label: "Estrutura" },
  { key: "equipmentCost", label: "Equipamentos" },
  { key: "maintenanceCost", label: "Manutenção" },
  { key: "systemsCost", label: "Sistemas" },
  { key: "employeeCost", label: "Funcionários" },
  { key: "taxCost", label: "Impostos" },
  { key: "financingCost", label: "Despesas de financiamento" }
];
const LEGACY_BUDGET_COST_FIELDS = ADMINISTRATIVE_COST_FIELDS.map(item => item.key);
const ACTIVITY_STATUS = ["EM ANDAMENTO", "EM ATRASO", "EM ATIVIDADE", "CONCLUÍDO", "CANCELADA"];
// Periodicidade da obrigação. O escritório pode acrescentar outras pela tela.
// Quatro senhas erradas bloqueiam a conta. Não há liberação por tempo:
// só um gestor ou administrador libera, trocando a senha ou pelo botão Liberar bloqueio.
const MAX_LOGIN_ATTEMPTS = 4;
const DEFAULT_RECURRENCES = ["MENSAL", "ANUAL", "ESPORÁDICA"];
const OBLIGATION_STATUS = [
  "PENDENTE", "EM ANDAMENTO", "LIBERADO CONFERÊNCIA", "LIBERADO TRANSMISSÃO",
  "TRANSMITIDO", "ENVIADO", "DISPENSADO", "NÃO PRECISA ENVIAR"
];
// Gestão e administração não batem ponto; apenas o colaborador registra jornada.
const TIME_CLOCK_ROLES = ["COLABORADOR"];
// Atividades podem ser atribuídas a colaboradores e também a gestores.
const ACTIVITY_ROLES = ["COLABORADOR", "GESTOR"];
// Gestão tem a mesma visão e os mesmos direitos da administração.
const ADMIN_ROLES = ["ADMIN", "GESTOR"];
const TIME_CLOCK_TYPES = ["ENTRADA", "SAIDA_ALMOCO", "RETORNO_ALMOCO", "SAIDA"];
const TIME_CLOCK_LABELS = {
  ENTRADA: "Entrada",
  SAIDA_ALMOCO: "Saída para almoço",
  RETORNO_ALMOCO: "Retorno do almoço",
  SAIDA: "Saída final"
};
const ATTENDANCE_STATUS = ["PENDENTE", "EM ATENDIMENTO", "FINALIZADO", "DESCONSIDERADO"];
const DEMAND_STATUS = ["PENDENTE", "EM ANDAMENTO", "CONCLUÍDA", "CANCELADA"];
const DEMAND_PRIORITIES = ["BAIXA", "NORMAL", "ALTA", "URGENTE"];
const ATTACHMENT_TYPES = new Map([
  ["application/pdf", ".pdf"], ["image/jpeg", ".jpg"], ["image/png", ".png"],
  ["application/vnd.openxmlformats-officedocument.wordprocessingml.document", ".docx"],
  ["application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", ".xlsx"],
  ["text/plain", ".txt"]
]);

function readJsonFile(file, fallback) {
  return fs.readFile(file, "utf8").then(raw => JSON.parse(raw.replace(/^\uFEFF/, ""))).catch(error => {
    if (error.code === "ENOENT") return fallback;
    throw error;
  });
}

function text(value, max = 240) {
  return String(value ?? "").trim().slice(0, max);
}

function upper(value, max = 120) {
  return text(value, max).toLocaleUpperCase("pt-BR");
}

function normalizeSector(value) {
  const sector = upper(value, 30).replace(/\s+/g, "");
  return SECTORS.includes(sector) ? sector : "";
}

function sectorForRole(role) {
  if (role === "ADMIN") return "ADMIN";
  if (role === "GESTOR") return "GESTAO";
  return "FISCAL/CONTABIL";
}

function normalizeCompanyType(value) {
  const raw = upper(value, 80);
  const normalized = COMPANY_TYPE_ALIASES[raw] || raw;
  return COMPANY_TYPES.includes(normalized) ? normalized : "";
}

function identifierList(value, limit = 5000) {
  let values = value;
  if (!Array.isArray(values)) {
    const raw = text(values, 100000);
    if (!raw) return [];
    try {
      const parsed = JSON.parse(raw);
      values = Array.isArray(parsed) ? parsed : [raw];
    } catch {
      values = raw.split(",");
    }
  }
  return [...new Set(values.map(item => text(item, 80)).filter(Boolean))].slice(0, limit);
}

function clientFields(body = {}, current = {}) {
  return {
    code: upper(body.code ?? current.code, 30),
    name: text(body.name ?? current.name, 160),
    cnpj: String(body.cnpj ?? current.cnpj ?? "").replace(/\D/g, "").slice(0, 14),
    stateRegistration: upper(body.stateRegistration ?? current.stateRegistration, 40),
    municipalRegistration: upper(body.municipalRegistration ?? current.municipalRegistration, 40),
    responsibleCpf: String(body.responsibleCpf ?? current.responsibleCpf ?? "").replace(/\D/g, "").slice(0, 11),
    domainCode: upper(body.domainCode ?? current.domainCode, 30),
    city: upper(body.city ?? current.city, 100),
    businessActivity: upper(body.businessActivity ?? current.businessActivity, 120),
    whatsappPhone: String(body.whatsappPhone ?? current.whatsappPhone ?? "").replace(/\D/g, "").slice(0, 15),
    taxRegime: normalizeCompanyType(body.taxRegime ?? current.taxRegime)
  };
}

function dateValue(value, allowEmpty = true) {
  const raw = text(value, 10);
  if (!raw && allowEmpty) return "";
  if (!/^\d{4}-\d{2}-\d{2}$/.test(raw) || Number.isNaN(Date.parse(`${raw}T00:00:00`))) {
    throw new Error("Data inválida.");
  }
  return raw;
}

function periodValue(value) {
  const raw = text(value, 7);
  if (!/^\d{4}-\d{2}$/.test(raw)) throw new Error("Competência inválida.");
  return raw;
}

function numberValue(value, min = 0, max = 1000000) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < min || parsed > max) throw new Error("Número inválido.");
  return parsed;
}

function moneyValue(value) {
  if (value === "" || value === null || value === undefined) return 0;
  let raw = String(value).trim().replace(/R\$/gi, "").replace(/\s/g, "").replace(/[^\d,.-]/g, "");
  if (raw.includes(",")) raw = raw.replace(/\./g, "").replace(",", ".");
  else if ((raw.match(/\./g) || []).length > 1) {
    const parts = raw.split(".");
    raw = `${parts.slice(0, -1).join("")}.${parts.at(-1)}`;
  } else if (/^-?\d{1,3}\.\d{3}$/.test(raw)) raw = raw.replace(".", "");
  const parsed = Number(raw);
  if (!Number.isFinite(parsed) || parsed < 0 || parsed > 1000000000) throw new Error("Valor financeiro inválido.");
  return Math.round((parsed + Number.EPSILON) * 100) / 100;
}

function roundMetric(value) {
  return Math.round((Number(value || 0) + Number.EPSILON) * 100) / 100;
}

function timeValue(value) {
  const raw = text(value, 5);
  const match = raw.match(/^(\d{2}):(\d{2})$/);
  if (!match || Number(match[1]) > 23 || Number(match[2]) > 59) throw new Error("Horário inválido.");
  return raw;
}

function timeMinutes(value) {
  if (!value) return null;
  const [hour, minute] = value.split(":").map(Number);
  return hour * 60 + minute;
}

function timeClockSummary(entries) {
  const byType = Object.fromEntries(entries.map(item => [item.type, item]));
  const morningStart = timeMinutes(byType.ENTRADA?.time);
  const morningEnd = timeMinutes(byType.SAIDA_ALMOCO?.time);
  const afternoonStart = timeMinutes(byType.RETORNO_ALMOCO?.time);
  const afternoonEnd = timeMinutes(byType.SAIDA?.time);
  let totalMinutes = 0;
  if (morningStart !== null && morningEnd !== null && morningEnd >= morningStart) totalMinutes += morningEnd - morningStart;
  if (afternoonStart !== null && afternoonEnd !== null && afternoonEnd >= afternoonStart) totalMinutes += afternoonEnd - afternoonStart;
  const nextAction = TIME_CLOCK_TYPES.find(type => !byType[type]) || null;
  const hasAll = nextAction === null;
  const validOrder = !hasAll || [morningStart, morningEnd, afternoonStart, afternoonEnd].every(value => value !== null)
    && morningStart <= morningEnd && morningEnd <= afternoonStart && afternoonStart <= afternoonEnd;
  return { byType, totalMinutes, nextAction, hasAll, validOrder, complete: hasAll && validOrder, invalidOrder: hasAll && !validOrder };
}

function csvEscape(value) {
  const raw = String(value ?? "");
  return /[";\r\n]/.test(raw) ? `"${raw.replace(/"/g, '""')}"` : raw;
}

function toCsv(rows, columns) {
  const lines = [columns.map(column => csvEscape(column.label)).join(";")];
  for (const row of rows) lines.push(columns.map(column => csvEscape(row[column.key])).join(";"));
  return `\uFEFF${lines.join("\r\n")}`;
}

function getNetworkAddresses(port) {
  const addresses = [];
  for (const list of Object.values(os.networkInterfaces())) {
    for (const item of list || []) {
      if (item.family === "IPv4" && !item.internal) addresses.push(`http://${item.address}:${port}`);
    }
  }
  return addresses;
}

async function createApplication(options = {}) {
  const baseDir = __dirname;
  const fileConfig = await readJsonFile(path.join(baseDir, "config.json"), {});
  const config = {
    host: options.host ?? process.env.DASHBOARD_FISCAL_HOST ?? fileConfig.host ?? "0.0.0.0",
    port: Number(options.port ?? process.env.DASHBOARD_FISCAL_PORT ?? fileConfig.port ?? 8787),
    sessionHours: Number(options.sessionHours ?? fileConfig.sessionHours ?? 12),
    backupRetentionDays: Number(options.backupRetentionDays ?? fileConfig.backupRetentionDays ?? 30),
    timeZone: options.timeZone ?? fileConfig.timeZone ?? "America/Sao_Paulo",
    importBundledClients: options.importBundledClients ?? fileConfig.importBundledClients ?? true,
    importBundledTeam: options.importBundledTeam ?? fileConfig.importBundledTeam ?? true,
    whatsappWebhookToken: text(options.whatsappWebhookToken ?? process.env.DF_WHATSAPP_WEBHOOK_TOKEN ?? fileConfig.whatsappWebhookToken, 240)
  };
  const dataDir = options.dataDir || process.env.DASHBOARD_FISCAL_DATA_DIR || path.join(baseDir, "data");
  const publicDir = path.join(baseDir, "public");
  const store = await new JsonStore(dataDir, config).init();
  const logDir = path.join(dataDir, "logs");
  const attachmentDir = path.join(dataDir, "attachments");
  const brandingDir = path.join(dataDir, "branding");
  await fs.mkdir(logDir, { recursive: true });
  await fs.mkdir(attachmentDir, { recursive: true });
  await fs.mkdir(brandingDir, { recursive: true });
  const sessions = new Map();
  const officeClock = new Intl.DateTimeFormat("en-CA", {
    timeZone: config.timeZone, year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23"
  });

  function officeNow(date = new Date()) {
    const parts = Object.fromEntries(officeClock.formatToParts(date).filter(part => part.type !== "literal").map(part => [part.type, part.value]));
    return { date: `${parts.year}-${parts.month}-${parts.day}`, time: `${parts.hour}:${parts.minute}`, second: parts.second };
  }

  // Identidade que acompanha o sistema. Vale enquanto o escritório não enviar a própria.
  const DEFAULT_BRANDING = {
    companyName: "FG Consultoria",
    primaryColor: "#2d2e6e",
    logoFile: path.join(baseDir, "seed", "branding", "logo-fg.png"),
    logoMime: "image/png",
    logoVersion: "fg-1"
  };

  const BRANDING_IMAGE_TYPES = new Map([
    ["image/png", ".png"], ["image/jpeg", ".jpg"], ["image/svg+xml", ".svg"], ["image/webp", ".webp"]
  ]);

  function brandingPublic() {
    const saved = store.data.meta.branding || {};
    const versao = saved.logo?.file ? saved.logo.updatedAt || "1" : DEFAULT_BRANDING.logoVersion;
    return {
      companyName: text(saved.companyName || store.data.meta.officeName || DEFAULT_BRANDING.companyName, 120),
      primaryColor: /^#[0-9a-f]{6}$/i.test(saved.primaryColor || "") ? saved.primaryColor : DEFAULT_BRANDING.primaryColor,
      logoUrl: `/api/branding/logo?v=${encodeURIComponent(versao)}`,
      usingDefaultLogo: !saved.logo?.file,
      updatedAt: saved.updatedAt || null
    };
  }

  function recordError(error, context = "servidor") {
    const message = error?.stack || error?.message || String(error);
    const line = `[${new Date().toISOString()}] ${context}: ${message}\n`;
    fs.appendFile(path.join(logDir, "erros.log"), line, "utf8").catch(() => {});
    console.error(line.trim());
  }

  function audit(draft, user, action, entity, entityId, details, req) {
    draft.audit.push({
      id: crypto.randomUUID(),
      at: new Date().toISOString(),
      userId: user?.id || null,
      username: user?.username || "sistema",
      action,
      entity,
      entityId: entityId || null,
      details: text(details, 500),
      ip: text(req?.socket?.remoteAddress, 80)
    });
  }

  async function importBundledClients() {
    if (!config.importBundledClients) return { added: 0, merged: 0, skipped: true };
    const seed = await readJsonFile(path.join(baseDir, "seed", CLIENT_SEED_FILE), null);
    if (!seed?.seedId || !Array.isArray(seed.clients)) throw new Error("Arquivo de empresas incorporadas inválido.");
    if (store.data.meta.seedImports?.[seed.seedId]) return { ...store.data.meta.seedImports[seed.seedId], skipped: true };

    let result = { added: 0, merged: 0, total: seed.clients.length, importedAt: new Date().toISOString() };
    await store.transaction(draft => {
      draft.meta.seedImports ||= {};
      if (draft.meta.seedImports[seed.seedId]) {
        result = { ...draft.meta.seedImports[seed.seedId], skipped: true };
        return;
      }
      for (const source of seed.clients) {
        const incoming = clientFields(source);
        const normalizedName = incoming.name.toLocaleUpperCase("pt-BR");
        const existing = draft.clients.find(item => (incoming.cnpj && item.cnpj === incoming.cnpj)
          || (incoming.domainCode && upper(item.domainCode, 30) === incoming.domainCode)
          || upper(item.name, 160) === normalizedName);
        if (existing) {
          for (const [key, value] of Object.entries(incoming)) if (!existing[key] && value) existing[key] = value;
          existing.updatedAt ||= result.importedAt;
          result.merged += 1;
          continue;
        }
        let code = incoming.code || `FG-${String(source.sourceRow || result.added + 1).padStart(3, "0")}`;
        if (draft.clients.some(item => item.code === code)) code = `FG-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
        draft.clients.push({
          id: crypto.randomUUID(), ...incoming, code, active: true,
          importSource: seed.seedId, createdAt: result.importedAt, updatedAt: result.importedAt
        });
        result.added += 1;
      }
      draft.meta.seedImports[seed.seedId] = result;
      audit(draft, null, "IMPORTAR", "CLIENTES", null, `${result.added} empresas adicionadas e ${result.merged} conciliadas (${seed.source || seed.seedId})`, null);
    });
    return result;
  }

  async function ensureUserSectors() {
    if (!store.data.users.some(user => !normalizeSector(user.sector))) return;
    await store.transaction(draft => {
      for (const user of draft.users) if (!normalizeSector(user.sector)) user.sector = sectorForRole(user.role);
    });
  }

  async function importBundledTeam() {
    if (!config.importBundledTeam || !store.data.users.length) return { added: 0, merged: 0, skipped: true };
    const seed = await readJsonFile(path.join(baseDir, "seed", TEAM_SEED_FILE), null);
    if (!seed?.seedId || !Array.isArray(seed.users)) throw new Error("Arquivo da equipe incorporada inválido.");
    if (store.data.meta.teamSeedImports?.[seed.seedId]) return { ...store.data.meta.teamSeedImports[seed.seedId], skipped: true };

    const prepared = [];
    for (const source of seed.users) {
      const sector = normalizeSector(source.sector);
      const username = normalizeUsername(source.username);
      if (!text(source.name, 120) || username.length < 3 || !sector) throw new Error("Usuário incorporado inválido.");
      const exists = store.data.users.some(user => user.username === username);
      if (exists) prepared.push({ source, sector, username, existing: true });
      else {
        const password = "123456";
        prepared.push({ source, sector, username, password, passwordHash: await hashInitialPassword(), existing: false });
      }
    }

    const importedAt = new Date().toISOString();
    let result = { added: 0, merged: 0, total: prepared.length, importedAt, accessFile: "" };
    await store.transaction(draft => {
      draft.meta.teamSeedImports ||= {};
      if (draft.meta.teamSeedImports[seed.seedId]) {
        result = { ...draft.meta.teamSeedImports[seed.seedId], skipped: true };
        return;
      }
      for (const entry of prepared) {
        const existing = draft.users.find(user => user.username === entry.username);
        if (existing) {
          existing.name = text(entry.source.name, 120);
          existing.sector = entry.sector;
          existing.role = SECTOR_ROLES[entry.sector];
          existing.active = true;
          existing.updatedAt = importedAt;
          result.merged += 1;
          continue;
        }
        draft.users.push({
          id: crypto.randomUUID(), name: text(entry.source.name, 120), username: entry.username,
          passwordHash: entry.passwordHash, sector: entry.sector, role: SECTOR_ROLES[entry.sector],
          active: true, mustChangePassword: true, importSource: seed.seedId,
          createdAt: importedAt, updatedAt: importedAt
        });
        result.added += 1;
      }
      draft.meta.teamSeedImports[seed.seedId] = result;
      audit(draft, null, "IMPORTAR", "USUARIOS", null, `${result.added} acessos adicionados e ${result.merged} conciliados`, null);
    });

    const credentials = prepared.filter(entry => !entry.existing);
    if (credentials.length) {
      const accessFile = "ACESSOS_INICIAIS_EQUIPE_FG.txt";
      const lines = [
        "DASHBOARD FISCAL OFFICE - ACESSOS TEMPORARIOS", "",
        "Cada usuário deve trocar a senha no primeiro acesso.", "Selecione também o setor indicado na tela de login.", ""
      ];
      for (const entry of credentials) {
        lines.push(`Nome: ${text(entry.source.name, 120)}`);
        lines.push(`Setor: ${entry.sector}`);
        lines.push(`Usuário: ${entry.username}`);
        lines.push(`Senha temporária: ${entry.password}`);
        lines.push("");
      }
      await fs.writeFile(path.join(dataDir, accessFile), `${lines.join("\r\n")}\r\n`, { encoding: "utf8", mode: 0o600 });
      result.accessFile = accessFile;
      await store.transaction(draft => { draft.meta.teamSeedImports[seed.seedId].accessFile = accessFile; });
    }
    return result;
  }

  async function ensureJosneManagement() {
    const marker = "josne-gestao-v1";
    if (store.data.meta.migrations?.[marker]) return false;
    const current = store.data.users.find(user => user.username === "josne");
    if (!current) return false;
    await store.transaction(draft => {
      draft.meta.migrations ||= {};
      if (draft.meta.migrations[marker]) return;
      const user = draft.users.find(item => item.username === "josne");
      if (user) {
        user.sector = "GESTAO";
        user.role = "GESTOR";
        user.updatedAt = new Date().toISOString();
        audit(draft, null, "MIGRAR", "USUARIO", user.id, "Josne transferida para GESTAO/GESTOR; senha e histórico preservados", null);
      }
      draft.meta.migrations[marker] = new Date().toISOString();
    });
    return true;
  }

  await ensureUserSectors();
  await importBundledClients();
  await importBundledTeam();
  await ensureJosneManagement();

  async function refreshOverdueActivities() {
    const now = Date.now();
    const hasExpired = store.data.activities.some(item => item.status === "EM ANDAMENTO"
      && item.startDeadlineAt && Date.parse(item.startDeadlineAt) <= now);
    if (!hasExpired) return false;
    await store.transaction(draft => {
      for (const item of draft.activities) {
        if (item.status !== "EM ANDAMENTO" || !item.startDeadlineAt || Date.parse(item.startDeadlineAt) > now) continue;
        item.status = "EM ATRASO";
        item.overdueAt = new Date(now).toISOString();
        item.updatedAt = item.overdueAt;
        audit(draft, null, "ATRASAR", "ATIVIDADE", item.id, `${item.task} não iniciada em 30 minutos`, null);
      }
    });
    return true;
  }

  function send(res, status, payload, headers = {}) {
    const binary = Buffer.isBuffer(payload);
    const body = binary ? payload : (typeof payload === "string" ? payload : JSON.stringify(payload));
    res.writeHead(status, {
      "Content-Type": binary ? "application/octet-stream" : (typeof payload === "string" ? "text/plain; charset=utf-8" : "application/json; charset=utf-8"),
      "Content-Length": binary ? body.length : Buffer.byteLength(body),
      "Cache-Control": "no-store",
      ...headers
    });
    res.end(body);
  }

  function sendError(res, status, message) {
    send(res, status, { ok: false, error: message });
  }

  async function parseBody(req, maxBytes = 1024 * 1024) {
    let size = 0;
    const chunks = [];
    for await (const chunk of req) {
      size += chunk.length;
      if (size > maxBytes) throw Object.assign(new Error("Requisição muito grande."), { status: 413 });
      chunks.push(chunk);
    }
    if (!chunks.length) return {};
    try {
      return JSON.parse(Buffer.concat(chunks).toString("utf8"));
    } catch {
      throw Object.assign(new Error("JSON inválido."), { status: 400 });
    }
  }

  function setSecurityHeaders(req, res) {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-Frame-Options", "DENY");
    res.setHeader("Referrer-Policy", "no-referrer");
    res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
    res.setHeader(
      "Content-Security-Policy",
      "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; font-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
    );
    if (req.url === "/service-worker.js") res.setHeader("Service-Worker-Allowed", "/");
  }

  function findSession(req) {
    const token = parseCookies(req.headers.cookie)[COOKIE_NAME];
    if (!token) return null;
    const session = sessions.get(token);
    if (!session || session.expiresAt <= Date.now()) {
      sessions.delete(token);
      return null;
    }
    const user = store.data.users.find(item => item.id === session.userId && item.active);
    if (!user) return null;
    session.expiresAt = Date.now() + config.sessionHours * 3600000;
    return { token, session, user };
  }

  function requireSession(req, res, roles) {
    const auth = findSession(req);
    if (!auth) {
      sendError(res, 401, "Sessão inválida ou expirada.");
      return null;
    }
    if (roles && !roles.includes(auth.user.role)) {
      sendError(res, 403, "Você não tem permissão para esta operação.");
      return null;
    }
    return auth;
  }

  function checkMutation(req, res, auth) {
    const origin = req.headers.origin;
    if (origin) {
      const expected = `${req.socket.encrypted ? "https" : "http"}://${req.headers.host}`;
      if (origin !== expected) {
        sendError(res, 403, "Origem inválida.");
        return false;
      }
    }
    if (req.headers["x-csrf-token"] !== auth.session.csrf) {
      sendError(res, 403, "Token de segurança inválido.");
      return false;
    }
    return true;
  }

  function visibleActivities(data, user) {
    return user.role === "COLABORADOR" ? data.activities.filter(item => item.userId === user.id) : data.activities;
  }

  // Gestão e administração têm os mesmos direitos sobre as contas.
  function recurrenceOptions() {
    const saved = store.data.meta.recurrenceOptions;
    return Array.isArray(saved) && saved.length ? saved : [...DEFAULT_RECURRENCES];
  }

  // Aceita o que já existe na lista; uma periodicidade nova precisa ser cadastrada antes.
  function recurrenceValue(value, atual = "") {
    const escolhida = upper(value ?? atual, 40);
    if (!escolhida) return "";
    if (!recurrenceOptions().includes(escolhida)) throw new Error("Periodicidade não cadastrada. Inclua na lista antes de usar.");
    return escolhida;
  }

  function canManageUser(actor) {
    return ADMIN_ROLES.includes(actor.role);
  }

  function visibleObligations(data, user) {
    return user.role === "COLABORADOR"
      ? data.obligations.filter(item => item.responsibleId === user.id)
      : data.obligations;
  }

  function visibleTimeEntries(data, user) {
    return user.role === "COLABORADOR" ? data.timeEntries.filter(item => item.userId === user.id) : data.timeEntries;
  }

  function filterTimeEntries(rows, query, user) {
    return rows.filter(row => {
      if (user.role !== "COLABORADOR" && query.get("userId") && row.userId !== query.get("userId")) return false;
      if (query.get("from") && row.date < query.get("from")) return false;
      if (query.get("to") && row.date > query.get("to")) return false;
      return true;
    });
  }

  function groupTimeEntries(entries) {
    const groups = new Map();
    for (const entry of entries) {
      const key = `${entry.date}:${entry.userId}`;
      if (!groups.has(key)) groups.set(key, { date: entry.date, userId: entry.userId, entries: [] });
      groups.get(key).entries.push(entry);
    }
    return [...groups.values()].map(group => {
      const summary = timeClockSummary(group.entries);
      return {
        date: group.date, userId: group.userId, entries: group.entries,
        times: Object.fromEntries(TIME_CLOCK_TYPES.map(type => [type, summary.byType[type]?.time || ""])),
        totalMinutes: summary.totalMinutes, complete: summary.complete,
        corrected: group.entries.some(item => item.automatic === false)
      };
    }).sort((a, b) => `${b.date}:${b.userId}`.localeCompare(`${a.date}:${a.userId}`));
  }

  function filterRows(rows, query) {
    return rows.filter(row => {
      if (query.get("clientId") && row.clientId !== query.get("clientId")) return false;
      if (query.get("userId") && row.userId !== query.get("userId") && row.responsibleId !== query.get("userId")) return false;
      if (query.get("status") && row.status !== query.get("status")) return false;
      const rowDate = row.date || row.dueDate || "";
      if (query.get("from") && rowDate < query.get("from")) return false;
      if (query.get("to") && rowDate > query.get("to")) return false;
      return true;
    });
  }

  function attendanceRows(query) {
    return store.data.attendances.filter(row => {
      const rowDate = String(row.createdAt || "").slice(0, 10);
      if (query.get("clientId") && row.clientId !== query.get("clientId")) return false;
      if (query.get("userId") && row.assignedUserId !== query.get("userId")) return false;
      if (query.get("status") && row.status !== query.get("status")) return false;
      if (query.get("from") && rowDate < query.get("from")) return false;
      if (query.get("to") && rowDate > query.get("to")) return false;
      return true;
    }).sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
  }

  function attendanceMinutes(item) {
    if (!item.startedAt) return 0;
    const end = item.finishedAt ? Date.parse(item.finishedAt) : Date.now();
    return Math.max(0, Math.round((end - Date.parse(item.startedAt)) / 60000));
  }

  function attendanceReport(query) {
    const items = attendanceRows(query).map(item => ({ ...item, totalMinutes: attendanceMinutes(item) }));
    const byUser = new Map();
    for (const item of items) {
      const key = item.assignedUserId || "sem-responsavel";
      if (!byUser.has(key)) byUser.set(key, { userId: item.assignedUserId || "", name: item.assignedUserId ? (store.data.users.find(user => user.id === item.assignedUserId)?.name || "Usuário não encontrado") : "Sem responsável", total: 0, initiated: 0, completed: 0, disregarded: 0, totalMinutes: 0 });
      const row = byUser.get(key);
      row.total += 1;
      if (item.startedAt) row.initiated += 1;
      if (item.status === "FINALIZADO") row.completed += 1;
      if (item.status === "DESCONSIDERADO") row.disregarded += 1;
      row.totalMinutes += item.totalMinutes;
    }
    const employees = [...byUser.values()].map(row => ({ ...row, averageMinutes: row.initiated ? Math.round(row.totalMinutes / row.initiated) : 0 })).sort((a, b) => b.completed - a.completed || b.total - a.total);
    const totalMinutes = items.reduce((sum, item) => sum + item.totalMinutes, 0);
    return {
      items,
      metrics: {
        total: items.length,
        pending: items.filter(item => item.status === "PENDENTE").length,
        inProgress: items.filter(item => item.status === "EM ATENDIMENTO").length,
        completed: items.filter(item => item.status === "FINALIZADO").length,
        disregarded: items.filter(item => item.status === "DESCONSIDERADO").length,
        totalMinutes,
        averageMinutes: items.filter(item => item.startedAt).length ? Math.round(totalMinutes / items.filter(item => item.startedAt).length) : 0
      },
      employees
    };
  }

  function cleanAttachment(source) {
    const name = text(source?.name, 180).replace(/[\\/:*?"<>|]/g, "_");
    const mime = text(source?.type, 120).toLowerCase();
    if (!name || !ATTACHMENT_TYPES.has(mime)) throw new Error("Anexo inválido. Use PDF, JPG, PNG, DOCX, XLSX ou TXT.");
    const encoded = String(source?.data || "").replace(/^data:[^;]+;base64,/, "");
    if (!encoded || !/^[a-z0-9+/=\r\n]+$/i.test(encoded)) throw new Error("Conteúdo do anexo inválido.");
    const content = Buffer.from(encoded, "base64");
    if (!content.length || content.length > 5 * 1024 * 1024) throw new Error("Cada anexo deve ter no máximo 5 MB.");
    const id = crypto.randomUUID();
    return { id, name, mime, size: content.length, storedName: `${id}${ATTACHMENT_TYPES.get(mime)}`, content };
  }

  function buildBudgetReport(period) {
    const data = store.data;
    const usersById = new Map(data.users.map(user => [user.id, user]));
    const completedActivities = data.activities.filter(item => item.status === "CONCLUÍDO"
      && String(item.date || "").slice(0, 7) === period && Number(item.totalMinutes || 0) > 0);
    const administrativeEntries = data.administrativeEntries.filter(item => item.period === period);
    const generalAdministrativeCost = roundMetric(administrativeEntries.reduce((sum, item) => sum + moneyValue(item.amount), 0));
    const categoryMap = new Map();
    for (const item of administrativeEntries) {
      const category = upper(item.category, 120) || "OUTRA DESPESA";
      categoryMap.set(category, roundMetric((categoryMap.get(category) || 0) + moneyValue(item.amount)));
    }
    const categoryTotals = [...categoryMap].map(([category, amount]) => ({ category, amount })).sort((a, b) => b.amount - a.amount || a.category.localeCompare(b.category, "pt-BR"));
    const officeTotalMinutes = completedActivities.reduce((sum, item) => sum + Math.max(0, Number(item.totalMinutes || 0)), 0);
    const officeTotalHours = officeTotalMinutes / 60;
    const administrativeCostPerHour = officeTotalHours > 0 ? roundMetric(generalAdministrativeCost / officeTotalHours) : null;
    const budgetsByClient = new Map(data.budgets.filter(item => item.period === period).map(item => [item.clientId, item]));
    const clientsWithWork = new Set(completedActivities.map(item => item.clientId));
    const rows = data.clients.filter(client => client.active || clientsWithWork.has(client.id) || budgetsByClient.has(client.id)).map(client => {
      const activities = completedActivities.filter(item => item.clientId === client.id);
      const departments = new Map();
      let totalMinutes = 0;
      for (const activity of activities) {
        const minutes = Math.max(0, Number(activity.totalMinutes || 0));
        totalMinutes += minutes;
        const user = usersById.get(activity.userId);
        const sector = normalizeSector(user?.sector) || sectorForRole(user?.role);
        if (!departments.has(sector)) departments.set(sector, { sector, totalMinutes: 0, activityCount: 0, employees: new Map() });
        const department = departments.get(sector);
        department.totalMinutes += minutes;
        department.activityCount += 1;
        const employeeKey = user?.id || activity.userId || "sem-usuario";
        if (!department.employees.has(employeeKey)) {
          department.employees.set(employeeKey, { userId: user?.id || null, name: user?.name || "Usuário não encontrado", totalMinutes: 0, activityCount: 0 });
        }
        const employee = department.employees.get(employeeKey);
        employee.totalMinutes += minutes;
        employee.activityCount += 1;
      }
      const saved = budgetsByClient.get(client.id) || {};
      const legacyTotalCost = LEGACY_BUDGET_COST_FIELDS.reduce((sum, field) => sum + moneyValue(saved[field]), 0);
      const legacyClientCost = Object.prototype.hasOwnProperty.call(saved, "generalCost") ? moneyValue(saved.generalCost) : roundMetric(legacyTotalCost);
      const extraCost = Object.prototype.hasOwnProperty.call(saved, "extraCost") ? moneyValue(saved.extraCost) : legacyClientCost;
      const extraRevenue = Object.prototype.hasOwnProperty.call(saved, "extraRevenue") ? moneyValue(saved.extraRevenue) : moneyValue(saved.revenue);
      const extraCostDescription = text(saved.extraCostDescription, 300)
        || (extraCost > 0 && legacyClientCost > 0 ? "Convertido do custo do cliente registrado na versão anterior." : "");
      const extraRevenueDescription = text(saved.extraRevenueDescription, 300)
        || (extraRevenue > 0 && saved.revenue !== undefined ? "Convertida da receita registrada na versão anterior." : "");
      const hours = totalMinutes / 60;
      const allocatedAdministrativeCost = administrativeCostPerHour === null ? 0 : roundMetric(hours * administrativeCostPerHour);
      const totalCost = roundMetric(allocatedAdministrativeCost + extraCost);
      const result = roundMetric(extraRevenue - totalCost);
      return {
        clientId: client.id, name: client.name, cnpj: client.cnpj, domainCode: client.domainCode,
        period, totalMinutes, totalHours: roundMetric(hours), activityCount: activities.length,
        allocatedAdministrativeCost, extraCost, extraRevenue, extraCostDescription, extraRevenueDescription,
        totalCost, result,
        administrativeCostPerHour,
        costPerHour: hours > 0 ? roundMetric(totalCost / hours) : null,
        revenuePerHour: hours > 0 ? roundMetric(extraRevenue / hours) : null,
        resultPerHour: hours > 0 ? roundMetric(result / hours) : null,
        updatedAt: saved.updatedAt || null,
        departments: [...departments.values()].map(department => ({
          sector: department.sector,
          totalMinutes: department.totalMinutes,
          totalHours: roundMetric(department.totalMinutes / 60),
          activityCount: department.activityCount,
          employees: [...department.employees.values()].map(employee => ({
            ...employee, totalHours: roundMetric(employee.totalMinutes / 60)
          })).sort((a, b) => b.totalMinutes - a.totalMinutes || a.name.localeCompare(b.name, "pt-BR"))
        })).sort((a, b) => b.totalMinutes - a.totalMinutes || a.sector.localeCompare(b.sector, "pt-BR"))
      };
    }).sort((a, b) => b.totalMinutes - a.totalMinutes || a.name.localeCompare(b.name, "pt-BR"));
    const totalMinutes = rows.reduce((sum, item) => sum + item.totalMinutes, 0);
    const totalHours = totalMinutes / 60;
    const totalExtraCost = roundMetric(rows.reduce((sum, item) => sum + item.extraCost, 0));
    const totalExtraRevenue = roundMetric(rows.reduce((sum, item) => sum + item.extraRevenue, 0));
    const totalCost = roundMetric(generalAdministrativeCost + totalExtraCost);
    const result = roundMetric(totalExtraRevenue - totalCost);
    return {
      period,
      administrative: {
        entries: administrativeEntries.map(item => ({
          id: item.id, period: item.period, amount: moneyValue(item.amount),
          category: upper(item.category, 120), correlation: text(item.correlation, 800),
          createdAt: item.createdAt, updatedAt: item.updatedAt
        })),
        categoryTotals,
        generalCost: generalAdministrativeCost,
        updatedAt: administrativeEntries.map(item => item.updatedAt).filter(Boolean).sort().at(-1) || null
      },
      summary: {
        clients: rows.length,
        clientsWithHours: rows.filter(item => item.totalMinutes > 0).length,
        totalMinutes,
        totalHours: roundMetric(totalHours),
        generalAdministrativeCost,
        administrativeCostPerHour,
        totalExtraCost,
        totalExtraRevenue,
        totalCost,
        costPerHour: totalHours > 0 ? roundMetric(totalCost / totalHours) : null,
        result
      },
      items: rows
    };
  }

  function buildAdministrativeReport(period) {
    const budgetReport = buildBudgetReport(period);
    const generalEntries = budgetReport.administrative.entries.map(item => ({
      id: item.id, editable: true, type: "DESPESA GERAL", origin: item.category,
      clientName: "Escritório", cnpj: "", description: item.correlation, amount: item.amount
    }));
    const clientEntries = budgetReport.items.flatMap(item => {
      const entries = [];
      if (item.extraCost > 0) entries.push({
        id: `custo-${item.clientId}`, editable: false, type: "CUSTO EXTRA", origin: item.extraCostDescription, clientName: item.name, cnpj: item.cnpj,
        description: item.extraCostDescription, amount: item.extraCost
      });
      if (item.extraRevenue > 0) entries.push({
        id: `receita-${item.clientId}`, editable: false, type: "RECEITA EXTRA", origin: item.extraRevenueDescription, clientName: item.name, cnpj: item.cnpj,
        description: item.extraRevenueDescription, amount: item.extraRevenue
      });
      return entries;
    });
    return { ...budgetReport, entries: [...generalEntries, ...clientEntries] };
  }

  const whatsapp = createWhatsAppApi({ store, send, sendError, audit, appVersion: APP_VERSION });

  async function handleApi(req, res, url) {
    const method = req.method || "GET";
    const pathname = url.pathname;
    if (await whatsapp.handle(req, res, url)) return;

    if (pathname === "/api/health" && method === "GET") {
      return send(res, 200, { ok: true, version: APP_VERSION, setup: store.data.users.length > 0, uptime: process.uptime() });
    }

    if (pathname === "/api/status" && method === "GET") {
      return send(res, 200, {
        ok: true,
        setupRequired: store.data.users.length === 0,
        officeName: store.data.meta.officeName,
        version: APP_VERSION
      });
    }

    if (pathname === "/api/branding" && method === "GET") {
      return send(res, 200, { ok: true, ...brandingPublic() });
    }

    if (pathname === "/api/branding/logo" && method === "GET") {
      const saved = store.data.meta.branding?.logo;
      const caminho = saved?.file ? path.join(brandingDir, saved.file) : DEFAULT_BRANDING.logoFile;
      const content = await fs.readFile(caminho).catch(() => null);
      if (!content) return sendError(res, 404, "Arquivo da logo não encontrado.");
      return send(res, 200, content, {
        "Content-Type": saved?.file ? saved.mime : DEFAULT_BRANDING.logoMime,
        "Cache-Control": "public, max-age=300"
      });
    }

    if (pathname === "/api/setup" && method === "POST") {
      if (store.data.users.length) return sendError(res, 409, "O sistema já foi configurado.");
      const body = await parseBody(req);
      const officeName = text(body.officeName, 120);
      const name = text(body.name, 120);
      const username = normalizeUsername(body.username);
      if (!officeName || !name || username.length < 3) return sendError(res, 400, "Preencha escritório, nome e usuário.");
      const passwordHash = await hashPassword(body.password);
      const user = {
        id: crypto.randomUUID(), name, username, passwordHash, role: "ADMIN", sector: "ADMIN", active: true, mustChangePassword: false,
        createdAt: new Date().toISOString(), updatedAt: new Date().toISOString()
      };
      await store.transaction(draft => {
        if (draft.users.length) throw new Error("O sistema já foi configurado.");
        draft.meta.officeName = officeName;
        draft.meta.setupAt = new Date().toISOString();
        draft.users.push(user);
        audit(draft, user, "CONFIGURAR", "SISTEMA", null, `Escritório ${officeName}`, req);
      });
      await importBundledTeam();
      const token = createToken();
      const csrf = createToken(24);
      sessions.set(token, { userId: user.id, csrf, expiresAt: Date.now() + config.sessionHours * 3600000 });
      return send(res, 201, { ok: true, user: safeUser(user), csrf }, {
        "Set-Cookie": `${COOKIE_NAME}=${encodeURIComponent(token)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${config.sessionHours * 3600}`
      });
    }

    if (pathname === "/api/login" && method === "POST") {
      const body = await parseBody(req);
      const username = normalizeUsername(body.username);
      const sector = normalizeSector(body.sector);
      const user = store.data.users.find(item => item.username === username && item.active);

      if (user && Number(user.failedAttempts || 0) >= MAX_LOGIN_ATTEMPTS) {
        return sendError(res, 423, "Acesso bloqueado após 4 tentativas. Peça a um gestor ou administrador para redefinir a sua senha.");
      }

      if (!sector || !user || normalizeSector(user.sector) !== sector || !(await verifyPassword(body.password, user.passwordHash))) {
        let restantes = null;
        if (user) {
          await store.transaction(draft => {
            const alvo = draft.users.find(item => item.id === user.id);
            alvo.failedAttempts = Number(alvo.failedAttempts || 0) + 1;
            restantes = Math.max(0, MAX_LOGIN_ATTEMPTS - alvo.failedAttempts);
            if (alvo.failedAttempts >= MAX_LOGIN_ATTEMPTS) {
              alvo.lockedAt = new Date().toISOString();
              audit(draft, null, "BLOQUEAR", "ACESSO", alvo.id, `${alvo.username} bloqueado após ${alvo.failedAttempts} tentativas`, req);
            }
          });
        }
        if (restantes === 0) {
          return sendError(res, 423, "Acesso bloqueado após 4 tentativas. Peça a um gestor ou administrador para redefinir a sua senha.");
        }
        const aviso = restantes === null ? "" : ` Restam ${restantes} tentativa(s) antes do bloqueio.`;
        return sendError(res, 401, `Setor, usuário ou senha inválidos.${aviso}`);
      }

      if (Number(user.failedAttempts || 0)) {
        await store.transaction(draft => {
          const alvo = draft.users.find(item => item.id === user.id);
          alvo.failedAttempts = 0;
          alvo.lockedAt = null;
        });
      }
      const token = createToken();
      const csrf = createToken(24);
      sessions.set(token, { userId: user.id, csrf, expiresAt: Date.now() + config.sessionHours * 3600000 });
      // O login não registra mais ponto: a entrada é sempre uma ação consciente do colaborador.
      await store.transaction(draft => {
        audit(draft, user, "LOGIN", "SESSAO", null, "Login realizado", req);
      });
      return send(res, 200, { ok: true, user: safeUser(user), csrf }, {
        "Set-Cookie": `${COOKIE_NAME}=${encodeURIComponent(token)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${config.sessionHours * 3600}`
      });
    }

    const auth = requireSession(req, res);
    if (!auth) return;

    if (pathname === "/api/logout" && method === "POST") {
      if (!checkMutation(req, res, auth)) return;
      sessions.delete(auth.token);
      return send(res, 200, { ok: true }, { "Set-Cookie": `${COOKIE_NAME}=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0` });
    }

    if (pathname === "/api/me" && method === "GET") {
      return send(res, 200, {
        ok: true,
        user: safeUser(auth.user),
        csrf: auth.session.csrf,
        officeName: store.data.meta.officeName,
        activityStatus: ACTIVITY_STATUS,
        obligationStatus: OBLIGATION_STATUS,
        timeClockTypes: TIME_CLOCK_TYPES.map(value => ({ value, label: TIME_CLOCK_LABELS[value] }))
      });
    }

    const ownPasswordPath = `/api/users/${auth.user.id}/password`;
    if (auth.user.mustChangePassword && !(method === "PUT" && pathname === ownPasswordPath)) {
      return sendError(res, 403, "Troque a senha temporária antes de continuar.");
    }

    if (pathname === "/api/team" && method === "GET") {
      return send(res, 200, { ok: true, items: store.data.users.filter(item => item.active).map(safeUser) });
    }

    if (pathname === "/api/whatsapp-integration" && method === "GET") {
      if (!requireRole(auth, res, ["ADMIN", "GESTOR"])) return;
      return send(res, 200, {
        ok: true, ...whatsapp.status(), publicWebhookUrl: store.data.meta.whatsappPublicUrl || "",
        ...(ADMIN_ROLES.includes(auth.user.role) ? { verifyToken: store.data.meta.whatsapp?.verifyToken || "" } : {})
      });
    }

    if (pathname === "/api/whatsapp-integration" && method === "POST") {
      if (!requireRole(auth, res, ADMIN_ROLES) || !checkMutation(req, res, auth)) return;
      const body = await parseBody(req);
      const result = await whatsapp.configure(auth.user, body, req);
      const publicUrl = text(body.publicWebhookUrl, 300);
      if (publicUrl) {
        if (!/^https:\/\/[a-z0-9.-]+(?::\d+)?(?:\/\S*)?$/i.test(publicUrl)) return sendError(res, 400, "O endereço público do webhook precisa começar com https://");
        await store.transaction(draft => { draft.meta.whatsappPublicUrl = publicUrl; });
      }
      return send(res, 200, { ok: true, ...result, publicWebhookUrl: store.data.meta.whatsappPublicUrl || "" });
    }

    if (pathname === "/api/whatsapp-integration" && method === "DELETE") {
      if (!requireRole(auth, res, ADMIN_ROLES) || !checkMutation(req, res, auth)) return;
      return send(res, 200, { ok: true, ...(await whatsapp.disconnect(auth.user, req)) });
    }

    if (pathname === "/api/whatsapp-integration/key" && method === "POST") {
      if (!requireRole(auth, res, ADMIN_ROLES) || !checkMutation(req, res, auth)) return;
      return send(res, 200, { ok: true, ...(await whatsapp.rotateKey(auth.user, req)) });
    }

    if (pathname === "/api/whatsapp-integration/test" && method === "POST") {
      if (!requireRole(auth, res, ADMIN_ROLES) || !checkMutation(req, res, auth)) return;
      return send(res, 200, { ok: true, ...(await whatsapp.testConnection(auth.user, req)) });
    }

    if (pathname === "/api/whatsapp/conversations" && method === "GET") {
      if (!requireRole(auth, res, ["ADMIN", "GESTOR"])) return;
      return send(res, 200, { ok: true, ...whatsapp.conversations(url.searchParams), integration: whatsapp.status() });
    }

    const conversationMatch = pathname.match(/^\/api\/whatsapp\/conversations\/([^/]+)$/);
    if (conversationMatch && method === "GET") {
      if (!requireRole(auth, res, ["ADMIN", "GESTOR"])) return;
      return send(res, 200, { ok: true, item: whatsapp.conversation(conversationMatch[1]) });
    }

    const conversationAction = pathname.match(/^\/api\/whatsapp\/conversations\/([^/]+)\/(messages|read|client)$/);
    if (conversationAction && method === "POST") {
      if (!requireRole(auth, res, ["ADMIN", "GESTOR"]) || !checkMutation(req, res, auth)) return;
      const [, conversationId, action] = conversationAction;
      if (action === "read") return send(res, 200, { ok: true, item: await whatsapp.markRead(conversationId) });
      const body = await parseBody(req);
      if (action === "client") return send(res, 200, { ok: true, item: await whatsapp.linkClient(auth.user, conversationId, text(body.clientId, 80), req) });
      return send(res, 200, { ok: true, ...(await whatsapp.sendMessage(auth.user, conversationId, body, req)) });
    }

    const mediaMatch = pathname.match(/^\/api\/whatsapp\/conversations\/([^/]+)\/media\/([^/]+)$/);
    if (mediaMatch && method === "GET") {
      if (!requireRole(auth, res, ["ADMIN", "GESTOR"])) return;
      const media = await whatsapp.fetchMedia(mediaMatch[1], mediaMatch[2]);
      return send(res, 200, media.buffer, {
        "Content-Type": media.mime,
        "Content-Disposition": `attachment; filename="${media.name.replace(/[^\w.\-]/g, "_")}"`
      });
    }

    if ((pathname === "/api/attendances" || pathname === "/api/attendance-metrics") && method === "GET") {
      if (!requireRole(auth, res, ["ADMIN", "GESTOR"])) return;
      const report = attendanceReport(url.searchParams);
      return send(res, 200, { ok: true, ...(pathname.endsWith("metrics") ? report : { items: report.items, metrics: report.metrics }) });
    }

    if (pathname === "/api/attendances" && method === "POST") {
      if (!requireRole(auth, res, ["ADMIN", "GESTOR"]) || !checkMutation(req, res, auth)) return;
      const body = await parseBody(req);
      const clientId = text(body.clientId, 80);
      const contactName = text(body.contactName, 160);
      const subject = text(body.subject, 200);
      if (!clientId || !subject) return sendError(res, 400, "Selecione o cliente e informe o assunto do atendimento.");
      let created;
      await store.transaction(draft => {
        if (!draft.clients.some(client => client.id === clientId && client.active)) throw new Error("Cliente inválido ou inativo.");
        const now = new Date().toISOString();
        const contactPhone = String(body.contactPhone || "").replace(/\D/g, "").slice(0, 15);
        const openingMessage = text(body.message, 3000);
        created = {
          id: crypto.randomUUID(), channel: "WHATSAPP", source: "REGISTRO MANUAL", externalId: text(body.externalId, 160),
          waid: contactPhone, clientId, contactName, contactPhone,
          subject, message: openingMessage, department: "DP", status: "PENDENTE", assignedUserId: "",
          startedAt: null, finishedAt: null, closingNotes: "", generatedItems: [],
          messages: openingMessage ? [{
            id: crypto.randomUUID(), externalId: "", direction: "IN", type: "text",
            text: openingMessage, at: now, status: "RECEBIDA", userId: null
          }] : [],
          unread: 0, lastMessageAt: now, lastInboundAt: null, createdBy: auth.user.id,
          createdAt: now, updatedAt: now
        };
        draft.attendances.push(created);
        audit(draft, auth.user, "REGISTRAR", "ATENDIMENTO", created.id, `${subject} - ${draft.clients.find(client => client.id === clientId).name}`, req);
      });
      return send(res, 201, { ok: true, item: created });
    }

    const attendanceAction = pathname.match(/^\/api\/attendances\/([^/]+)\/(start|finish|convert)$/);
    if (attendanceAction && method === "POST") {
      if (!requireRole(auth, res, ["ADMIN", "GESTOR"]) || !checkMutation(req, res, auth)) return;
      const [, attendanceId, action] = attendanceAction;
      const body = await parseBody(req);
      let result;
      await store.transaction(draft => {
        const item = draft.attendances.find(entry => entry.id === attendanceId);
        if (!item) throw Object.assign(new Error("Atendimento não encontrado."), { status: 404 });
        const now = new Date().toISOString();
        if (action === "start") {
          const assignedUserId = text(body.assignedUserId || auth.user.id, 80);
          if (!draft.users.some(user => user.id === assignedUserId && user.active)) throw new Error("Atendente inválido ou inativo.");
          if (["FINALIZADO", "DESCONSIDERADO"].includes(item.status)) throw new Error("Este atendimento já foi encerrado.");
          item.assignedUserId = assignedUserId;
          item.startedAt ||= now;
          item.status = "EM ATENDIMENTO";
          audit(draft, auth.user, "INICIAR", "ATENDIMENTO", item.id, `Atendimento iniciado por ${draft.users.find(user => user.id === assignedUserId).name}`, req);
        } else if (action === "finish") {
          const status = upper(body.status || "FINALIZADO", 40);
          if (!item.startedAt) throw new Error("Inicie o atendimento antes de finalizar.");
          if (!["FINALIZADO", "DESCONSIDERADO"].includes(status)) throw new Error("Situação final inválida.");
          item.status = status;
          item.finishedAt = now;
          item.closingNotes = text(body.closingNotes, 1200);
          audit(draft, auth.user, "FINALIZAR", "ATENDIMENTO", item.id, `${status} em ${attendanceMinutes(item)} minuto(s)`, req);
        } else {
          const kind = upper(body.kind, 20);
          const responsibleId = text(body.responsibleId, 80);
          const responsible = draft.users.find(user => user.id === responsibleId && user.active && user.sector === "DP");
          if (!responsible) throw new Error("Selecione um responsável ativo do DP.");
          if (item.generatedItems?.some(entry => entry.kind === kind)) throw new Error(`Este atendimento já gerou uma ${kind.toLocaleLowerCase("pt-BR")}.`);
          const client = draft.clients.find(entry => entry.id === item.clientId && entry.active);
          if (!client) throw new Error("O cliente do atendimento não está ativo.");
          if (kind === "ATIVIDADE") {
            const date = dateValue(body.date, false);
            const assignedAt = new Date();
            result = {
              id: crypto.randomUUID(), date, userId: responsible.id, clientId: client.id,
              task: upper(body.title || item.subject, 180), instructions: text(body.instructions || item.message, 1200), notes: "",
              status: "EM ANDAMENTO", assignedAt: assignedAt.toISOString(), startDeadlineAt: new Date(assignedAt.getTime() + 30 * 60000).toISOString(),
              startedAt: null, finishedAt: null, totalMinutes: 0, sourceAttendanceId: item.id,
              createdAt: now, updatedAt: now
            };
            draft.activities.push(result);
          } else if (kind === "OBRIGAÇÃO") {
            result = {
              id: crypto.randomUUID(), clientId: client.id, type: upper(body.title || item.subject, 120),
              period: periodValue(body.period), dueDate: dateValue(body.dueDate), status: "PENDENTE", responsibleId: responsible.id,
              notes: text(body.instructions || item.message, 800), sourceAttendanceId: item.id, createdAt: now, updatedAt: now
            };
            draft.obligations.push(result);
          } else throw new Error("Escolha ATIVIDADE ou OBRIGAÇÃO.");
          item.generatedItems ||= [];
          item.generatedItems.push({ kind, id: result.id, createdAt: now });
          audit(draft, auth.user, "CONVERTER", "ATENDIMENTO", item.id, `${kind} criada para ${responsible.name} / ${client.name}`, req);
        }
        item.updatedAt = now;
        result ||= structuredClone(item);
      });
      return send(res, 200, { ok: true, item: result });
    }

    if (pathname === "/api/export/attendances" && method === "GET") {
      if (!requireRole(auth, res, ["ADMIN", "GESTOR"])) return;
      const rows = attendanceReport(url.searchParams).items.map(item => ({
        client: store.data.clients.find(client => client.id === item.clientId)?.name || "Cliente não encontrado",
        contact: item.contactName, subject: item.subject, status: item.status,
        attendant: store.data.users.find(user => user.id === item.assignedUserId)?.name || "Sem responsável",
        createdAt: item.createdAt, startedAt: item.startedAt || "", finishedAt: item.finishedAt || "", totalMinutes: item.totalMinutes,
        notes: item.closingNotes || ""
      }));
      const columns = [["client", "Cliente"], ["contact", "Contato"], ["subject", "Assunto"], ["status", "Situação"], ["attendant", "Atendido por"], ["createdAt", "Recebido em"], ["startedAt", "Iniciado em"], ["finishedAt", "Finalizado em"], ["totalMinutes", "Tempo em minutos"], ["notes", "Observações"]].map(([key, label]) => ({ key, label }));
      return send(res, 200, toCsv(rows, columns), { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": `attachment; filename="df-office-atendimentos-${new Date().toISOString().slice(0, 10)}.csv"` });
    }

    if (pathname === "/api/demands" && method === "GET") {
      if (!requireRole(auth, res, ["ADMIN", "GESTOR"])) return;
      const items = [...store.data.demands].sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
      return send(res, 200, { ok: true, items });
    }

    if (pathname === "/api/demands" && method === "POST") {
      if (!requireRole(auth, res, ["ADMIN", "GESTOR"]) || !checkMutation(req, res, auth)) return;
      const body = await parseBody(req, 18 * 1024 * 1024);
      const destinationSector = upper(body.destinationSector, 30);
      const priority = upper(body.priority || "NORMAL", 20);
      const attachments = (Array.isArray(body.attachments) ? body.attachments : []).slice(0, 3).map(cleanAttachment);
      if (!text(body.title, 200) || ![...SECTORS, "GESTORES"].includes(destinationSector) || !DEMAND_PRIORITIES.includes(priority)) return sendError(res, 400, "Informe título, destino e prioridade válidos.");
      const written = [];
      try {
        for (const file of attachments) {
          await fs.writeFile(path.join(attachmentDir, file.storedName), file.content, { mode: 0o600 });
          written.push(file.storedName);
        }
        let created;
        await store.transaction(draft => {
          const assignedUserId = text(body.assignedUserId, 80);
          const assigned = assignedUserId ? draft.users.find(user => user.id === assignedUserId && user.active) : null;
          if (assignedUserId && !assigned) throw new Error("Responsável inválido ou inativo.");
          if (destinationSector === "GESTORES" && assigned && !["ADMIN", "GESTOR"].includes(assigned.role)) throw new Error("O grupo Gestores aceita somente gestores e administradores.");
          const now = new Date().toISOString();
          created = {
            id: crypto.randomUUID(), title: text(body.title, 200), description: text(body.description, 3000),
            destinationSector, assignedUserId, priority, status: "PENDENTE", createdBy: auth.user.id,
            attachments: attachments.map(({ content, ...file }) => ({ ...file, uploadedBy: auth.user.id, uploadedAt: now })),
            createdAt: now, updatedAt: now, completedAt: null
          };
          draft.demands.push(created);
          audit(draft, auth.user, "CRIAR", "DEMANDA", created.id, `${created.title} para ${destinationSector}; ${attachments.length} anexo(s)`, req);
        });
        return send(res, 201, { ok: true, item: created });
      } catch (error) {
        await Promise.all(written.map(file => fs.rm(path.join(attachmentDir, file), { force: true }).catch(() => {})));
        throw error;
      }
    }

    const demandUpdate = pathname.match(/^\/api\/demands\/([^/]+)$/);
    if (demandUpdate && method === "PUT") {
      if (!requireRole(auth, res, ["ADMIN", "GESTOR"]) || !checkMutation(req, res, auth)) return;
      const body = await parseBody(req);
      let updated;
      await store.transaction(draft => {
        const item = draft.demands.find(entry => entry.id === demandUpdate[1]);
        if (!item) throw Object.assign(new Error("Demanda não encontrada."), { status: 404 });
        const status = upper(body.status ?? item.status, 30);
        const assignedUserId = text(body.assignedUserId ?? item.assignedUserId, 80);
        if (!DEMAND_STATUS.includes(status)) throw new Error("Situação inválida.");
        if (assignedUserId && !draft.users.some(user => user.id === assignedUserId && user.active)) throw new Error("Responsável inválido ou inativo.");
        item.status = status;
        item.assignedUserId = assignedUserId;
        item.updatedAt = new Date().toISOString();
        item.completedAt = status === "CONCLUÍDA" ? item.updatedAt : null;
        updated = structuredClone(item);
        audit(draft, auth.user, "ATUALIZAR", "DEMANDA", item.id, `${item.status}; responsável ${assignedUserId || "não definido"}`, req);
      });
      return send(res, 200, { ok: true, item: updated });
    }

    const attachmentDownload = pathname.match(/^\/api\/demands\/([^/]+)\/attachments\/([^/]+)$/);
    if (attachmentDownload && method === "GET") {
      if (!requireRole(auth, res, ["ADMIN", "GESTOR"])) return;
      const demand = store.data.demands.find(item => item.id === attachmentDownload[1]);
      const attachment = demand?.attachments?.find(item => item.id === attachmentDownload[2]);
      if (!attachment) return sendError(res, 404, "Anexo não encontrado.");
      const content = await fs.readFile(path.join(attachmentDir, attachment.storedName));
      const safeName = attachment.name.replace(/["\r\n]/g, "_");
      return send(res, 200, content, { "Content-Type": attachment.mime, "Content-Disposition": `inline; filename="${safeName}"` });
    }

    if (pathname === "/api/dashboard" && method === "GET") {
      await refreshOverdueActivities();
      const data = store.snapshot();
      const activities = filterRows(visibleActivities(data, auth.user), url.searchParams);
      const obligations = filterRows(visibleObligations(data, auth.user), url.searchParams);
      const finalStatus = new Set(["TRANSMITIDO", "ENVIADO", "DISPENSADO", "NÃO PRECISA ENVIAR"]);
      const recentActivities = activities.sort((a, b) => String(b.date).localeCompare(String(a.date))).slice(0, 8);
      const upcomingObligations = obligations.filter(item => !finalStatus.has(item.status)).sort((a, b) => String(a.dueDate).localeCompare(String(b.dueDate))).slice(0, 8);
      if (auth.user.role === "COLABORADOR") {
        return send(res, 200, { ok: true, mode: "COLABORADOR", recentActivities, upcomingObligations });
      }
      const totalMinutes = activities.reduce((sum, item) => sum + Number(item.totalMinutes || 0), 0);
      const concluded = activities.filter(item => item.status === "CONCLUÍDO").length;
      const today = officeNow().date;
      const overdue = obligations.filter(item => item.dueDate && item.dueDate < today && !finalStatus.has(item.status)).length;
      const byStatus = {};
      for (const item of obligations) byStatus[item.status] = (byStatus[item.status] || 0) + 1;
      const teamProduction = data.users.filter(item => item.active).map(member => {
        const memberActivities = activities.filter(item => item.userId === member.id);
        const memberMinutes = memberActivities.reduce((sum, item) => sum + Number(item.totalMinutes || 0), 0);
        const todayEntries = data.timeEntries.filter(item => item.userId === member.id && item.date === today);
        const point = timeClockSummary(todayEntries);
        let presence = "NÃO INICIOU";
        if (point.byType.SAIDA) presence = "JORNADA CONCLUÍDA";
        else if (point.byType.SAIDA_ALMOCO && !point.byType.RETORNO_ALMOCO) presence = "EM ALMOÇO";
        else if (point.byType.ENTRADA) presence = "EM EXPEDIENTE";
        const lastActivity = [...memberActivities].sort((a, b) => `${b.date}:${b.updatedAt || ""}`.localeCompare(`${a.date}:${a.updatedAt || ""}`))[0];
        return {
          userId: member.id, name: member.name, role: member.role,
          activities: memberActivities.length,
          concluded: memberActivities.filter(item => item.status === "CONCLUÍDO").length,
          inProgress: memberActivities.filter(item => ["EM ATIVIDADE", "EM ANDAMENTO"].includes(item.status)).length,
          totalMinutes: memberMinutes,
          completionRate: memberActivities.length ? Math.round(memberActivities.filter(item => item.status === "CONCLUÍDO").length / memberActivities.length * 100) : 0,
          presence,
          lastActivity: lastActivity ? { date: lastActivity.date, task: lastActivity.task, status: lastActivity.status } : null
        };
      });
      return send(res, 200, {
        ok: true,
        metrics: {
          totalHours: Math.round(totalMinutes / 6) / 10,
          activities: activities.length,
          completionRate: activities.length ? Math.round((concluded / activities.length) * 100) : 0,
          activeClients: data.clients.filter(item => item.active).length,
          activeUsers: data.users.filter(item => item.active).length,
          employeesPresent: teamProduction.filter(item => ["EM EXPEDIENTE", "EM ALMOÇO"].includes(item.presence)).length,
          pendingObligations: obligations.filter(item => !finalStatus.has(item.status)).length,
          overdueObligations: overdue
        },
        obligationStatus: byStatus,
        teamProduction,
        recentActivities,
        upcomingObligations
      });
    }

    if (pathname === "/api/time-clock" && method === "GET") {
      const now = officeNow();
      const visible = visibleTimeEntries(store.data, auth.user);
      const items = filterTimeEntries(visible, url.searchParams, auth.user);
      const todayEntries = store.data.timeEntries.filter(item => item.userId === auth.user.id && item.date === now.date);
      const todaySummary = timeClockSummary(todayEntries);
      return send(res, 200, {
        ok: true,
        items: items.sort((a, b) => `${b.date}:${b.time}`.localeCompare(`${a.date}:${a.time}`)),
        days: groupTimeEntries(items),
        today: {
          date: now.date, serverTime: now.time, entries: todayEntries,
          nextAction: todaySummary.nextAction, complete: todaySummary.complete,
          invalidOrder: todaySummary.invalidOrder, totalMinutes: todaySummary.totalMinutes
        }
      });
    }

    if (pathname === "/api/time-clock/punch" && method === "POST") {
      if (!checkMutation(req, res, auth)) return;
      if (!TIME_CLOCK_ROLES.includes(auth.user.role)) return sendError(res, 403, "Gestão e administração não registram ponto.");
      const body = await parseBody(req);
      const requestedType = upper(body.type, 30);
      if (!TIME_CLOCK_TYPES.includes(requestedType)) return sendError(res, 400, "Tipo de marcação inválido.");
      const instant = new Date();
      const now = officeNow(instant);
      let created;
      let nextAction;
      await store.transaction(draft => {
        const todayEntries = draft.timeEntries.filter(item => item.userId === auth.user.id && item.date === now.date);
        const summary = timeClockSummary(todayEntries);
        if (!summary.nextAction) throw Object.assign(new Error("As quatro marcações de hoje já foram concluídas."), { status: 409 });
        if (summary.nextAction !== requestedType) {
          throw Object.assign(new Error(`A próxima marcação deve ser: ${TIME_CLOCK_LABELS[summary.nextAction]}.`), { status: 409 });
        }
        created = {
          id: crypto.randomUUID(), userId: auth.user.id, date: now.date, time: now.time,
          type: requestedType, automatic: true, recordedAt: instant.toISOString(),
          sourceIp: text(req.socket.remoteAddress, 80), createdAt: instant.toISOString(), updatedAt: instant.toISOString()
        };
        draft.timeEntries.push(created);
        nextAction = TIME_CLOCK_TYPES[TIME_CLOCK_TYPES.indexOf(requestedType) + 1] || null;
        audit(draft, auth.user, "REGISTRAR", "PONTO", created.id, `${TIME_CLOCK_LABELS[requestedType]} às ${now.time}`, req);
      });
      return send(res, 201, { ok: true, item: created, nextAction });
    }

    if (pathname === "/api/time-clock/manual" && method === "POST") {
      if (!requireRole(auth, res, ["ADMIN", "GESTOR"]) || !checkMutation(req, res, auth)) return;
      const body = await parseBody(req);
      const userId = text(body.userId, 80);
      const date = dateValue(body.date, false);
      const clockTime = timeValue(body.time);
      const type = upper(body.type, 30);
      const reason = text(body.reason, 300);
      if (!TIME_CLOCK_TYPES.includes(type) || reason.length < 5) return sendError(res, 400, "Informe tipo e motivo da correção.");
      let adjusted;
      await store.transaction(draft => {
        if (!draft.users.some(item => item.id === userId && item.active)) throw new Error("Colaborador inválido.");
        adjusted = draft.timeEntries.find(item => item.userId === userId && item.date === date && item.type === type);
        const now = new Date().toISOString();
        if (adjusted) {
          adjusted.time = clockTime;
          adjusted.automatic = false;
          adjusted.correctionReason = reason;
          adjusted.correctedBy = auth.user.id;
          adjusted.updatedAt = now;
        } else {
          adjusted = {
            id: crypto.randomUUID(), userId, date, time: clockTime, type, automatic: false,
            correctionReason: reason, correctedBy: auth.user.id, recordedAt: now,
            sourceIp: text(req.socket.remoteAddress, 80), createdAt: now, updatedAt: now
          };
          draft.timeEntries.push(adjusted);
        }
        audit(draft, auth.user, "AJUSTAR", "PONTO", adjusted.id, `${TIME_CLOCK_LABELS[type]} de ${date} para ${clockTime}. Motivo: ${reason}`, req);
      });
      return send(res, 200, { ok: true, item: adjusted });
    }

    if (pathname === "/api/clients" && method === "GET") {
      const requestedType = normalizeCompanyType(url.searchParams.get("type"));
      const query = upper(url.searchParams.get("q"), 160).normalize("NFD").replace(/[\u0300-\u036f]/g, "");
      const items = store.data.clients
        .filter(item => url.searchParams.get("all") === "1" || item.active)
        .filter(item => !requestedType || normalizeCompanyType(item.taxRegime) === requestedType)
        .filter(item => {
          const searchable = `${item.name} ${item.cnpj || ""} ${item.domainCode || ""} ${item.city || ""} ${item.businessActivity || ""}`
            .toLocaleUpperCase("pt-BR").normalize("NFD").replace(/[\u0300-\u036f]/g, "");
          return !query || searchable.includes(query);
        })
        .sort((a, b) => {
          const typeA = COMPANY_TYPES.indexOf(normalizeCompanyType(a.taxRegime));
          const typeB = COMPANY_TYPES.indexOf(normalizeCompanyType(b.taxRegime));
          const typeDifference = (typeA < 0 ? COMPANY_TYPES.length : typeA) - (typeB < 0 ? COMPANY_TYPES.length : typeB);
          return typeDifference || String(a.name).localeCompare(String(b.name), "pt-BR");
        });
      return send(res, 200, { ok: true, items, companyTypes: COMPANY_TYPES });
    }

    if (pathname === "/api/clients" && method === "POST") {
      if (!requireRole(auth, res, ["ADMIN", "GESTOR"]) || !checkMutation(req, res, auth)) return;
      const body = await parseBody(req);
      const fields = clientFields(body);
      if (!fields.name) return sendError(res, 400, "Razão social é obrigatória.");
      let client;
      await store.transaction(draft => {
        if (fields.cnpj && draft.clients.some(item => item.cnpj === fields.cnpj)) throw new Error("CNPJ já cadastrado.");
        if (fields.domainCode && draft.clients.some(item => upper(item.domainCode, 30) === fields.domainCode)) throw new Error("Código Domínio já cadastrado.");
        let code = fields.code || (fields.domainCode ? `DOM-${fields.domainCode}` : `CLI-${crypto.randomUUID().slice(0, 8).toUpperCase()}`);
        if (draft.clients.some(item => item.code === code)) code = `CLI-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
        const now = new Date().toISOString();
        client = { id: crypto.randomUUID(), ...fields, code, active: body.active !== false, createdAt: now, updatedAt: now };
        draft.clients.push(client);
        audit(draft, auth.user, "CRIAR", "CLIENTE", client.id, `${client.domainCode || client.code} - ${client.name}`, req);
      });
      return send(res, 201, { ok: true, item: client });
    }

    if (pathname === "/api/activities" && method === "GET") {
      await refreshOverdueActivities();
      return send(res, 200, { ok: true, items: filterRows(visibleActivities(store.data, auth.user), url.searchParams) });
    }

    if (pathname === "/api/activities" && method === "POST") {
      if (!checkMutation(req, res, auth)) return;
      const body = await parseBody(req);
      const instant = new Date();
      const assignedAt = instant.toISOString();
      const startDeadlineAt = new Date(instant.getTime() + 30 * 60000).toISOString();
      const clientIds = identifierList(body.clientIds ?? body.clientId);
      const userIds = auth.user.role === "COLABORADOR" ? [auth.user.id] : identifierList(body.userIds ?? body.userId);
      const date = dateValue(body.date || officeNow(instant).date, false);
      const task = text(body.task, 180);
      const instructions = text(body.instructions ?? body.notes, 800);
      if (!clientIds.length || !userIds.length || !task) return sendError(res, 400, "Selecione ao menos um CNPJ, um responsável e informe a atividade.");
      if (clientIds.length * userIds.length > 5000) return sendError(res, 400, "A seleção ultrapassa o limite de 5.000 atividades por operação.");
      const activities = [];
      await store.transaction(draft => {
        if (clientIds.some(clientId => !draft.clients.some(item => item.id === clientId && item.active))) throw new Error("Um dos clientes selecionados é inválido ou está inativo.");
        if (userIds.some(userId => !draft.users.some(item => item.id === userId && item.active && ACTIVITY_ROLES.includes(item.role)))) throw new Error("Um dos responsáveis selecionados é inválido ou está inativo.");
        for (const userId of userIds) for (const clientId of clientIds) activities.push({
          id: crypto.randomUUID(), date, userId, clientId, task, status: "EM ANDAMENTO",
          instructions, notes: "", assignedAt, startDeadlineAt, overdueAt: null, startedAt: null,
          finishedAt: null, startedLate: false, start: "", end: "", totalMinutes: 0,
          createdByUserId: auth.user.id, selfCreated: auth.user.role === "COLABORADOR",
          createdAt: assignedAt, updatedAt: assignedAt
        });
        draft.activities.push(...activities);
        audit(draft, auth.user, auth.user.role === "COLABORADOR" ? "CRIAR" : "ATRIBUIR", "ATIVIDADES", null, `${activities.length} registro(s) de ${task}; ${clientIds.length} CNPJ(s) e ${userIds.length} responsável(is); início em até 30 minutos`, req);
      });
      return send(res, 201, { ok: true, item: activities[0], items: activities, count: activities.length });
    }

    const activityWorkflowMatch = pathname.match(/^\/api\/activities\/([^/]+)\/(start|finish)$/);
    if (activityWorkflowMatch && method === "POST") {
      if (!requireRole(auth, res, ACTIVITY_ROLES) || !checkMutation(req, res, auth)) return;
      const [, activityId, action] = activityWorkflowMatch;
      await refreshOverdueActivities();
      const body = await parseBody(req);
      const instant = new Date();
      const office = officeNow(instant);
      let updated;
      await store.transaction(draft => {
        const item = draft.activities.find(entry => entry.id === activityId);
        if (!item) throw new Error("Atividade não encontrada.");
        if (item.userId !== auth.user.id) throw new Error("Esta atividade não foi atribuída a você.");
        if (action === "start") {
          if (!["EM ANDAMENTO", "EM ATRASO"].includes(item.status)) throw new Error("Esta atividade não está aguardando início.");
          item.startedLate = item.status === "EM ATRASO" || (item.startDeadlineAt && Date.parse(item.startDeadlineAt) < instant.getTime());
          item.status = "EM ATIVIDADE";
          item.startedAt = instant.toISOString();
          item.start = office.time;
          item.updatedAt = item.startedAt;
          audit(draft, auth.user, "INICIAR", "ATIVIDADE", item.id, `${item.task} iniciada às ${office.time}`, req);
        } else {
          const notes = text(body.notes, 800);
          if (item.status !== "EM ATIVIDADE" || !item.startedAt) throw new Error("Inicie a atividade antes de finalizá-la.");
          if (!notes) throw new Error("Preencha a observação da atividade.");
          item.status = "CONCLUÍDO";
          item.notes = notes;
          item.finishedAt = instant.toISOString();
          item.end = office.time;
          item.totalMinutes = Math.max(1, Math.round((instant.getTime() - Date.parse(item.startedAt)) / 60000));
          item.updatedAt = item.finishedAt;
          audit(draft, auth.user, "FINALIZAR", "ATIVIDADE", item.id, `${item.task} finalizada às ${office.time} (${item.totalMinutes} min)`, req);
        }
        updated = structuredClone(item);
      });
      return send(res, 200, { ok: true, item: updated });
    }

    // Correção da observação depois de concluída, mantendo o texto anterior na auditoria.
    const activityNotesMatch = pathname.match(/^\/api\/activities\/([^/]+)\/notes$/);
    if (activityNotesMatch && method === "POST") {
      if (!checkMutation(req, res, auth)) return;
      const notes = text((await parseBody(req)).notes, 800);
      if (!notes) return sendError(res, 400, "Preencha a observação.");
      let updated;
      await store.transaction(draft => {
        const item = draft.activities.find(entry => entry.id === activityNotesMatch[1]);
        if (!item) throw Object.assign(new Error("Atividade não encontrada."), { status: 404 });
        const executou = item.userId === auth.user.id;
        if (!executou && !ADMIN_ROLES.includes(auth.user.role)) {
          throw Object.assign(new Error("Esta atividade é de outro responsável."), { status: 403 });
        }
        if (item.status !== "CONCLUÍDO") throw new Error("A observação só é corrigida depois que a atividade é concluída.");
        const anterior = item.notes || "";
        if (anterior === notes) throw new Error("A observação é igual à anterior.");
        item.notes = notes;
        item.notesEditedAt = new Date().toISOString();
        item.notesEditedBy = auth.user.id;
        item.updatedAt = item.notesEditedAt;
        audit(draft, auth.user, "CORRIGIR_OBSERVACAO", "ATIVIDADE", item.id,
          `${item.task}: observação corrigida. Texto anterior: ${anterior.slice(0, 200)}`, req);
        updated = structuredClone(item);
      });
      return send(res, 200, { ok: true, item: updated });
    }

    if (pathname === "/api/obligation-catalog" && method === "GET") {
      if (!requireRole(auth, res, ["ADMIN", "GESTOR"])) return;
      return send(res, 200, { ok: true, sourceFile: obligationCatalog.sourceFile, sourceRows: obligationCatalog.sourceRows, items: obligationCatalog.items });
    }

    if (pathname === "/api/obligations" && method === "GET") {
      return send(res, 200, { ok: true, items: filterRows(visibleObligations(store.data, auth.user), url.searchParams) });
    }

    if (pathname === "/api/obligations" && method === "POST") {
      if (!requireRole(auth, res, ["ADMIN", "GESTOR"]) || !checkMutation(req, res, auth)) return;
      const body = await parseBody(req);
      const clientIds = identifierList(body.clientIds ?? body.clientId);
      const selectedResponsibleIds = identifierList(body.responsibleIds ?? body.responsibleId);
      const responsibleIds = selectedResponsibleIds.length ? selectedResponsibleIds : [""];
      const type = upper(body.type, 120);
      const period = periodValue(body.period);
      const dueDate = dateValue(body.dueDate);
      const status = upper(body.status, 60);
      const notes = text(body.notes, 800);
      const recurrence = recurrenceValue(body.recurrence);
      if (!clientIds.length || !type || !OBLIGATION_STATUS.includes(status)) return sendError(res, 400, "Selecione ao menos um CNPJ e informe obrigação e status válidos.");
      if (clientIds.length * responsibleIds.length > 5000) return sendError(res, 400, "A seleção ultrapassa o limite de 5.000 obrigações por operação.");
      const obligations = [];
      await store.transaction(draft => {
        if (clientIds.some(clientId => !draft.clients.some(item => item.id === clientId && item.active))) throw new Error("Um dos clientes selecionados é inválido ou está inativo.");
        if (selectedResponsibleIds.some(responsibleId => !draft.users.some(item => item.id === responsibleId && item.active))) throw new Error("Um dos responsáveis selecionados é inválido ou está inativo.");
        const now = new Date().toISOString();
        const template = (draft.meta.obligationStepTemplates || []).find(item => item.name === type);
        const buildSteps = () => (template?.steps || []).map((name, order) => ({
          id: crypto.randomUUID(), order, name, done: false, doneAt: null, userId: null
        }));
        for (const responsibleId of responsibleIds) for (const clientId of clientIds) obligations.push({
          id: crypto.randomUUID(), clientId, type, period, dueDate, status, responsibleId, notes, recurrence,
          steps: buildSteps(), createdAt: now, updatedAt: now
        });
        draft.obligations.push(...obligations);
        audit(draft, auth.user, "CRIAR", "OBRIGACOES", null, `${obligations.length} registro(s) de ${type} ${period}; ${clientIds.length} CNPJ(s) e ${selectedResponsibleIds.length || 1} responsável(is)`, req);
      });
      return send(res, 201, { ok: true, item: obligations[0], items: obligations, count: obligations.length });
    }

    if (pathname === "/api/branding" && method === "POST") {
      if (!requireRole(auth, res, ADMIN_ROLES) || !checkMutation(req, res, auth)) return;
      const body = await parseBody(req, 3 * 1024 * 1024);
      const companyName = text(body.companyName, 120);
      const primaryColor = text(body.primaryColor, 7).toLowerCase();
      if (primaryColor && !/^#[0-9a-f]{6}$/.test(primaryColor)) return sendError(res, 400, "Informe a cor no formato #1a2b3c.");
      let logo = store.data.meta.branding?.logo || null;
      if (body.removeLogo) {
        if (logo?.file) await fs.rm(path.join(brandingDir, logo.file), { force: true });
        logo = null;
      } else if (body.logo?.data) {
        const mime = text(body.logo.type, 60).toLowerCase();
        if (!BRANDING_IMAGE_TYPES.has(mime)) return sendError(res, 400, "Use uma imagem PNG, JPG, SVG ou WEBP.");
        const encoded = String(body.logo.data).replace(/^data:[^;]+;base64,/, "");
        if (!/^[a-z0-9+/=\r\n]+$/i.test(encoded)) return sendError(res, 400, "Conteúdo da imagem inválido.");
        const content = Buffer.from(encoded, "base64");
        if (!content.length || content.length > 1024 * 1024) return sendError(res, 400, "A logo deve ter no máximo 1 MB.");
        const file = `logo${BRANDING_IMAGE_TYPES.get(mime)}`;
        await fs.writeFile(path.join(brandingDir, file), content);
        logo = { file, mime, size: content.length, updatedAt: new Date().toISOString() };
      }
      await store.transaction(draft => {
        draft.meta.branding = {
          ...(draft.meta.branding || {}),
          companyName: companyName || draft.meta.branding?.companyName || "",
          primaryColor: primaryColor || "",
          logo,
          updatedAt: new Date().toISOString()
        };
        audit(draft, auth.user, "ATUALIZAR", "IDENTIDADE", null, `Identidade visual atualizada${logo ? " com logo" : ""}.`, req);
      });
      return send(res, 200, { ok: true, ...brandingPublic() });
    }

    if (pathname === "/api/recurrences" && method === "GET") {
      return send(res, 200, { ok: true, items: recurrenceOptions() });
    }

    if (pathname === "/api/recurrences" && method === "POST") {
      if (!requireRole(auth, res, ADMIN_ROLES) || !checkMutation(req, res, auth)) return;
      const nome = upper((await parseBody(req)).name, 40);
      if (!nome) return sendError(res, 400, "Informe o nome da periodicidade.");
      let lista;
      await store.transaction(draft => {
        draft.meta.recurrenceOptions = Array.isArray(draft.meta.recurrenceOptions) && draft.meta.recurrenceOptions.length
          ? draft.meta.recurrenceOptions : [...DEFAULT_RECURRENCES];
        if (!draft.meta.recurrenceOptions.includes(nome)) {
          if (draft.meta.recurrenceOptions.length >= 30) throw new Error("Limite de 30 periodicidades atingido.");
          draft.meta.recurrenceOptions.push(nome);
          audit(draft, auth.user, "CRIAR", "PERIODICIDADE", null, nome, req);
        }
        lista = [...draft.meta.recurrenceOptions];
      });
      return send(res, 201, { ok: true, items: lista });
    }

    const recurrenceMatch = pathname.match(/^\/api\/recurrences\/([^/]+)$/);
    if (recurrenceMatch && method === "DELETE") {
      if (!requireRole(auth, res, ADMIN_ROLES) || !checkMutation(req, res, auth)) return;
      const nome = upper(decodeURIComponent(recurrenceMatch[1]), 40);
      let lista;
      await store.transaction(draft => {
        const atual = Array.isArray(draft.meta.recurrenceOptions) && draft.meta.recurrenceOptions.length
          ? draft.meta.recurrenceOptions : [...DEFAULT_RECURRENCES];
        if (draft.obligations.some(item => upper(item.recurrence, 40) === nome)) {
          throw new Error("Existem obrigações usando esta periodicidade. Altere-as antes de excluir.");
        }
        draft.meta.recurrenceOptions = atual.filter(item => item !== nome);
        if (!draft.meta.recurrenceOptions.length) draft.meta.recurrenceOptions = [...DEFAULT_RECURRENCES];
        lista = [...draft.meta.recurrenceOptions];
        audit(draft, auth.user, "EXCLUIR", "PERIODICIDADE", null, nome, req);
      });
      return send(res, 200, { ok: true, items: lista });
    }

    if (pathname === "/api/obligations/bulk" && method === "POST") {
      if (!requireRole(auth, res, ADMIN_ROLES) || !checkMutation(req, res, auth)) return;
      const body = await parseBody(req);
      const ids = identifierList(body.ids);
      if (!ids.length) return sendError(res, 400, "Selecione ao menos uma obrigação.");
      if (ids.length > 5000) return sendError(res, 400, "Selecione no máximo 5.000 obrigações por operação.");
      const acao = upper(body.action || "ALTERAR", 20);
      let afetadas = 0;
      await store.transaction(draft => {
        const alvo = new Set(ids);
        const encontradas = draft.obligations.filter(item => alvo.has(item.id));
        if (!encontradas.length) throw Object.assign(new Error("Nenhuma das obrigações selecionadas foi encontrada."), { status: 404 });

        if (acao === "EXCLUIR") {
          draft.obligations = draft.obligations.filter(item => !alvo.has(item.id));
          afetadas = encontradas.length;
          audit(draft, auth.user, "EXCLUIR_LOTE", "OBRIGACOES", null, `${afetadas} obrigação(ões) excluída(s) de uma vez`, req);
          return;
        }

        // Alteração em lote: só muda o que foi enviado, o resto permanece.
        const mudancas = {};
        if (body.responsibleId !== undefined) {
          const responsibleId = text(body.responsibleId, 80);
          if (responsibleId && !draft.users.some(user => user.id === responsibleId && user.active)) throw new Error("Responsável inválido ou inativo.");
          mudancas.responsibleId = responsibleId;
        }
        if (body.status !== undefined) {
          const status = upper(body.status, 60);
          if (!OBLIGATION_STATUS.includes(status)) throw new Error("Status inválido.");
          mudancas.status = status;
        }
        if (body.dueDate !== undefined) mudancas.dueDate = dateValue(body.dueDate);
        if (body.period !== undefined) mudancas.period = periodValue(body.period);
        if (body.recurrence !== undefined) mudancas.recurrence = recurrenceValue(body.recurrence);
        if (!Object.keys(mudancas).length) throw new Error("Informe ao menos um campo para alterar.");

        const agora = new Date().toISOString();
        for (const item of encontradas) {
          Object.assign(item, mudancas, { updatedAt: agora });
          afetadas += 1;
        }
        const resumo = Object.entries(mudancas).map(([campo, valor]) => `${campo}=${valor || "(vazio)"}`).join(", ");
        audit(draft, auth.user, "ALTERAR_LOTE", "OBRIGACOES", null, `${afetadas} obrigação(ões): ${resumo}`, req);
      });
      return send(res, 200, { ok: true, action: acao, affected: afetadas });
    }

    if (pathname === "/api/obligations-panel" && method === "GET") {
      if (!requireRole(auth, res, ["ADMIN", "GESTOR"])) return;
      const period = url.searchParams.get("period") ? periodValue(url.searchParams.get("period")) : "";
      return send(res, 200, { ok: true, ...buildObligationPanel(store.data, period, officeNow().date) });
    }

    if ((pathname === "/api/movimentacoes" || pathname === "/api/export/movimentacoes") && method === "GET") {
      if (!requireRole(auth, res, ["ADMIN", "GESTOR"])) return;
      const type = text(url.searchParams.get("type") || "atividades", 20);
      if (!MOVEMENT_TYPES.includes(type)) return sendError(res, 400, "Tipo de movimentação inválido.");
      const filtro = {
        type,
        userId: text(url.searchParams.get("userId"), 80),
        from: url.searchParams.get("from") ? dateValue(url.searchParams.get("from")) : "",
        to: url.searchParams.get("to") ? dateValue(url.searchParams.get("to")) : ""
      };
      const { rows, columns } = buildMovements(store.data, filtro);
      if (pathname === "/api/movimentacoes") {
        return send(res, 200, {
          ok: true, type, total: rows.length,
          columns: columns.map(([key, label]) => ({ key, label })),
          items: rows.slice(0, 200), truncated: rows.length > 200
        });
      }
      const body = toCsv(rows, columns.map(([key, label]) => ({ key, label })));
      return send(res, 200, body, {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="df-office-${type}-${new Date().toISOString().slice(0, 10)}.csv"`
      });
    }

    if (pathname === "/api/obligation-steps" && method === "GET") {
      return send(res, 200, { ok: true, items: store.data.meta.obligationStepTemplates || [] });
    }

    if (pathname === "/api/obligation-steps" && method === "POST") {
      if (!requireRole(auth, res, ["ADMIN", "GESTOR"]) || !checkMutation(req, res, auth)) return;
      const body = await parseBody(req);
      const name = upper(body.name, 120);
      const steps = (Array.isArray(body.steps) ? body.steps : String(body.steps || "").split("\n"))
        .map(step => text(step, 120)).filter(Boolean).slice(0, 30);
      if (!name || !steps.length) return sendError(res, 400, "Informe a obrigação e ao menos uma etapa.");
      let saved;
      await store.transaction(draft => {
        draft.meta.obligationStepTemplates ||= [];
        const existing = draft.meta.obligationStepTemplates.find(item => item.name === name);
        saved = existing || { id: crypto.randomUUID(), name, createdAt: new Date().toISOString() };
        saved.steps = steps;
        saved.updatedAt = new Date().toISOString();
        if (!existing) draft.meta.obligationStepTemplates.push(saved);
        audit(draft, auth.user, existing ? "ATUALIZAR" : "CRIAR", "ETAPAS", saved.id, `${name}: ${steps.length} etapa(s)`, req);
      });
      return send(res, 200, { ok: true, item: saved });
    }

    const stepTemplateMatch = pathname.match(/^\/api\/obligation-steps\/([^/]+)$/);
    if (stepTemplateMatch && method === "DELETE") {
      if (!requireRole(auth, res, ["ADMIN", "GESTOR"]) || !checkMutation(req, res, auth)) return;
      await store.transaction(draft => {
        draft.meta.obligationStepTemplates = (draft.meta.obligationStepTemplates || []).filter(item => item.id !== stepTemplateMatch[1]);
        audit(draft, auth.user, "EXCLUIR", "ETAPAS", stepTemplateMatch[1], "Modelo de etapas removido.", req);
      });
      return send(res, 200, { ok: true });
    }

    const obligationStepMatch = pathname.match(/^\/api\/obligations\/([^/]+)\/steps\/([^/]+)$/);
    if (obligationStepMatch && method === "POST") {
      if (!checkMutation(req, res, auth)) return;
      const [, obligationId, stepId] = obligationStepMatch;
      const body = await parseBody(req);
      let updated;
      await store.transaction(draft => {
        const item = draft.obligations.find(entry => entry.id === obligationId);
        if (!item) throw Object.assign(new Error("Obrigação não encontrada."), { status: 404 });
        if (auth.user.role === "COLABORADOR" && item.responsibleId !== auth.user.id) {
          throw Object.assign(new Error("Esta obrigação é de outro responsável."), { status: 403 });
        }
        const step = (item.steps || []).find(entry => entry.id === stepId);
        if (!step) throw Object.assign(new Error("Etapa não encontrada."), { status: 404 });
        const done = body.done === undefined ? !step.done : Boolean(body.done);
        // Clicar na etapa em que a pessoa parou conclui todas as anteriores.
        // Reabrir uma etapa reabre as seguintes, para o progresso nunca ficar furado.
        const cascata = body.cascade === undefined ? true : Boolean(body.cascade);
        const agora = new Date().toISOString();
        const posicao = item.steps.indexOf(step);
        for (const [indice, etapa] of item.steps.entries()) {
          const alvo = indice === posicao || (cascata && (done ? indice < posicao : indice > posicao));
          if (!alvo) continue;
          if (etapa.done === done) continue;
          etapa.done = done;
          etapa.doneAt = done ? agora : null;
          etapa.userId = done ? auth.user.id : null;
        }
        item.updatedAt = new Date().toISOString();
        audit(draft, auth.user, done ? "CONCLUIR_ETAPA" : "REABRIR_ETAPA", "OBRIGACAO", item.id, `${item.type}: ${step.name}`, req);
        updated = structuredClone(item);
      });
      return send(res, 200, { ok: true, item: updated });
    }

    if (pathname === "/api/users" && method === "GET") {
      if (!requireRole(auth, res, ["ADMIN", "GESTOR"])) return;
      return send(res, 200, {
        ok: true,
        items: store.data.users.map(safeUser).map(user => ({
          ...user,
          locked: Number(user.failedAttempts || 0) >= MAX_LOGIN_ATTEMPTS,
          failedAttempts: Number(user.failedAttempts || 0)
        }))
      });
    }

    if (pathname === "/api/users" && method === "POST") {
      if (!requireRole(auth, res, ["ADMIN", "GESTOR"]) || !checkMutation(req, res, auth)) return;
      const body = await parseBody(req);
      const username = normalizeUsername(body.username);
      const sector = normalizeSector(body.sector);
      const role = SECTOR_ROLES[sector];
      if (!text(body.name, 120) || username.length < 3 || !sector || !ROLES.includes(role)) return sendError(res, 400, "Nome, usuário e setor válidos são obrigatórios.");
      const user = {
        id: crypto.randomUUID(), name: text(body.name, 120), username, passwordHash: await hashPassword(body.password),
        role, sector, active: true, mustChangePassword: true, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString()
      };
      await store.transaction(draft => {
        if (draft.users.some(item => item.username === username)) throw new Error("Usuário já cadastrado.");
        draft.users.push(user);
        audit(draft, auth.user, "CRIAR", "USUARIO", user.id, `${user.username} (${user.sector}/${user.role})`, req);
      });
      return send(res, 201, { ok: true, item: safeUser(user), accessReady: true });
    }

    const unlockMatch = pathname.match(/^\/api\/users\/([^/]+)\/unlock$/);
    if (unlockMatch && method === "POST") {
      if (!requireRole(auth, res, ["ADMIN", "GESTOR"]) || !checkMutation(req, res, auth)) return;
      const alvo = store.data.users.find(item => item.id === unlockMatch[1]);
      if (!alvo) return sendError(res, 404, "Usuário não encontrado.");
      await store.transaction(draft => {
        const item = draft.users.find(entry => entry.id === alvo.id);
        item.failedAttempts = 0;
        item.lockedAt = null;
        audit(draft, auth.user, "LIBERAR", "ACESSO", alvo.id, `Bloqueio por tentativas removido de ${alvo.username}.`, req);
      });
      return send(res, 200, { ok: true, username: alvo.username });
    }

    if (pathname === "/api/budgets" && method === "GET") {
      if (!requireRole(auth, res, ADMIN_ROLES)) return;
      const period = periodValue(url.searchParams.get("period") || officeNow().date.slice(0, 7));
      return send(res, 200, { ok: true, ...buildBudgetReport(period) });
    }

    if (pathname === "/api/administrative" && method === "GET") {
      if (!requireRole(auth, res, ADMIN_ROLES)) return;
      const period = periodValue(url.searchParams.get("period") || officeNow().date.slice(0, 7));
      return send(res, 200, { ok: true, ...buildAdministrativeReport(period) });
    }

    if (pathname === "/api/administrative/entries" && method === "POST") {
      if (!requireRole(auth, res, ADMIN_ROLES) || !checkMutation(req, res, auth)) return;
      const body = await parseBody(req);
      const period = periodValue(body.period);
      const amount = moneyValue(body.amount);
      const category = upper(body.category, 120);
      const correlation = text(body.correlation, 800);
      if (amount <= 0) return sendError(res, 400, "Informe um valor maior que zero.");
      if (!category) return sendError(res, 400, "Informe a origem ou o tipo da despesa.");
      if (!correlation) return sendError(res, 400, "Explique a correlação ou o destino da despesa.");
      let saved;
      await store.transaction(draft => {
        const now = new Date().toISOString();
        saved = {
          id: crypto.randomUUID(), period, amount, category, correlation,
          createdBy: auth.user.id, updatedBy: auth.user.id, createdAt: now, updatedAt: now
        };
        draft.administrativeEntries.push(saved);
        audit(draft, auth.user, "CRIAR", "DESPESA ADMINISTRATIVA", saved.id, `${category} - ${period}`, req);
      });
      return send(res, 201, { ok: true, item: saved, ...buildAdministrativeReport(period) });
    }

    const administrativeEntryMatch = pathname.match(/^\/api\/administrative\/entries\/([^/]+)$/);
    if (administrativeEntryMatch && method === "PUT") {
      if (!requireRole(auth, res, ADMIN_ROLES) || !checkMutation(req, res, auth)) return;
      const id = text(administrativeEntryMatch[1], 80);
      const body = await parseBody(req);
      const period = periodValue(body.period);
      const amount = moneyValue(body.amount);
      const category = upper(body.category, 120);
      const correlation = text(body.correlation, 800);
      if (amount <= 0) return sendError(res, 400, "Informe um valor maior que zero.");
      if (!category) return sendError(res, 400, "Informe a origem ou o tipo da despesa.");
      if (!correlation) return sendError(res, 400, "Explique a correlação ou o destino da despesa.");
      let saved;
      await store.transaction(draft => {
        saved = draft.administrativeEntries.find(item => item.id === id);
        if (!saved) throw new Error("Despesa administrativa não encontrada.");
        Object.assign(saved, { period, amount, category, correlation, updatedBy: auth.user.id, updatedAt: new Date().toISOString() });
        audit(draft, auth.user, "EDITAR", "DESPESA ADMINISTRATIVA", saved.id, `${category} - ${period}`, req);
      });
      return send(res, 200, { ok: true, item: saved, ...buildAdministrativeReport(period) });
    }

    if (administrativeEntryMatch && method === "DELETE") {
      if (!requireRole(auth, res, ADMIN_ROLES) || !checkMutation(req, res, auth)) return;
      const id = text(administrativeEntryMatch[1], 80);
      let period;
      await store.transaction(draft => {
        const index = draft.administrativeEntries.findIndex(item => item.id === id);
        if (index < 0) throw new Error("Despesa administrativa não encontrada.");
        const [removed] = draft.administrativeEntries.splice(index, 1);
        period = removed.period;
        audit(draft, auth.user, "EXCLUIR", "DESPESA ADMINISTRATIVA", removed.id, `${removed.category} - ${period}`, req);
      });
      return send(res, 200, { ok: true, ...buildAdministrativeReport(period) });
    }

    if (pathname === "/api/administrative/export.pdf" && method === "GET") {
      if (!requireRole(auth, res, ADMIN_ROLES)) return;
      const period = periodValue(url.searchParams.get("period") || officeNow().date.slice(0, 7));
      const report = buildAdministrativeReport(period);
      return send(res, 200, buildAdministrativePdf(report, store.data.meta.officeName), {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="relatorio-administrativo-${period}.pdf"`
      });
    }

    if (pathname === "/api/administrative/export.xls" && method === "GET") {
      if (!requireRole(auth, res, ADMIN_ROLES)) return;
      const period = periodValue(url.searchParams.get("period") || officeNow().date.slice(0, 7));
      const report = buildAdministrativeReport(period);
      return send(res, 200, buildAdministrativeExcel(report, store.data.meta.officeName), {
        "Content-Type": "application/vnd.ms-excel; charset=utf-8",
        "Content-Disposition": `attachment; filename="relatorio-administrativo-${period}.xls"`
      });
    }

    const budgetMatch = pathname.match(/^\/api\/budgets\/([^/]+)$/);
    if (budgetMatch && method === "PUT") {
      if (!requireRole(auth, res, ADMIN_ROLES) || !checkMutation(req, res, auth)) return;
      const clientId = text(budgetMatch[1], 80);
      const body = await parseBody(req);
      const period = periodValue(body.period);
      const extraCost = moneyValue(body.extraCost);
      const extraRevenue = moneyValue(body.extraRevenue);
      const extraCostDescription = text(body.extraCostDescription, 300)
        || (extraCost > 0 ? "Custo extra informado no CNPJ." : "");
      const extraRevenueDescription = text(body.extraRevenueDescription, 300)
        || (extraRevenue > 0 ? "Receita extra informada no CNPJ." : "");
      let saved;
      await store.transaction(draft => {
        const client = draft.clients.find(item => item.id === clientId);
        if (!client) throw new Error("Cliente não encontrado.");
        const now = new Date().toISOString();
        saved = draft.budgets.find(item => item.clientId === clientId && item.period === period);
        const values = { extraCost, extraRevenue, extraCostDescription, extraRevenueDescription };
        if (saved) Object.assign(saved, values, { updatedBy: auth.user.id, updatedAt: now });
        else {
          saved = {
            id: crypto.randomUUID(), clientId, period, ...values,
            createdBy: auth.user.id, updatedBy: auth.user.id, createdAt: now, updatedAt: now
          };
          draft.budgets.push(saved);
        }
        audit(draft, auth.user, "SALVAR", "ORCAMENTO", saved.id, `${client.name} ${period} - extras`, req);
      });
      return send(res, 200, { ok: true, item: saved, report: buildBudgetReport(period).items.find(item => item.clientId === clientId) });
    }

    if (pathname === "/api/audit" && method === "GET") {
      if (!requireRole(auth, res, ["ADMIN", "GESTOR"])) return;
      return send(res, 200, { ok: true, items: store.data.audit.slice(-500).reverse() });
    }

    if (pathname === "/api/backup" && method === "GET") {
      if (!requireRole(auth, res, ADMIN_ROLES)) return;
      const body = `${JSON.stringify(store.snapshot(), null, 2)}\n`;
      return send(res, 200, body, {
        "Content-Type": "application/json; charset=utf-8",
        "Content-Disposition": `attachment; filename="dashboard-fiscal-backup-${new Date().toISOString().slice(0, 10)}.json"`
      });
    }

    const passwordMatch = pathname.match(/^\/api\/users\/([^/]+)\/password$/);
    if (passwordMatch && method === "PUT") {
      const targetId = passwordMatch[1];
      if (auth.user.id !== targetId && !canManageUser(auth.user)) return sendError(res, 403, "Você não pode alterar esta senha.");
      if (!checkMutation(req, res, auth)) return;
      const body = await parseBody(req);
      const passwordHash = await hashPassword(body.password);
      await store.transaction(draft => {
        const user = draft.users.find(item => item.id === targetId);
        if (!user) throw new Error("Usuário não encontrado.");
        user.passwordHash = passwordHash;
        user.mustChangePassword = auth.user.id !== targetId;
        // Trocar a senha é o caminho natural para devolver o acesso de quem errou quatro vezes.
        user.failedAttempts = 0;
        user.lockedAt = null;
        user.updatedAt = new Date().toISOString();
        audit(draft, auth.user, "ALTERAR_SENHA", "USUARIO", targetId, user.username, req);
      });
      for (const [token, session] of sessions) if (session.userId === targetId && token !== auth.token) sessions.delete(token);
      return send(res, 200, { ok: true });
    }

    const entityMatch = pathname.match(/^\/api\/(clients|activities|obligations|users)\/([^/]+)$/);
    if (entityMatch && ["PUT", "DELETE"].includes(method)) {
      const [, collection, id] = entityMatch;
      if (!checkMutation(req, res, auth)) return;
      const singular = { clients: "CLIENTE", activities: "ATIVIDADE", obligations: "OBRIGACAO", users: "USUARIO" }[collection];
      const source = store.data[collection].find(item => item.id === id);
      if (!source) return sendError(res, 404, `${singular} não encontrado.`);
      if (collection === "clients" && !["ADMIN", "GESTOR"].includes(auth.user.role)) return sendError(res, 403, "Sem permissão.");
      if (collection === "users" && !canManageUser(auth.user)) return sendError(res, 403, "Sem permissão para alterar esta conta.");
      if (collection === "activities" && auth.user.role === "COLABORADOR") return sendError(res, 403, "Use os controles de iniciar e finalizar a atividade.");
      if (collection === "obligations" && auth.user.role === "COLABORADOR" && source.responsibleId !== auth.user.id) return sendError(res, 403, "Sem permissão.");

      if (method === "DELETE") {
        if (collection === "users") return sendError(res, 405, "Desative usuários em vez de excluí-los.");
        await store.transaction(draft => {
          draft[collection] = draft[collection].filter(item => item.id !== id);
          audit(draft, auth.user, "EXCLUIR", singular, id, "Registro excluído", req);
        });
        return send(res, 200, { ok: true });
      }

      const body = await parseBody(req);
      let updated;
      await store.transaction(draft => {
        const item = draft[collection].find(entry => entry.id === id);
        if (collection === "clients") {
          const fields = clientFields(body, item);
          if (!fields.name) throw new Error("Razão social é obrigatória.");
          if (fields.cnpj && draft.clients.some(client => client.id !== id && client.cnpj === fields.cnpj)) throw new Error("CNPJ já cadastrado.");
          if (fields.domainCode && draft.clients.some(client => client.id !== id && upper(client.domainCode, 30) === fields.domainCode)) throw new Error("Código Domínio já cadastrado.");
          Object.assign(item, fields);
          item.active = body.active ?? item.active;
        } else if (collection === "activities") {
          if (["EM ATIVIDADE", "CONCLUÍDO"].includes(item.status)) throw new Error("Uma atividade iniciada ou concluída não pode ser reatribuída.");
          const previousUserId = item.userId;
          item.date = dateValue(body.date ?? item.date, false);
          item.clientId = text(body.clientId ?? item.clientId, 80);
          item.task = text(body.task ?? item.task, 180);
          item.instructions = text(body.instructions ?? body.notes ?? item.instructions, 800);
          item.userId = text(body.userId ?? item.userId, 80);
          if (!draft.clients.some(client => client.id === item.clientId && client.active)) throw new Error("Cliente inválido.");
          if (!draft.users.some(user => user.id === item.userId && user.active && ACTIVITY_ROLES.includes(user.role))) throw new Error("Selecione um responsável ativo (colaborador ou gestor).");
          if (item.userId !== previousUserId) {
            const reassignedAt = new Date();
            item.status = "EM ANDAMENTO";
            item.assignedAt = reassignedAt.toISOString();
            item.startDeadlineAt = new Date(reassignedAt.getTime() + 30 * 60000).toISOString();
            item.overdueAt = null;
            item.startedLate = false;
          }
        } else if (collection === "obligations") {
          if (auth.user.role === "COLABORADOR") {
            item.status = upper(body.status ?? item.status, 60);
            item.notes = text(body.notes ?? item.notes, 800);
          } else {
            item.clientId = text(body.clientId ?? item.clientId, 80);
            const tipoAnterior = item.type;
            item.type = upper(body.type ?? item.type, 120);
            if (item.type !== tipoAnterior && !(item.steps || []).some(step => step.done)) {
              const modelo = (draft.meta.obligationStepTemplates || []).find(entry => entry.name === item.type);
              item.steps = (modelo?.steps || []).map((name, order) => ({
                id: crypto.randomUUID(), order, name, done: false, doneAt: null, userId: null
              }));
            }
            item.period = periodValue(body.period ?? item.period);
            item.dueDate = dateValue(body.dueDate ?? item.dueDate);
            item.status = upper(body.status ?? item.status, 60);
            item.responsibleId = text(body.responsibleId ?? item.responsibleId, 80);
            item.recurrence = recurrenceValue(body.recurrence, item.recurrence);
            item.notes = text(body.notes ?? item.notes, 800);
          }
          if (!OBLIGATION_STATUS.includes(item.status)) throw new Error("Status inválido.");
          if (!draft.clients.some(client => client.id === item.clientId && client.active)) throw new Error("Cliente inválido.");
          if (item.responsibleId && !draft.users.some(user => user.id === item.responsibleId && user.active)) throw new Error("Responsável inválido ou inativo.");
        } else if (collection === "users") {
          item.name = text(body.name ?? item.name, 120);
          item.sector = normalizeSector(body.sector ?? item.sector ?? sectorForRole(item.role));
          item.role = SECTOR_ROLES[item.sector];
          item.active = body.active ?? item.active;
          if (!item.sector || !ROLES.includes(item.role)) throw new Error("Setor inválido.");
          if (item.id === auth.user.id && item.active === false) throw new Error("Você não pode desativar o próprio usuário.");
        }
        item.updatedAt = new Date().toISOString();
        updated = collection === "users" ? safeUser(item) : structuredClone(item);
        audit(draft, auth.user, "ATUALIZAR", singular, id, "Registro atualizado", req);
      });
      return send(res, 200, { ok: true, item: updated });
    }

    if (pathname === "/api/export/time-clock" && method === "GET") {
      const visible = filterTimeEntries(visibleTimeEntries(store.data, auth.user), url.searchParams, auth.user);
      const rows = groupTimeEntries(visible).map(day => ({
        date: day.date,
        user: store.data.users.find(item => item.id === day.userId)?.name || day.userId,
        entry: day.times.ENTRADA,
        lunchOut: day.times.SAIDA_ALMOCO,
        lunchReturn: day.times.RETORNO_ALMOCO,
        exit: day.times.SAIDA,
        totalMinutes: day.totalMinutes,
        status: day.complete ? "COMPLETO" : "INCOMPLETO",
        corrected: day.corrected ? "SIM" : "NÃO"
      }));
      const columns = [
        ["date", "Data"], ["user", "Colaborador"], ["entry", "Entrada"], ["lunchOut", "Saída almoço"],
        ["lunchReturn", "Retorno almoço"], ["exit", "Saída final"], ["totalMinutes", "Minutos trabalhados"],
        ["status", "Situação"], ["corrected", "Ajustado"]
      ].map(([key, label]) => ({ key, label }));
      return send(res, 200, toCsv(rows, columns), {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="dashboard-fiscal-ponto-${new Date().toISOString().slice(0, 10)}.csv"`
      });
    }

    const exportMatch = pathname.match(/^\/api\/export\/(clients|activities|obligations)$/);
    if (exportMatch && method === "GET") {
      const type = exportMatch[1];
      let rows = store.data[type];
      if (type === "activities") rows = visibleActivities(store.data, auth.user);
      if (type === "obligations") rows = visibleObligations(store.data, auth.user);
      const columns = {
        clients: [
          ["domainCode", "Código Domínio"], ["name", "Razão social"], ["cnpj", "CNPJ"],
          ["stateRegistration", "I.E."], ["municipalRegistration", "I.M."],
          ["responsibleCpf", "CPF do responsável"], ["city", "Cidade"],
          ["businessActivity", "Atividade"], ["taxRegime", "Tipo da empresa"], ["active", "Ativo"]
        ],
        activities: [
          ["date", "Data"], ["userId", "Responsável"], ["clientId", "Cliente"], ["task", "Atividade"],
          ["status", "Status"], ["assignedAt", "Atribuída em"], ["startDeadlineAt", "Prazo para iniciar"],
          ["startedAt", "Iniciada em"], ["finishedAt", "Finalizada em"], ["startedLate", "Iniciada com atraso"],
          ["totalMinutes", "Minutos"], ["instructions", "Orientações"], ["notes", "Observações da conclusão"]
        ],
        obligations: [
          ["clientId", "Cliente"], ["type", "Obrigação"], ["period", "Competência"], ["dueDate", "Prazo"],
          ["status", "Status"], ["responsibleId", "Responsável"], ["notes", "Observações"]
        ]
      }[type].map(([key, label]) => ({ key, label }));
      const body = toCsv(rows, columns);
      return send(res, 200, body, {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="dashboard-fiscal-${type}-${new Date().toISOString().slice(0, 10)}.csv"`
      });
    }

    return sendError(res, 404, "Rota não encontrada.");
  }

  function requireRole(auth, res, roles) {
    if (!roles.includes(auth.user.role)) {
      sendError(res, 403, "Você não tem permissão para esta operação.");
      return false;
    }
    return true;
  }

  async function serveStatic(req, res, pathname) {
    const staticFiles = {
      "/": "index.html",
      "/index.html": "index.html",
      "/app.js": "app.js",
      "/styles.css": "styles.css",
      "/manifest.webmanifest": "manifest.webmanifest",
      "/service-worker.js": "service-worker.js",
      "/icons/icon.svg": path.join("icons", "icon.svg"),
      "/icons/icon-192.png": path.join("icons", "icon-192.png"),
      "/icons/icon-512.png": path.join("icons", "icon-512.png")
    };
    const fileName = staticFiles[pathname];
    if (!fileName) return sendError(res, 404, "Arquivo não encontrado.");
    const file = path.join(publicDir, fileName);
    const content = await fs.readFile(file);
    const extension = path.extname(file);
    const type = {
      ".html": "text/html; charset=utf-8",
      ".js": "text/javascript; charset=utf-8",
      ".css": "text/css; charset=utf-8",
      ".webmanifest": "application/manifest+json; charset=utf-8",
      ".svg": "image/svg+xml; charset=utf-8",
      ".png": "image/png"
    }[extension] || "application/octet-stream";
    res.writeHead(200, {
      "Content-Type": type,
      "Content-Length": content.length,
      "Cache-Control": pathname === "/service-worker.js" ? "no-cache" : "public, max-age=300"
    });
    res.end(content);
  }

  const server = http.createServer(async (req, res) => {
    setSecurityHeaders(req, res);
    try {
      const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
      if (url.pathname.startsWith("/api/")) await handleApi(req, res, url);
      else if (req.method === "GET" || req.method === "HEAD") await serveStatic(req, res, url.pathname);
      else sendError(res, 405, "Método não permitido.");
    } catch (error) {
      if (!error.status || error.status >= 500) recordError(error, `${req.method} ${req.url}`);
      if (!res.headersSent) sendError(res, error.status || 400, error.message || "Erro interno.");
      else res.end();
    }
  });

  const sessionTimer = setInterval(() => {
    const now = Date.now();
    for (const [token, session] of sessions) if (session.expiresAt <= now) sessions.delete(token);
  }, 10 * 60000);
  sessionTimer.unref();

  const activityTimer = setInterval(() => {
    refreshOverdueActivities().catch(error => recordError(error, "controle de atraso das atividades"));
  }, 60000);
  activityTimer.unref();

  const backupTimer = setInterval(() => {
    if (store.data.users.length) store.createBackup("diario").catch(error => recordError(error, "backup diário"));
  }, 24 * 3600000);
  backupTimer.unref();

  async function listen() {
    await new Promise((resolve, reject) => {
      server.once("error", reject);
      server.listen(config.port, config.host, resolve);
    });
    const address = server.address();
    const activePort = typeof address === "object" ? address.port : config.port;
    await fs.writeFile(path.join(dataDir, "server.pid"), String(process.pid), "utf8");
    if (store.data.users.length) store.createBackup("inicio").catch(error => recordError(error, "backup de início"));
    return { port: activePort, localUrl: `http://localhost:${activePort}`, networkUrls: getNetworkAddresses(activePort) };
  }

  async function close() {
    clearInterval(sessionTimer);
    clearInterval(activityTimer);
    clearInterval(backupTimer);
    await new Promise(resolve => server.close(resolve));
    await fs.rm(path.join(dataDir, "server.pid"), { force: true });
  }

  return { close, config, dataDir, listen, server, store };
}

if (require.main === module) {
  createApplication().then(async app => {
    const info = await app.listen();
    console.log("\nDashboard Fiscal Office iniciado.");
    console.log(`Local: ${info.localUrl}`);
    for (const url of info.networkUrls) console.log(`Rede:  ${url}`);
    console.log("Pressione Ctrl+C para encerrar.\n");
    const shutdown = async () => {
      await app.close().catch(() => {});
      process.exit(0);
    };
    process.on("SIGINT", shutdown);
    process.on("SIGTERM", shutdown);
  }).catch(error => {
    console.error("Não foi possível iniciar o Dashboard Fiscal:", error.message);
    process.exit(1);
  });
}

module.exports = { APP_VERSION, createApplication };
