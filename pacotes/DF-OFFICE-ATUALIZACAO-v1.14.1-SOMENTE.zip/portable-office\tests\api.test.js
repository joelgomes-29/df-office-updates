"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs/promises");
const os = require("node:os");
const path = require("node:path");
const { createApplication } = require("../server");

async function startTestApp(dataDir, options = {}) {
  const app = await createApplication({ dataDir, host: "127.0.0.1", port: 0, sessionHours: 1, importBundledClients: false, importBundledTeam: false, ...options });
  const info = await app.listen();
  return { app, baseUrl: info.localUrl.replace("localhost", "127.0.0.1") };
}

async function request(baseUrl, route, options = {}, session = {}) {
  const headers = { Accept: "application/json", ...(options.headers || {}) };
  if (session.cookie) headers.Cookie = session.cookie;
  if (session.csrf && !["GET", "HEAD"].includes(options.method || "GET")) headers["X-CSRF-Token"] = session.csrf;
  let body = options.body;
  if (body && typeof body !== "string") {
    headers["Content-Type"] = "application/json";
    body = JSON.stringify(body);
  }
  const response = await fetch(`${baseUrl}${route}`, { ...options, headers, body });
  const setCookie = response.headers.get("set-cookie");
  if (setCookie) session.cookie = setCookie.split(";")[0];
  const contentType = response.headers.get("content-type") || "";
  const payload = contentType.includes("application/json") ? await response.json() : Buffer.from(await response.arrayBuffer());
  if (payload.csrf) session.csrf = payload.csrf;
  return { response, payload };
}

test("catálogo acessível à Rebeca sem criar atribuições automaticamente", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "df-catalog-test-"));
  const { app, baseUrl } = await startTestApp(dataDir);
  t.after(async () => { await app.close(); await fs.rm(dataDir, { recursive: true, force: true }); });
  const admin = {};
  let result = await request(baseUrl, "/api/obligation-catalog");
  assert.equal(result.response.status, 401);
  await request(baseUrl, "/api/setup", { method: "POST", body: { officeName: "Teste", name: "Admin", username: "admin", password: "Teste!Admin123" } }, admin);
  const before = await request(baseUrl, "/api/obligations", {}, admin);
  result = await request(baseUrl, "/api/obligation-catalog", {}, admin);
  assert.equal(result.payload.items.length, 149);
  assert.equal(result.payload.sourceRows, 151);
  assert.equal(new Set(result.payload.items.map(item => item.id)).size, 149);
  for (const [group, count] of [["DP", 43], ["FISCAL/CONTABIL", 39], ["ADM_FIN", 67]]) {
    assert.equal(result.payload.items.filter(item => item.departmentGroup === group).length, count);
  }
  assert.equal(result.payload.items.reduce((n, item) => n + item.sources.length, 0), 151);
  for (const [username, sector, expected] of [["rebeca", "GESTAO", 200], ["colaborador", "DP", 403]]) {
    const created = await request(baseUrl, "/api/users", { method: "POST", body: { name: username, username, sector, password: "Inicial!Teste123" } }, admin);
    const session = {};
    await request(baseUrl, "/api/login", { method: "POST", body: { sector, username, password: "Inicial!Teste123" } }, session);
    await request(baseUrl, `/api/users/${created.payload.item.id}/password`, { method: "PUT", body: { password: "Definitiva!Teste123" } }, session);
    result = await request(baseUrl, "/api/obligation-catalog", {}, session);
    assert.equal(result.response.status, expected);
    if (expected === 200) assert.equal(result.payload.items.length, 149);
  }
  const after = await request(baseUrl, "/api/obligations", {}, admin);
  assert.deepEqual(after.payload.items, before.payload.items);
});

test("fluxo completo multiusuário e persistência", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "dashboard-fiscal-test-"));
  const { app, baseUrl } = await startTestApp(dataDir);
  t.after(async () => {
    await app.close().catch(() => {});
    await fs.rm(dataDir, { recursive: true, force: true });
  });

  const admin = {};
  let result = await request(baseUrl, "/api/status");
  assert.equal(result.payload.setupRequired, true);

  result = await request(baseUrl, "/api/setup", {
    method: "POST",
    body: { officeName: "Contabilidade Teste", name: "Administrador", username: "admin", password: "Senha!Forte123" }
  }, admin);
  assert.equal(result.response.status, 201);
  assert.equal(result.payload.user.role, "ADMIN");
  assert.equal(result.payload.user.sector, "ADMIN");
  assert.ok(admin.cookie);
  assert.ok(admin.csrf);

  result = await request(baseUrl, "/api/clients", {
    method: "POST",
    body: {
      domainCode: "001", name: "Empresa Exemplo", cnpj: "12345678000190",
      stateRegistration: "ISENTO", municipalRegistration: "98765", responsibleCpf: "123.456.789-01",
      city: "Recife", businessActivity: "Comércio", taxRegime: "SIMPLES NACIONAL"
    }
  }, admin);
  assert.equal(result.response.status, 201);
  const client = result.payload.item;
  assert.equal(client.domainCode, "001");
  assert.equal(client.stateRegistration, "ISENTO");
  assert.equal(client.municipalRegistration, "98765");
  assert.equal(client.responsibleCpf, "12345678901");
  assert.equal(client.city, "RECIFE");
  assert.equal(client.businessActivity, "COMÉRCIO");
  assert.equal("email" in client, false);

  result = await request(baseUrl, "/api/users", {
    method: "POST",
    body: { name: "Analista Fiscal", username: "analista", password: "Outra!Senha123", sector: "FISCAL/CONTABIL", active: false }
  }, admin);
  assert.equal(result.response.status, 201);
  assert.equal(result.payload.accessReady, true);
  assert.equal(result.payload.item.active, true);
  const collaborator = result.payload.item;

  result = await request(baseUrl, "/api/obligations", {
    method: "POST",
    body: {
      clientId: client.id, type: "EFD REINF", period: "2026-08", dueDate: "2026-09-15",
      status: "PENDENTE", responsibleId: collaborator.id, notes: "Teste"
    }
  }, admin);
  assert.equal(result.response.status, 201);
  const obligation = result.payload.item;

  result = await request(baseUrl, "/api/activities", {
    method: "POST",
    body: {
      date: "2026-08-07", userId: collaborator.id, clientId: client.id,
      task: "Conferência fiscal", instructions: "Conferir documentos recebidos"
    }
  }, admin);
  assert.equal(result.response.status, 201);
  assert.equal(result.payload.item.status, "EM ANDAMENTO");
  assert.equal(result.payload.item.userId, collaborator.id);
  assert.ok(result.payload.item.startDeadlineAt);
  const activity = result.payload.item;

  const analyst = {};
  result = await request(baseUrl, "/api/login", {
    method: "POST", body: { sector: "DP", username: "analista", password: "Outra!Senha123" }
  }, analyst);
  assert.equal(result.response.status, 401);
  result = await request(baseUrl, "/api/login", {
    method: "POST", body: { sector: "FISCAL/CONTABIL", username: "analista", password: "Outra!Senha123" }
  }, analyst);
  assert.equal(result.response.status, 200);
  assert.equal(result.payload.user.role, "COLABORADOR");
  assert.equal(result.payload.user.sector, "FISCAL/CONTABIL");
  assert.equal(result.payload.user.mustChangePassword, true);

  result = await request(baseUrl, `/api/users/${collaborator.id}/password`, {
    method: "PUT", body: { password: "Definitiva!123" }
  }, analyst);
  assert.equal(result.response.status, 200);

  result = await request(baseUrl, "/api/clients", {
    method: "POST", body: { code: "002", name: "Operação proibida" }
  }, analyst);
  assert.equal(result.response.status, 403);

  result = await request(baseUrl, "/api/obligations", {
    method: "POST",
    body: { clientId: client.id, type: "OBRIGAÇÃO PROIBIDA", period: "2026-08", status: "PENDENTE" }
  }, analyst);
  assert.equal(result.response.status, 403);

  await app.store.transaction(draft => {
    draft.activities.find(item => item.id === activity.id).startDeadlineAt = new Date(Date.now() - 60000).toISOString();
  });
  result = await request(baseUrl, "/api/activities", {}, analyst);
  assert.equal(result.payload.items[0].status, "EM ATRASO");

  result = await request(baseUrl, `/api/activities/${activity.id}/start`, { method: "POST" }, analyst);
  assert.equal(result.response.status, 200);
  assert.equal(result.payload.item.status, "EM ATIVIDADE");
  assert.equal(result.payload.item.startedLate, true);
  assert.ok(result.payload.item.startedAt);

  result = await request(baseUrl, `/api/activities/${activity.id}`, {
    method: "PUT", body: { notes: "Alteração direta proibida" }
  }, analyst);
  assert.equal(result.response.status, 403);

  await app.store.transaction(draft => {
    draft.activities.find(item => item.id === activity.id).startedAt = new Date(Date.now() - 90 * 60000).toISOString();
  });
  result = await request(baseUrl, `/api/activities/${activity.id}/finish`, {
    method: "POST", body: { notes: "Atividade validada" }
  }, analyst);
  assert.equal(result.response.status, 200);
  assert.equal(result.payload.item.status, "CONCLUÍDO");
  assert.equal(result.payload.item.notes, "Atividade validada");
  assert.equal(result.payload.item.totalMinutes, 90);
  assert.ok(result.payload.item.finishedAt);

  result = await request(baseUrl, `/api/obligations/${obligation.id}`, {
    method: "PUT", body: { status: "EM ANDAMENTO", notes: "Em conferência" }
  }, analyst);
  assert.equal(result.response.status, 200);
  assert.equal(result.payload.item.status, "EM ANDAMENTO");

  result = await request(baseUrl, "/api/dashboard", {}, analyst);
  assert.equal(result.response.status, 200);
  assert.equal(result.payload.mode, "COLABORADOR");
  assert.equal(result.payload.recentActivities.length, 1);
  assert.equal(result.payload.recentActivities[0].userId, collaborator.id);
  assert.equal(result.payload.upcomingObligations.length, 1);
  assert.equal(result.payload.upcomingObligations[0].responsibleId, collaborator.id);
  assert.equal("metrics" in result.payload, false);
  assert.equal("teamProduction" in result.payload, false);

  // Sem ponto automatico, a presenca no painel depende de o colaborador bater a entrada.
  result = await request(baseUrl, "/api/time-clock/punch", { method: "POST", body: { type: "ENTRADA" } }, analyst);
  assert.equal(result.response.status, 201);

  result = await request(baseUrl, "/api/dashboard?from=2026-08-01&to=2026-08-31", {}, admin);
  assert.equal(result.response.status, 200);
  const adminActivity = result.payload.recentActivities.find(item => item.id === activity.id);
  assert.equal(adminActivity.notes, "Atividade validada");
  assert.ok(adminActivity.startedAt);
  assert.ok(adminActivity.finishedAt);
  const analystProduction = result.payload.teamProduction.find(item => item.userId === collaborator.id);
  assert.equal(analystProduction.activities, 1);
  assert.equal(analystProduction.concluded, 1);
  assert.equal(analystProduction.totalMinutes, 90);
  assert.equal(analystProduction.presence, "EM EXPEDIENTE");

  result = await request(baseUrl, "/api/budgets?period=2026-08", {}, analyst);
  assert.equal(result.response.status, 403);
  result = await request(baseUrl, "/api/administrative?period=2026-08", {}, analyst);
  assert.equal(result.response.status, 403);
  result = await request(baseUrl, "/api/administrative/entries", {
    method: "POST", body: { period: "2026-08", amount: 1, category: "Estrutura", correlation: "Teste" }
  }, analyst);
  assert.equal(result.response.status, 403);
  result = await request(baseUrl, `/api/budgets/${client.id}`, {
    method: "PUT", body: { period: "2026-08", extraCost: 100, extraCostDescription: "Teste" }
  }, analyst);
  assert.equal(result.response.status, 403);

  const administrativeEntries = [];
  for (const body of [
    { period: "2026-08", amount: "1.000,00", category: "Estrutura", correlation: "Aluguel e energia do escritório" },
    { period: "2026-08", amount: "1.200,00", category: "Sistemas", correlation: "Licenças usadas pela equipe" },
    { period: "2026-08", amount: "700,00", category: "Outra despesa", correlation: "Material extraordinário" },
    { period: "2026-08", amount: "100,00", category: "Temporária", correlation: "Será removida no teste" }
  ]) {
    result = await request(baseUrl, "/api/administrative/entries", { method: "POST", body }, admin);
    assert.equal(result.response.status, 201);
    administrativeEntries.push(result.payload.item);
  }
  result = await request(baseUrl, `/api/administrative/entries/${administrativeEntries[2].id}`, {
    method: "PUT",
    body: { period: "2026-08", amount: "800,00", category: "Tarifa especial", correlation: "Tarifa adicional discriminada" }
  }, admin);
  assert.equal(result.response.status, 200);
  assert.equal(result.payload.item.category, "TARIFA ESPECIAL");
  result = await request(baseUrl, `/api/administrative/entries/${administrativeEntries[3].id}`, { method: "DELETE" }, admin);
  assert.equal(result.response.status, 200);
  assert.equal(result.payload.summary.generalAdministrativeCost, 3000);
  assert.equal(result.payload.summary.administrativeCostPerHour, 2000);

  result = await request(baseUrl, "/api/administrative/entries", {
    method: "POST", body: { period: "2026-08", amount: "50,00", category: "Sem destino", correlation: "" }
  }, admin);
  assert.equal(result.response.status, 400);

  result = await request(baseUrl, `/api/budgets/${client.id}`, {
    method: "PUT",
    body: {
      period: "2026-08", extraCost: "500,00", extraRevenue: "6.000,00",
      extraCostDescription: "", extraRevenueDescription: ""
    }
  }, admin);
  assert.equal(result.response.status, 200);
  assert.equal(result.payload.report.totalMinutes, 90);
  assert.equal(result.payload.report.allocatedAdministrativeCost, 3000);
  assert.equal(result.payload.report.extraCost, 500);
  assert.equal(result.payload.report.extraRevenue, 6000);
  assert.equal(result.payload.report.totalCost, 3500);
  assert.equal(result.payload.report.costPerHour, 2333.33);
  assert.equal(result.payload.report.result, 2500);
  assert.equal(result.payload.report.resultPerHour, 1666.67);
  assert.equal(result.payload.report.departments[0].sector, "FISCAL/CONTABIL");
  assert.equal(result.payload.report.departments[0].employees[0].name, "Analista Fiscal");

  result = await request(baseUrl, "/api/budgets?period=2026-08", {}, admin);
  assert.equal(result.response.status, 200);
  assert.equal(result.payload.summary.totalHours, 1.5);
  assert.equal(result.payload.summary.generalAdministrativeCost, 3000);
  assert.equal(result.payload.summary.totalExtraCost, 500);
  assert.equal(result.payload.summary.totalExtraRevenue, 6000);
  assert.equal(result.payload.summary.totalCost, 3500);
  assert.equal(result.payload.summary.result, 2500);

  result = await request(baseUrl, "/api/administrative?period=2026-08", {}, admin);
  assert.equal(result.response.status, 200);
  assert.equal(result.payload.entries.length, 5);
  assert.equal(result.payload.administrative.categoryTotals.length, 3);
  assert.equal(result.payload.entries.find(item => item.type === "CUSTO EXTRA").origin, "Custo extra informado no CNPJ.");
  assert.equal(result.payload.entries.find(item => item.type === "RECEITA EXTRA").origin, "Receita extra informada no CNPJ.");

  result = await request(baseUrl, "/api/administrative/export.pdf?period=2026-08", {}, admin);
  assert.equal(result.response.status, 200);
  assert.equal(result.response.headers.get("content-type"), "application/pdf");
  assert.equal(result.payload.subarray(0, 8).toString("latin1"), "%PDF-1.4");

  result = await request(baseUrl, "/api/administrative/export.xls?period=2026-08", {}, admin);
  assert.equal(result.response.status, 200);
  assert.match(result.response.headers.get("content-type"), /application\/vnd\.ms-excel/);
  assert.match(result.payload.toString("utf8"), /Worksheet ss:Name="Clientes"/);

  result = await request(baseUrl, "/api/activities", {
    method: "POST",
    body: { date: "2026-08-08", userId: result.payload.user?.id || "usuario-forjado", clientId: client.id, task: "Atividade criada pelo colaborador" }
  }, analyst);
  assert.equal(result.response.status, 201);
  assert.equal(result.payload.item.userId, collaborator.id);
  assert.equal(result.payload.item.createdByUserId, collaborator.id);
  assert.equal(result.payload.item.selfCreated, true);
  assert.equal(result.payload.item.status, "EM ANDAMENTO");

  const raw = JSON.parse(await fs.readFile(path.join(dataDir, "db.json"), "utf8"));
  assert.equal(raw.users.length, 2);
  assert.equal(raw.clients.length, 1);
  assert.equal(raw.activities.length, 2);
  assert.equal(raw.budgets.length, 1);
  assert.equal(raw.budgets[0].extraCost, 500);
  assert.equal(raw.budgets[0].extraRevenue, 6000);
  assert.equal(raw.administrativeCosts.length, 0);
  assert.equal(raw.administrativeEntries.length, 3);
  assert.ok(raw.audit.length >= 10);
});

test("converte custos detalhados antigos em custo extra sem perder o valor", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "dashboard-fiscal-budget-legacy-"));
  const first = await startTestApp(dataDir);
  const admin = {};
  await request(first.baseUrl, "/api/setup", {
    method: "POST",
    body: { officeName: "Contabilidade Legada", name: "Administrador", username: "admin", password: "Senha!Forte123" }
  }, admin);
  const created = await request(first.baseUrl, "/api/clients", {
    method: "POST", body: { domainCode: "001", name: "Cliente Legado", cnpj: "12345678000190" }
  }, admin);
  await first.app.close();

  const dbPath = path.join(dataDir, "db.json");
  const raw = JSON.parse(await fs.readFile(dbPath, "utf8"));
  raw.schemaVersion = 4;
  delete raw.administrativeEntries;
  raw.budgets.push({
    id: "orcamento-legado", clientId: created.payload.item.id, period: "2026-08",
    structureCost: 1000, equipmentCost: 500, maintenanceCost: 250,
    systemsCost: 300, employeeCost: 2000, taxCost: 400, financingCost: 50
  });
  raw.administrativeCosts.push({
    id: "administrativo-legado", period: "2026-08", structureCost: 1000,
    equipmentCost: 500, maintenanceCost: 0, systemsCost: 0, employeeCost: 0,
    taxCost: 0, financingCost: 0, notes: "Custos administrativos migrados"
  });
  await fs.writeFile(dbPath, `${JSON.stringify(raw, null, 2)}\n`, "utf8");

  const second = await startTestApp(dataDir);
  t.after(async () => {
    await second.app.close().catch(() => {});
    await fs.rm(dataDir, { recursive: true, force: true });
  });
  const restartedAdmin = {};
  await request(second.baseUrl, "/api/login", {
    method: "POST", body: { sector: "ADMIN", username: "admin", password: "Senha!Forte123" }
  }, restartedAdmin);
  const report = await request(second.baseUrl, "/api/budgets?period=2026-08", {}, restartedAdmin);
  const clientReport = report.payload.items.find(item => item.clientId === created.payload.item.id);
  assert.equal(report.response.status, 200);
  assert.equal(clientReport.extraCost, 4500);
  assert.equal(clientReport.totalCost, 4500);
  assert.match(clientReport.extraCostDescription, /versão anterior/);
  assert.equal(report.payload.summary.generalAdministrativeCost, 1500);
  assert.equal(report.payload.administrative.entries.length, 2);
  assert.equal(report.payload.administrative.entries[0].correlation, "Custos administrativos migrados");
});

test("importa uma única vez as 102 empresas FG incorporadas", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "dashboard-fiscal-seed-"));
  const first = await startTestApp(dataDir, { importBundledClients: true });
  await first.app.close();
  const second = await startTestApp(dataDir, { importBundledClients: true });
  t.after(async () => {
    await second.app.close().catch(() => {});
    await fs.rm(dataDir, { recursive: true, force: true });
  });

  assert.equal(second.app.store.data.clients.length, 102);
  assert.equal(second.app.store.data.clients.filter(item => item.taxRegime === "SIMPLES NACIONAL").length, 51);
  assert.equal(second.app.store.data.clients.filter(item => item.taxRegime === "LUCRO PRESUMIDO").length, 23);
  assert.equal(second.app.store.data.clients.filter(item => item.taxRegime === "LUCRO REAL").length, 15);
  assert.equal(second.app.store.data.clients.filter(item => item.taxRegime === "IMUNE").length, 3);
  assert.equal(second.app.store.data.clients.filter(item => item.taxRegime === "MEI").length, 10);
  assert.equal(second.app.store.data.meta.seedImports["empresas-fg-julho-2026-v1"].added, 102);
  assert.equal(second.app.store.data.audit.filter(item => item.action === "IMPORTAR").length, 1);
});

test("cria atividades e obrigações para múltiplos CNPJs e responsáveis", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "dashboard-fiscal-batch-"));
  const { app, baseUrl } = await startTestApp(dataDir);
  t.after(async () => {
    await app.close().catch(() => {});
    await fs.rm(dataDir, { recursive: true, force: true });
  });
  const admin = {};
  await request(baseUrl, "/api/setup", {
    method: "POST", body: { officeName: "Lotes", name: "Admin", username: "admin", password: "Senha!Forte123" }
  }, admin);
  const clients = [];
  for (const body of [
    { domainCode: "101", name: "Cliente Simples", cnpj: "11111111000191", taxRegime: "EMPRESAS SIMPLES" },
    { domainCode: "102", name: "Cliente Real", cnpj: "22222222000191", taxRegime: "EMPRESA LUCRO REAL" }
  ]) {
    const created = await request(baseUrl, "/api/clients", { method: "POST", body }, admin);
    assert.equal(created.response.status, 201);
    clients.push(created.payload.item);
  }
  assert.equal(clients[0].taxRegime, "SIMPLES NACIONAL");
  assert.equal(clients[1].taxRegime, "LUCRO REAL");
  const filtered = await request(baseUrl, "/api/clients?type=LUCRO%20REAL&q=real", {}, admin);
  assert.equal(filtered.payload.items.length, 1);
  assert.equal(filtered.payload.items[0].id, clients[1].id);

  const collaborators = [];
  for (const body of [
    { name: "Pessoa DP", username: "pessoa.dp", password: "Senha!Pessoa123", sector: "DP" },
    { name: "Pessoa Fiscal", username: "pessoa.fiscal", password: "Senha!Pessoa456", sector: "FISCAL/CONTABIL" }
  ]) {
    const created = await request(baseUrl, "/api/users", { method: "POST", body }, admin);
    assert.equal(created.response.status, 201);
    collaborators.push(created.payload.item);
  }

  let result = await request(baseUrl, "/api/activities", {
    method: "POST",
    body: { date: "2026-08-15", clientIds: clients.map(item => item.id), userIds: collaborators.map(item => item.id), task: "Atividade em lote" }
  }, admin);
  assert.equal(result.response.status, 201);
  assert.equal(result.payload.count, 4);
  assert.equal(new Set(result.payload.items.map(item => `${item.clientId}:${item.userId}`)).size, 4);

  result = await request(baseUrl, "/api/obligations", {
    method: "POST",
    body: { clientIds: clients.map(item => item.id), responsibleIds: collaborators.map(item => item.id), type: "DCTFWEB", period: "2026-08", status: "PENDENTE" }
  }, admin);
  assert.equal(result.response.status, 201);
  assert.equal(result.payload.count, 4);
  assert.equal(new Set(result.payload.items.map(item => `${item.clientId}:${item.responsibleId}`)).size, 4);

  const collaboratorSession = {};
  result = await request(baseUrl, "/api/login", {
    method: "POST", body: { sector: "DP", username: "pessoa.dp", password: "Senha!Pessoa123" }
  }, collaboratorSession);
  assert.equal(result.response.status, 200);
  result = await request(baseUrl, `/api/users/${collaborators[0].id}/password`, {
    method: "PUT", body: { password: "Definitiva!Pessoa123" }
  }, collaboratorSession);
  assert.equal(result.response.status, 200);
  result = await request(baseUrl, "/api/activities", {
    method: "POST",
    body: { date: "2026-08-15", clientIds: clients.map(item => item.id), userIds: [collaborators[1].id], task: "Atividade própria em lote" }
  }, collaboratorSession);
  assert.equal(result.response.status, 201);
  assert.equal(result.payload.count, 2);
  assert.ok(result.payload.items.every(item => item.userId === collaborators[0].id && item.selfCreated));
});

test("cadastra a equipe FG por setor e gera acessos temporários", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "dashboard-fiscal-team-"));
  const { app, baseUrl } = await startTestApp(dataDir, { importBundledTeam: true });
  t.after(async () => {
    await app.close().catch(() => {});
    await fs.rm(dataDir, { recursive: true, force: true });
  });
  const admin = {};
  const setup = await request(baseUrl, "/api/setup", {
    method: "POST",
    body: { officeName: "Equipe FG", name: "Administrador Inicial", username: "admin", password: "Senha!Forte123" }
  }, admin);
  assert.equal(setup.response.status, 201);
  assert.equal(app.store.data.users.length, 11);
  assert.equal(app.store.data.users.filter(item => item.sector === "DP").length, 1);
  assert.equal(app.store.data.users.filter(item => item.sector === "FISCAL/CONTABIL").length, 4);
  assert.equal(app.store.data.users.filter(item => item.sector === "GESTAO").length, 3);
  assert.equal(app.store.data.users.filter(item => item.sector === "ADMIN").length, 3);
  assert.equal(app.store.data.meta.teamSeedImports["equipe-fg-agosto-2026-v1"].added, 10);
  const accessFile = await fs.readFile(path.join(dataDir, "ACESSOS_INICIAIS_EQUIPE_FG.txt"), "utf8");
  assert.match(accessFile, /Nome: MAYARA/);
  assert.match(accessFile, /Usuário: flavio\.cesario/);
  assert.equal((accessFile.match(/Senha temporária:/g) || []).length, 10);
  assert.equal((accessFile.match(/Senha temporária: 123456/g) || []).length, 10);
  for (const member of app.store.data.users.filter(item => item.username !== "admin")) {
    const session = {};
    const login = await request(baseUrl, "/api/login", {
      method: "POST", body: { sector: member.sector, username: member.username, password: "123456" }
    }, session);
    assert.equal(login.response.status, 200);
    assert.equal(login.payload.user.mustChangePassword, true);
    const blocked = await request(baseUrl, "/api/activities", {}, session);
    assert.equal(blocked.response.status, 403);
    const weak = await request(baseUrl, `/api/users/${member.id}/password`, {
      method: "PUT", body: { password: "123456" }
    }, session);
    assert.notEqual(weak.response.status, 200);
  }
});

test("protege mutações sem CSRF", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "dashboard-fiscal-csrf-"));
  const { app, baseUrl } = await startTestApp(dataDir);
  t.after(async () => {
    await app.close().catch(() => {});
    await fs.rm(dataDir, { recursive: true, force: true });
  });
  const session = {};
  await request(baseUrl, "/api/setup", {
    method: "POST",
    body: { officeName: "Teste", name: "Admin", username: "admin", password: "Senha!Forte123" }
  }, session);
  const csrf = session.csrf;
  session.csrf = "";
  const result = await request(baseUrl, "/api/clients", {
    method: "POST", body: { code: "001", name: "Não deve gravar" }
  }, session);
  assert.equal(result.response.status, 403);
  session.csrf = csrf;
});

test("registra ponto em sequência e permite ajuste auditado pelo gestor", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "dashboard-fiscal-clock-"));
  const { app, baseUrl } = await startTestApp(dataDir);
  t.after(async () => {
    await app.close().catch(() => {});
    await fs.rm(dataDir, { recursive: true, force: true });
  });

  const admin = {};
  await request(baseUrl, "/api/setup", {
    method: "POST",
    body: { officeName: "Contabilidade Ponto", name: "Administrador", username: "admin", password: "Senha!Forte123" }
  }, admin);
  let result = await request(baseUrl, "/api/users", {
    method: "POST",
    body: { name: "Colaborador Ponto", username: "ponto", password: "Outra!Senha123", sector: "DP" }
  }, admin);
  const collaborator = result.payload.item;

  const employee = {};
  result = await request(baseUrl, "/api/login", {
    method: "POST", body: { sector: "DP", username: "ponto", password: "Outra!Senha123" }
  }, employee);
  assert.equal(result.response.status, 200);
  assert.equal(result.payload.autoPunch, undefined, "o login não registra mais ponto automaticamente");
  result = await request(baseUrl, `/api/users/${collaborator.id}/password`, {
    method: "PUT", body: { password: "Definitiva!123" }
  }, employee);
  assert.equal(result.response.status, 200);

  result = await request(baseUrl, "/api/time-clock");
  assert.equal(result.response.status, 401);

  result = await request(baseUrl, "/api/time-clock", {}, employee);
  const workDate = result.payload.today.date;
  assert.equal(result.payload.today.nextAction, "ENTRADA", "sem ponto automatico, a proxima marcacao e a entrada");
  assert.equal(result.payload.today.entries.length, 0);

  result = await request(baseUrl, "/api/time-clock/punch", {
    method: "POST", body: { type: "RETORNO_ALMOCO" }
  }, employee);
  assert.equal(result.response.status, 409);

  for (const type of ["ENTRADA", "SAIDA_ALMOCO", "RETORNO_ALMOCO", "SAIDA"]) {
    result = await request(baseUrl, "/api/time-clock/punch", { method: "POST", body: { type } }, employee);
    assert.equal(result.response.status, 201);
    assert.equal(result.payload.item.type, type);
    assert.equal(result.payload.item.userId, collaborator.id);
  }

  result = await request(baseUrl, "/api/time-clock/punch", {
    method: "POST", body: { type: "SAIDA" }
  }, employee);
  assert.equal(result.response.status, 409);

  const employeeAgain = {};
  result = await request(baseUrl, "/api/login", {
    method: "POST", body: { sector: "DP", username: "ponto", password: "Definitiva!123" }
  }, employeeAgain);
  assert.equal(result.response.status, 200);
  assert.equal(result.payload.autoPunch, undefined);

  result = await request(baseUrl, "/api/time-clock/manual", {
    method: "POST",
    body: { userId: collaborator.id, date: workDate, type: "ENTRADA", time: "08:00", reason: "Correção de teste" }
  }, employee);
  assert.equal(result.response.status, 403);

  const corrections = {
    ENTRADA: "08:00", SAIDA_ALMOCO: "12:00", RETORNO_ALMOCO: "13:00", SAIDA: "17:00"
  };
  for (const [type, time] of Object.entries(corrections)) {
    result = await request(baseUrl, "/api/time-clock/manual", {
      method: "POST",
      body: { userId: collaborator.id, date: workDate, type, time, reason: "Ajuste solicitado pelo colaborador" }
    }, admin);
    assert.equal(result.response.status, 200);
    assert.equal(result.payload.item.automatic, false);
  }

  result = await request(baseUrl, `/api/time-clock?from=${workDate}&to=${workDate}&userId=${collaborator.id}`, {}, admin);
  assert.equal(result.response.status, 200);
  assert.equal(result.payload.days.length, 1);
  assert.equal(result.payload.days[0].totalMinutes, 480);
  assert.equal(result.payload.days[0].complete, true);
  assert.equal(result.payload.days[0].corrected, true);

  const raw = JSON.parse(await fs.readFile(path.join(dataDir, "db.json"), "utf8"));
  assert.equal(raw.schemaVersion, 6);
  assert.equal(raw.timeEntries.length, 4);
  assert.ok(raw.audit.filter(item => item.entity === "PONTO").length >= 8);
});

test("gestores controlam atendimentos, métricas, conversões e demandas com anexos", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "df-attendance-test-"));
  const { app, baseUrl } = await startTestApp(dataDir);
  t.after(async () => {
    await app.close().catch(() => {});
    await fs.rm(dataDir, { recursive: true, force: true });
  });
  const admin = {};
  await request(baseUrl, "/api/setup", { method: "POST", body: { officeName: "FG", name: "Admin", username: "admin", password: "Senha!Forte123" } }, admin);
  let result = await request(baseUrl, "/api/clients", { method: "POST", body: { code: "001", name: "Empresa Atendimento", cnpj: "12345678000190", taxRegime: "SIMPLES NACIONAL" } }, admin);
  const client = result.payload.item;
  result = await request(baseUrl, "/api/users", { method: "POST", body: { name: "Mayara", username: "mayara", sector: "DP", password: "Inicial!Mayara123" } }, admin);
  const mayara = result.payload.item;
  result = await request(baseUrl, "/api/users", { method: "POST", body: { name: "Rebeca", username: "rebeca", sector: "GESTAO", password: "Inicial!Rebeca123" } }, admin);
  const rebeca = result.payload.item;
  const manager = {};
  await request(baseUrl, "/api/login", { method: "POST", body: { username: "rebeca", sector: "GESTAO", password: "Inicial!Rebeca123" } }, manager);
  await request(baseUrl, `/api/users/${rebeca.id}/password`, { method: "PUT", body: { password: "Definitiva!Rebeca123" } }, manager);

  result = await request(baseUrl, "/api/attendances", { method: "POST", body: { clientId: client.id, contactName: "Maria", contactPhone: "81999990000", subject: "Enviar folha", message: "Cliente solicitou conferência da folha." } }, manager);
  assert.equal(result.response.status, 201);
  const attendance = result.payload.item;
  assert.equal(attendance.status, "PENDENTE");
  result = await request(baseUrl, `/api/attendances/${attendance.id}/start`, { method: "POST", body: { assignedUserId: rebeca.id } }, manager);
  assert.equal(result.payload.item.status, "EM ATENDIMENTO");
  await app.store.transaction(draft => { draft.attendances.find(item => item.id === attendance.id).startedAt = new Date(Date.now() - 65 * 60000).toISOString(); });
  result = await request(baseUrl, `/api/attendances/${attendance.id}/finish`, { method: "POST", body: { status: "FINALIZADO", closingNotes: "Conferido" } }, manager);
  assert.equal(result.payload.item.status, "FINALIZADO");
  result = await request(baseUrl, "/api/attendance-metrics", {}, manager);
  assert.equal(result.payload.metrics.completed, 1);
  assert.ok(result.payload.metrics.totalMinutes >= 65);
  assert.equal(result.payload.employees[0].userId, rebeca.id);

  result = await request(baseUrl, `/api/attendances/${attendance.id}/convert`, { method: "POST", body: { kind: "ATIVIDADE", responsibleId: mayara.id, date: "2026-09-12", title: "CONFERIR FOLHA", instructions: "Conferir solicitação do WhatsApp" } }, manager);
  assert.equal(result.response.status, 200);
  assert.equal(result.payload.item.userId, mayara.id);
  assert.equal(result.payload.item.sourceAttendanceId, attendance.id);
  result = await request(baseUrl, `/api/attendances/${attendance.id}/convert`, { method: "POST", body: { kind: "OBRIGAÇÃO", responsibleId: mayara.id, period: "2026-09", dueDate: "2026-09-30", title: "OBRIGAÇÃO DA FOLHA", instructions: "Originada no atendimento" } }, manager);
  assert.equal(result.payload.item.responsibleId, mayara.id);
  assert.equal(result.payload.item.sourceAttendanceId, attendance.id);

  const attachment = Buffer.from("documento interno", "utf8").toString("base64");
  result = await request(baseUrl, "/api/demands", { method: "POST", body: { title: "Revisar atendimento", description: "Demanda entre gestores", destinationSector: "GESTORES", assignedUserId: rebeca.id, priority: "ALTA", attachments: [{ name: "nota.txt", type: "text/plain", data: `data:text/plain;base64,${attachment}` }] } }, manager);
  assert.equal(result.response.status, 201);
  const demand = result.payload.item;
  assert.equal(demand.attachments.length, 1);
  result = await request(baseUrl, `/api/demands/${demand.id}/attachments/${demand.attachments[0].id}`, {}, manager);
  assert.equal(result.payload.toString("utf8"), "documento interno");
  result = await request(baseUrl, `/api/demands/${demand.id}`, { method: "PUT", body: { status: "EM ANDAMENTO", assignedUserId: rebeca.id } }, manager);
  assert.equal(result.payload.item.status, "EM ANDAMENTO");
  result = await request(baseUrl, `/api/demands/${demand.id}`, { method: "PUT", body: { status: "CONCLUÍDA" } }, manager);
  assert.ok(result.payload.item.completedAt);
  result = await request(baseUrl, "/api/export/attendances", {}, manager);
  assert.equal(result.response.status, 200);
  assert.match(result.payload.toString("utf8"), /Empresa Atendimento/);

  const employee = {};
  await request(baseUrl, "/api/login", { method: "POST", body: { username: "mayara", sector: "DP", password: "Inicial!Mayara123" } }, employee);
  await request(baseUrl, `/api/users/${mayara.id}/password`, { method: "PUT", body: { password: "Definitiva!Mayara123" } }, employee);
  assert.equal((await request(baseUrl, "/api/attendances", {}, employee)).response.status, 403);
  assert.equal((await request(baseUrl, "/api/demands", {}, employee)).response.status, 403);
});

test("migra Josne para Gestão preservando senha e histórico", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "df-josne-migration-test-"));
  const first = await startTestApp(dataDir);
  const admin = {};
  await request(first.baseUrl, "/api/setup", { method: "POST", body: { officeName: "FG", name: "Admin", username: "admin", password: "Senha!Forte123" } }, admin);
  const created = await request(first.baseUrl, "/api/users", { method: "POST", body: { name: "Josne", username: "josne", sector: "DP", password: "Inicial!Josne123" } }, admin);
  const originalHash = first.app.store.data.users.find(user => user.id === created.payload.item.id).passwordHash;
  await first.app.store.transaction(draft => { draft.timeEntries.push({ id: "ponto-josne", userId: created.payload.item.id, date: "2026-09-11", time: "08:00", type: "ENTRADA" }); });
  await first.app.close();
  const second = await startTestApp(dataDir);
  t.after(async () => { await second.app.close().catch(() => {}); await fs.rm(dataDir, { recursive: true, force: true }); });
  const josne = second.app.store.data.users.find(user => user.username === "josne");
  assert.equal(josne.sector, "GESTAO");
  assert.equal(josne.role, "GESTOR");
  assert.equal(josne.passwordHash, originalHash);
  assert.equal(second.app.store.data.timeEntries.find(item => item.id === "ponto-josne").userId, josne.id);
  assert.ok(second.app.store.data.meta.migrations["josne-gestao-v1"]);
});

test("quatro senhas erradas bloqueiam até um gestor liberar, sem prazo", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "df-bloqueio-teste-"));
  const { app, baseUrl } = await startTestApp(dataDir);
  t.after(async () => { await app.close().catch(() => {}); await fs.rm(dataDir, { recursive: true, force: true }); });

  const admin = {};
  await request(baseUrl, "/api/setup", { method: "POST", body: { officeName: "FG Teste", name: "Admin", username: "admin", password: "Senha!Forte123" } }, admin);
  const criado = await request(baseUrl, "/api/users", { method: "POST", body: { name: "Mayara", username: "mayara", sector: "DP", password: "Inicial!Teste123" } }, admin);

  // As três primeiras erradas avisam quantas restam.
  for (const restantes of [3, 2, 1]) {
    const erro = await request(baseUrl, "/api/login", { method: "POST", body: { sector: "DP", username: "mayara", password: "errada" } });
    assert.equal(erro.response.status, 401);
    assert.match(erro.payload.error, new RegExp(`Restam ${restantes} tentativa`));
  }

  // A quarta bloqueia, e a mensagem não fala em minutos.
  let bloqueio = await request(baseUrl, "/api/login", { method: "POST", body: { sector: "DP", username: "mayara", password: "errada" } });
  assert.equal(bloqueio.response.status, 423);
  assert.match(bloqueio.payload.error, /gestor ou administrador/i);
  assert.doesNotMatch(bloqueio.payload.error, /minuto/i, "não existe mais liberação por tempo");

  // Nem com a senha certa entra enquanto estiver bloqueado.
  bloqueio = await request(baseUrl, "/api/login", { method: "POST", body: { sector: "DP", username: "mayara", password: "Inicial!Teste123" } });
  assert.equal(bloqueio.response.status, 423);

  // O bloqueio sobrevive ao reinício do servidor.
  await app.close();
  const reiniciado = await startTestApp(dataDir);
  const depoisDoReinicio = await request(reiniciado.baseUrl, "/api/login", { method: "POST", body: { sector: "DP", username: "mayara", password: "Inicial!Teste123" } });
  assert.equal(depoisDoReinicio.response.status, 423, "reiniciar o servidor não libera mais o acesso");

  const admin2 = {};
  await request(reiniciado.baseUrl, "/api/login", { method: "POST", body: { sector: "ADMIN", username: "admin", password: "Senha!Forte123" } }, admin2);
  let usuarios = await request(reiniciado.baseUrl, "/api/users", {}, admin2);
  const bloqueada = usuarios.payload.items.find(item => item.username === "mayara");
  assert.equal(bloqueada.locked, true);
  assert.equal(bloqueada.failedAttempts, 4);

  // Caminho 1: o gestor redefine a senha, que é o que o documento pede.
  const redefinida = await request(reiniciado.baseUrl, `/api/users/${criado.payload.item.id}/password`, {
    method: "PUT", body: { password: "Redefinida!Teste123" }
  }, admin2);
  assert.equal(redefinida.response.status, 200);
  const entrou = await request(reiniciado.baseUrl, "/api/login", { method: "POST", body: { sector: "DP", username: "mayara", password: "Redefinida!Teste123" } });
  assert.equal(entrou.response.status, 200, "trocar a senha devolve o acesso");

  usuarios = await request(reiniciado.baseUrl, "/api/users", {}, admin2);
  assert.equal(usuarios.payload.items.find(item => item.username === "mayara").locked, false);

  // Caminho 2: o botão Liberar bloqueio, sem trocar a senha.
  for (let tentativa = 0; tentativa < 4; tentativa += 1) {
    await request(reiniciado.baseUrl, "/api/login", { method: "POST", body: { sector: "DP", username: "mayara", password: "errada" } });
  }
  const travada = await request(reiniciado.baseUrl, "/api/login", { method: "POST", body: { sector: "DP", username: "mayara", password: "Redefinida!Teste123" } });
  assert.equal(travada.response.status, 423);
  const liberada = await request(reiniciado.baseUrl, `/api/users/${criado.payload.item.id}/unlock`, { method: "POST", body: {} }, admin2);
  assert.equal(liberada.response.status, 200);
  const voltou = await request(reiniciado.baseUrl, "/api/login", { method: "POST", body: { sector: "DP", username: "mayara", password: "Redefinida!Teste123" } });
  assert.equal(voltou.response.status, 200);

  // Um login certo zera a contagem antes de chegar ao bloqueio.
  await request(reiniciado.baseUrl, "/api/login", { method: "POST", body: { sector: "DP", username: "mayara", password: "errada" } });
  await request(reiniciado.baseUrl, "/api/login", { method: "POST", body: { sector: "DP", username: "mayara", password: "Redefinida!Teste123" } });
  usuarios = await request(reiniciado.baseUrl, "/api/users", {}, admin2);
  assert.equal(usuarios.payload.items.find(item => item.username === "mayara").failedAttempts, 0);

  await reiniciado.app.close();
});
