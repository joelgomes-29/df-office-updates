"use strict";

// Socorro para o caso extremo: todos os administradores bloqueados ao mesmo tempo.
// Use com o servidor PARADO, senão a alteração é sobrescrita.
//
//   runtime\node.exe tools\liberar-acesso.js            lista quem está bloqueado
//   runtime\node.exe tools\liberar-acesso.js gerson     libera esse usuário
//   runtime\node.exe tools\liberar-acesso.js --todos    libera todos

const fs = require("node:fs");
const path = require("node:path");

const raiz = path.resolve(__dirname, "..");
const banco = path.join(raiz, "data", "db.json");
const alvo = (process.argv[2] || "").trim().toLowerCase();

if (!fs.existsSync(banco)) {
  console.error(`Banco não encontrado em ${banco}`);
  process.exit(1);
}

const dados = JSON.parse(fs.readFileSync(banco, "utf8"));
const bloqueados = dados.users.filter(user => Number(user.failedAttempts || 0) > 0);

if (!alvo) {
  console.log(`Banco: ${banco}\n`);
  if (!bloqueados.length) {
    console.log("Nenhum usuário com tentativas erradas registradas.");
  } else {
    console.log("Usuários com tentativas erradas:\n");
    for (const user of bloqueados) {
      const situacao = Number(user.failedAttempts) >= 4 ? "BLOQUEADO" : "com tentativas";
      console.log(`  ${user.username.padEnd(18)} ${String(user.failedAttempts).padStart(2)} tentativa(s)  ${situacao}`);
    }
    console.log("\nPara liberar:  runtime\\node.exe tools\\liberar-acesso.js <usuario>");
    console.log("Para liberar todos:  runtime\\node.exe tools\\liberar-acesso.js --todos");
  }
  process.exit(0);
}

const liberar = alvo === "--todos" ? dados.users : dados.users.filter(user => user.username === alvo);
if (!liberar.length) {
  console.error(`Usuário "${alvo}" não encontrado.`);
  process.exit(1);
}

let alterados = 0;
for (const user of liberar) {
  if (!Number(user.failedAttempts || 0) && !user.lockedAt) continue;
  user.failedAttempts = 0;
  user.lockedAt = null;
  user.updatedAt = new Date().toISOString();
  alterados += 1;
  console.log(`liberado: ${user.username}`);
}

if (!alterados) {
  console.log("Nada a fazer: ninguém estava bloqueado.");
  process.exit(0);
}

dados.audit.push({
  id: `liberacao-${Date.now()}`,
  at: new Date().toISOString(),
  userId: null,
  username: "console do servidor",
  action: "LIBERAR",
  entity: "ACESSO",
  entityId: null,
  details: `${alterados} acesso(s) liberado(s) pelo utilitário no servidor`,
  ip: "local"
});

const temporario = `${banco}.liberar.tmp`;
fs.writeFileSync(temporario, `${JSON.stringify(dados, null, 2)}\n`, "utf8");
fs.renameSync(temporario, banco);
console.log(`\n${alterados} acesso(s) liberado(s). Inicie o servidor novamente.`);
