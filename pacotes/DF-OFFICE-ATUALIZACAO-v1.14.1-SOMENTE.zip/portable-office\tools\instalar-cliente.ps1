param(
  [string]$ServerUrl,
  [string]$ShortcutDirectory,
  [switch]$NoLaunch
)

. (Join-Path $PSScriptRoot "common.ps1")

if ([string]::IsNullOrWhiteSpace($ServerUrl)) {
  Write-Host "Informe o endereço exibido no arquivo ENDERECOS_DO_ESCRITORIO.txt do computador servidor."
  $ServerUrl = Read-Host "Endereço (ex.: http://192.168.1.20:8787)"
}
$ServerUrl = $ServerUrl.Trim().TrimEnd("/")

$uri = $null
if (-not [Uri]::TryCreate($ServerUrl, [UriKind]::Absolute, [ref]$uri) -or $uri.Scheme -notin @("http", "https")) {
  throw "Endereço inválido. Use o formato http://IP-DO-SERVIDOR:8787"
}

try {
  $health = Invoke-RestMethod -Uri "$ServerUrl/api/health" -TimeoutSec 5
  if (-not $health.ok) { throw "Resposta inesperada." }
} catch {
  throw "Não foi possível acessar o servidor em $ServerUrl. Verifique se o PC servidor está ligado e se o firewall foi configurado."
}

$edgeCandidates = @(@(
  (Join-Path ${env:ProgramFiles(x86)} "Microsoft\Edge\Application\msedge.exe"),
  (Join-Path $env:ProgramFiles "Microsoft\Edge\Application\msedge.exe")
) | Where-Object { $_ -and (Test-Path -LiteralPath $_) })
if ($edgeCandidates.Count -eq 0) { throw "Microsoft Edge não encontrado neste computador." }

if ([string]::IsNullOrWhiteSpace($ShortcutDirectory)) {
  $ShortcutDirectory = [Environment]::GetFolderPath("Desktop")
}
New-Item -ItemType Directory -Path $ShortcutDirectory -Force | Out-Null

# A logo da empresa fica guardada no perfil do usuário, para o atalho continuar
# com o ícone certo mesmo que a pasta do instalador seja apagada depois.
$iconeCandidatos = @(
  (Join-Path (Split-Path $PSScriptRoot -Parent) "icone\logo-fg.ico"),
  (Join-Path (Split-Path $PSScriptRoot -Parent) "seed\branding\logo-fg.ico")
)
$iconeOrigem = $iconeCandidatos | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
$iconeDestino = Join-Path $env:LOCALAPPDATA "DF Office\logo-fg.ico"
if (Test-Path -LiteralPath $iconeOrigem) {
  New-Item -ItemType Directory -Path (Split-Path $iconeDestino -Parent) -Force | Out-Null
  Copy-Item -LiteralPath $iconeOrigem -Destination $iconeDestino -Force
}

$shortcutPath = Join-Path $ShortcutDirectory "Dashboard Fiscal Office.lnk"
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = $edgeCandidates[0]
$shortcut.Arguments = "--app=$ServerUrl --start-maximized"
$shortcut.WorkingDirectory = Split-Path $edgeCandidates[0]
$shortcut.IconLocation = if (Test-Path -LiteralPath $iconeDestino) { "$iconeDestino,0" } else { "$($edgeCandidates[0]),0" }
$shortcut.Description = "Dashboard Fiscal do escritório"
$shortcut.Save()

Write-Host "Dashboard Fiscal instalado neste computador." -ForegroundColor Green
Write-Host "Atalho criado: $shortcutPath"
if (Test-Path -LiteralPath $iconeDestino) {
  Write-Host "O atalho usa a logo da empresa. Se o ícone antigo continuar na tela, pressione F5 na Área de Trabalho."
}
if (-not $NoLaunch) {
  Start-Process -FilePath $edgeCandidates[0] -ArgumentList "--app=$ServerUrl", "--start-maximized"
}
