param(
  [string]$UpdateZip,
  [switch]$NoPause
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$root = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot "..")).Path
$tempBase = [System.IO.Path]::GetFullPath([System.IO.Path]::GetTempPath())
$tempRoot = Join-Path $tempBase ("dashboard-fiscal-update-" + [guid]::NewGuid().ToString("N"))
$backupRoot = $null
$serverStopped = $false
$applicationChanged = $false
$exitCode = 0

function Copy-DirectoryContents {
  param([string]$Source, [string]$Destination)
  New-Item -ItemType Directory -Path $Destination -Force | Out-Null
  Get-ChildItem -LiteralPath $Source -Force | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination $Destination -Recurse -Force
  }
}

function Start-DashboardWithoutOpening {
  & (Join-Path $root "tools\iniciar-servidor.ps1") -NoOpen
}

try {
  if ([string]::IsNullOrWhiteSpace($UpdateZip)) {
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Title = "Selecione o pacote de atualização do Dashboard Fiscal"
    $dialog.Filter = "Pacote ZIP (*.zip)|*.zip"
    $dialog.Multiselect = $false
    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
      Write-Host "Atualização cancelada." -ForegroundColor Yellow
      exit 0
    }
    $UpdateZip = $dialog.FileName
  }

  $zipPath = [System.IO.Path]::GetFullPath($UpdateZip)
  if (-not (Test-Path -LiteralPath $zipPath -PathType Leaf) -or [System.IO.Path]::GetExtension($zipPath) -ne ".zip") {
    throw "Selecione um pacote ZIP válido."
  }

  New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null
  Expand-Archive -LiteralPath $zipPath -DestinationPath $tempRoot -Force
  $sourceRoot = if (Test-Path -LiteralPath (Join-Path $tempRoot "portable-office\server.js")) {
    Join-Path $tempRoot "portable-office"
  } elseif (Test-Path -LiteralPath (Join-Path $tempRoot "server.js")) {
    $tempRoot
  } else {
    $candidate = Get-ChildItem -LiteralPath $tempRoot -Directory -Recurse | Where-Object {
      Test-Path -LiteralPath (Join-Path $_.FullName "server.js")
    } | Select-Object -First 1
    if ($null -eq $candidate) { throw "O ZIP não contém um pacote válido do Dashboard Fiscal." }
    $candidate.FullName
  }

  foreach ($required in @("server.js", "VERSION.txt", "public\app.js", "tools\iniciar-servidor.ps1")) {
    if (-not (Test-Path -LiteralPath (Join-Path $sourceRoot $required))) {
      throw "Pacote incompleto: arquivo $required não encontrado."
    }
  }

  $newVersion = (Get-Content -LiteralPath (Join-Path $sourceRoot "VERSION.txt") -First 1 -Encoding UTF8).Trim()
  $currentVersion = if (Test-Path -LiteralPath (Join-Path $root "VERSION.txt")) {
    (Get-Content -LiteralPath (Join-Path $root "VERSION.txt") -First 1 -Encoding UTF8).Trim()
  } else { "versão não identificada" }
  Write-Host "Atualizando: $currentVersion" -ForegroundColor Cyan
  Write-Host "Novo pacote: $newVersion" -ForegroundColor Cyan

  & (Join-Path $root "tools\parar-servidor.ps1")
  $serverStopped = $true

  $dataRoot = Join-Path $root "data"
  $databaseBackupRoot = Join-Path $dataRoot "backups"
  New-Item -ItemType Directory -Path $databaseBackupRoot -Force | Out-Null
  if (Test-Path -LiteralPath (Join-Path $dataRoot "db.json")) {
    $databaseBackup = Join-Path $databaseBackupRoot ("dashboard-fiscal-" + (Get-Date -Format "yyyy-MM-dd-HH-mm-ss") + "-antes-atualizacao.json")
    Copy-Item -LiteralPath (Join-Path $dataRoot "db.json") -Destination $databaseBackup -Force
  }

  $backupRoot = Join-Path $dataRoot ("update-backups\" + (Get-Date -Format "yyyy-MM-dd-HH-mm-ss"))
  New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
  Get-ChildItem -LiteralPath $root -Force | Where-Object {
    $_.Name -notin @("data", ".tour-data", "config.json", "runtime")
  } | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination $backupRoot -Recurse -Force
  }

  $preserveRuntime = Test-Path -LiteralPath (Join-Path $root "runtime\node.exe")
  Get-ChildItem -LiteralPath $sourceRoot -Force | Where-Object {
    $_.Name -notin @("data", ".tour-data", "config.json") -and (-not $preserveRuntime -or $_.Name -ne "runtime")
  } | ForEach-Object {
    $destination = Join-Path $root $_.Name
    if ($_.PSIsContainer) {
      Copy-DirectoryContents -Source $_.FullName -Destination $destination
    } else {
      Copy-Item -LiteralPath $_.FullName -Destination $destination -Force
    }
  }
  $applicationChanged = $true

  Start-DashboardWithoutOpening
  $serverStopped = $false
  $config = Get-Content -LiteralPath (Join-Path $root "config.json") -Raw -Encoding UTF8 | ConvertFrom-Json
  $health = Invoke-RestMethod -Uri ("http://127.0.0.1:" + [int]$config.port + "/api/health") -TimeoutSec 5
  if (-not $health.ok) { throw "A verificação final do servidor falhou." }

  Write-Host "Atualização concluída com sucesso: $($health.version)." -ForegroundColor Green
  Write-Host "Dados e configurações foram preservados." -ForegroundColor Green
  Write-Host "Backup técnico: $backupRoot" -ForegroundColor DarkGray
} catch {
  $exitCode = 1
  Write-Host "Falha na atualização: $($_.Exception.Message)" -ForegroundColor Red
  if ($applicationChanged -and $backupRoot -and (Test-Path -LiteralPath $backupRoot)) {
    Write-Host "Restaurando a versão anterior..." -ForegroundColor Yellow
    try {
      & (Join-Path $root "tools\parar-servidor.ps1")
      Get-ChildItem -LiteralPath $backupRoot -Force | ForEach-Object {
        $destination = Join-Path $root $_.Name
        if ($_.PSIsContainer) {
          Copy-DirectoryContents -Source $_.FullName -Destination $destination
        } else {
          Copy-Item -LiteralPath $_.FullName -Destination $destination -Force
        }
      }
      Start-DashboardWithoutOpening
      $serverStopped = $false
      Write-Host "Versão anterior restaurada e reiniciada." -ForegroundColor Green
    } catch {
      Write-Host "A restauração automática também falhou: $($_.Exception.Message)" -ForegroundColor Red
      Write-Host "Use o backup técnico em: $backupRoot" -ForegroundColor Yellow
    }
  } elseif ($serverStopped) {
    try { Start-DashboardWithoutOpening; $serverStopped = $false } catch {}
  }
} finally {
  $tempFull = [System.IO.Path]::GetFullPath($tempRoot)
  if ($tempFull.StartsWith($tempBase, [System.StringComparison]::OrdinalIgnoreCase) -and (Test-Path -LiteralPath $tempFull)) {
    Remove-Item -LiteralPath $tempFull -Recurse -Force -ErrorAction SilentlyContinue
  }
}

if (-not $NoPause) { Read-Host "Pressione Enter para fechar" | Out-Null }
exit $exitCode
