"use strict";

// Cobre a folha "NOVAS ALTERAÇÕES": periodicidade, lote, etapas em cascata e correção da observação.

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs/promises");
const os = require("node:os");
const path = require("node:path");
const { createApplication } = require("../server");

async function startTestApp(dataDir) {
  const app = await createApplication({
    dataDir, host: "127.0.0.1", port: 0, sessionHours: 1,
    importBundledClients: false, importBundledTeam: false
  });
  const info = await app.listen();
  return { app, baseUrl: info.localUrl.replace("localhost", "127.0.0.1") };
}

async function request(baseUrl, route, options = {}, session = {}) {
  const headers = { Accept: "application/json", ...(options.headers || {}) };
  if (session.cookie) headers.Cookie = session.cookie;
  if (session.csrf && !["GET", "HEAD"].includes(options.method || "GET")) headers["X-CSRF-Token"] = session.csrf;
  let body = options.body;
  if (body && typeof body !== "string") {
    headers["Content-Type"] = "application/json";
    body = JSON.stringify(body);
  }
  const response = await fetch(`${baseUrl}${route}`, { ...options, headers, body });
  const setCookie = response.headers.get("set-cookie");
  if (setCookie) session.cookie = setCookie.split(";")[0];
  const contentType = response.headers.get("content-type") || "";
  const payload = contentType.includes("application/json") ? await response.json() : await response.text();
  if (payload?.csrf) session.csrf = payload.csrf;
  return { response, payload };
}

async function prepare(baseUrl) {
  const admin = {};
  await request(baseUrl, "/api/setup", {
    method: "POST", body: { officeName: "FG Consultoria", name: "Gerson", username: "admin", password: "Senha!Forte123" }
  }, admin);

  const contas = {};
  for (const [nome, username, sector] of [["Rebeca", "rebeca", "GESTAO"], ["Mayara", "mayara", "DP"], ["Wesley", "wesley", "FISCAL/CONTABIL"]]) {
    const criado = await request(baseUrl, "/api/users", { method: "POST", body: { name: nome, username, sector, password: "Inicial!Teste123" } }, admin);
    const sessao = {};
    await request(baseUrl, "/api/login", { method: "POST", body: { sector, username, password: "Inicial!Teste123" } }, sessao);
    await request(baseUrl, `/api/users/${criado.payload.item.id}/password`, { method: "PUT", body: { password: "Definitiva!Teste123" } }, sessao);
    contas[username] = { sessao, item: criado.payload.item };
  }

  const clientes = [];
  for (const [nome, cnpj] of [["Empresa Um Ltda", "11222333000181"], ["Empresa Dois Ltda", "11222333000262"], ["Empresa Tres Ltda", "11222333000343"]]) {
    const criado = await request(baseUrl, "/api/clients", {
      method: "POST", body: { name: nome, cnpj, taxRegime: "SIMPLES NACIONAL" }
    }, admin);
    clientes.push(criado.payload.item);
  }

  return { admin, contas, clientes };
}

test("periodicidade das obrigações: lista padrão, inclusão, uso e proteção ao excluir", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "df-recorrencia-"));
  const { app, baseUrl } = await startTestApp(dataDir);
  t.after(async () => { await app.close().catch(() => {}); await fs.rm(dataDir, { recursive: true, force: true }); });
  const { admin, contas, clientes } = await prepare(baseUrl);

  // Já nasce com as três periodicidades pedidas.
  let lista = await request(baseUrl, "/api/recurrences", {}, admin);
  assert.deepEqual(lista.payload.items, ["MENSAL", "ANUAL", "ESPORÁDICA"]);

  // Dá para incluir outras, como o documento pede.
  const incluida = await request(baseUrl, "/api/recurrences", { method: "POST", body: { name: "trimestral" } }, admin);
  assert.equal(incluida.response.status, 201);
  assert.ok(incluida.payload.items.includes("TRIMESTRAL"), "a nova periodicidade entra em maiúsculas");

  // A obrigação guarda a periodicidade escolhida.
  const criada = await request(baseUrl, "/api/obligations", {
    method: "POST",
    body: {
      clientIds: [clientes[0].id], type: "EFD REINF", period: "2026-10",
      dueDate: "2026-11-15", status: "PENDENTE", recurrence: "TRIMESTRAL"
    }
  }, admin);
  assert.equal(criada.response.status, 201);
  assert.equal(criada.payload.items[0].recurrence, "TRIMESTRAL");

  // Periodicidade não cadastrada é recusada.
  const invalida = await request(baseUrl, "/api/obligations", {
    method: "POST",
    body: { clientIds: [clientes[0].id], type: "DIRBI", period: "2026-10", status: "PENDENTE", recurrence: "QUINZENAL" }
  }, admin);
  assert.equal(invalida.response.status, 400);
  assert.match(invalida.payload.error, /não cadastrada/i);

  // Enquanto estiver em uso, não pode ser excluída.
  const emUso = await request(baseUrl, "/api/recurrences/TRIMESTRAL", { method: "DELETE" }, admin);
  assert.equal(emUso.response.status, 400);
  assert.match(emUso.payload.error, /obrigações usando/i);

  // Colaborador não mexe na lista.
  const negado = await request(baseUrl, "/api/recurrences", { method: "POST", body: { name: "SEMANAL" } }, contas.mayara.sessao);
  assert.equal(negado.response.status, 403);

  // Depois de liberar o uso, a exclusão funciona.
  await request(baseUrl, `/api/obligations/${criada.payload.items[0].id}`, { method: "PUT", body: { recurrence: "MENSAL" } }, admin);
  const excluida = await request(baseUrl, "/api/recurrences/TRIMESTRAL", { method: "DELETE" }, admin);
  assert.equal(excluida.response.status, 200);
  assert.ok(!excluida.payload.items.includes("TRIMESTRAL"));
});

test("obrigações em lote: alterar responsável de várias e excluir todas as selecionadas", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "df-lote-"));
  const { app, baseUrl } = await startTestApp(dataDir);
  t.after(async () => { await app.close().catch(() => {}); await fs.rm(dataDir, { recursive: true, force: true }); });
  const { admin, contas, clientes } = await prepare(baseUrl);

  const criadas = await request(baseUrl, "/api/obligations", {
    method: "POST",
    body: {
      clientIds: clientes.map(item => item.id), responsibleIds: [contas.mayara.item.id],
      type: "EFD CONTRIBUIÇÕES", period: "2026-10", dueDate: "2026-11-15", status: "PENDENTE"
    }
  }, admin);
  assert.equal(criadas.payload.count, 3);
  const ids = criadas.payload.items.map(item => item.id);

  // Troca o responsável das três de uma vez, junto com status e periodicidade.
  const alterado = await request(baseUrl, "/api/obligations/bulk", {
    method: "POST",
    body: { ids, responsibleId: contas.wesley.item.id, status: "EM ANDAMENTO", recurrence: "MENSAL" }
  }, admin);
  assert.equal(alterado.response.status, 200);
  assert.equal(alterado.payload.affected, 3);

  let lista = await request(baseUrl, "/api/obligations", {}, admin);
  for (const item of lista.payload.items) {
    assert.equal(item.responsibleId, contas.wesley.item.id);
    assert.equal(item.status, "EM ANDAMENTO");
    assert.equal(item.recurrence, "MENSAL");
  }

  // Sem nenhum campo, a operação é recusada em vez de passar em branco.
  const semCampos = await request(baseUrl, "/api/obligations/bulk", { method: "POST", body: { ids } }, admin);
  assert.equal(semCampos.response.status, 400);

  // Responsável inválido não passa.
  const invalido = await request(baseUrl, "/api/obligations/bulk", {
    method: "POST", body: { ids, responsibleId: "nao-existe" }
  }, admin);
  assert.equal(invalido.response.status, 400);

  // Colaborador não altera nem exclui em lote.
  const negado = await request(baseUrl, "/api/obligations/bulk", {
    method: "POST", body: { ids, status: "TRANSMITIDO" }
  }, contas.mayara.sessao);
  assert.equal(negado.response.status, 403);

  // Exclusão em lote das selecionadas.
  const excluidas = await request(baseUrl, "/api/obligations/bulk", { method: "POST", body: { ids, action: "EXCLUIR" } }, admin);
  assert.equal(excluidas.payload.affected, 3);
  lista = await request(baseUrl, "/api/obligations", {}, admin);
  assert.equal(lista.payload.items.length, 0);

  // A auditoria registra a operação em lote.
  const auditoria = await request(baseUrl, "/api/audit", {}, admin);
  assert.ok(auditoria.payload.items.some(item => item.action === "EXCLUIR_LOTE"));
  assert.ok(auditoria.payload.items.some(item => item.action === "ALTERAR_LOTE"));
});

test("etapas: clicar onde parou conclui as anteriores e reabrir desfaz as seguintes", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "df-etapas-cascata-"));
  const { app, baseUrl } = await startTestApp(dataDir);
  t.after(async () => { await app.close().catch(() => {}); await fs.rm(dataDir, { recursive: true, force: true }); });
  const { admin, contas, clientes } = await prepare(baseUrl);

  await request(baseUrl, "/api/obligation-steps", {
    method: "POST", body: { name: "EFD REINF", steps: "Coletar notas\nConferir retenções\nApurar\nTransmitir\nEnviar ao cliente" }
  }, admin);
  const criada = await request(baseUrl, "/api/obligations", {
    method: "POST",
    body: {
      clientIds: [clientes[0].id], responsibleIds: [contas.mayara.item.id],
      type: "EFD REINF", period: "2026-10", dueDate: "2026-11-15", status: "PENDENTE"
    }
  }, admin);
  const obrigacao = criada.payload.items[0];
  assert.equal(obrigacao.steps.length, 5);

  // A pessoa parou na terceira etapa: clica nela e as duas anteriores fecham junto.
  const terceira = await request(baseUrl, `/api/obligations/${obrigacao.id}/steps/${obrigacao.steps[2].id}`, {
    method: "POST", body: { done: true }
  }, contas.mayara.sessao);
  assert.equal(terceira.response.status, 200);
  const depois = terceira.payload.item.steps.map(step => step.done);
  assert.deepEqual(depois, [true, true, true, false, false]);
  for (const etapa of terceira.payload.item.steps.filter(step => step.done)) {
    assert.equal(etapa.userId, contas.mayara.item.id);
    assert.ok(etapa.doneAt, "cada etapa concluída guarda a hora");
  }

  // Reabrir a segunda desfaz as seguintes, para o progresso não ficar furado.
  const reaberta = await request(baseUrl, `/api/obligations/${obrigacao.id}/steps/${obrigacao.steps[1].id}`, {
    method: "POST", body: { done: false }
  }, contas.mayara.sessao);
  assert.deepEqual(reaberta.payload.item.steps.map(step => step.done), [true, false, false, false, false]);

  // Sem cascata, marca só aquela etapa.
  const isolada = await request(baseUrl, `/api/obligations/${obrigacao.id}/steps/${obrigacao.steps[3].id}`, {
    method: "POST", body: { done: true, cascade: false }
  }, contas.mayara.sessao);
  assert.deepEqual(isolada.payload.item.steps.map(step => step.done), [true, false, false, true, false]);
});

test("observação da atividade pode ser corrigida depois de concluída", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "df-observacao-"));
  const { app, baseUrl } = await startTestApp(dataDir);
  t.after(async () => { await app.close().catch(() => {}); await fs.rm(dataDir, { recursive: true, force: true }); });
  const { admin, contas, clientes } = await prepare(baseUrl);

  const criada = await request(baseUrl, "/api/activities", {
    method: "POST",
    body: { clientIds: [clientes[0].id], userIds: [contas.mayara.item.id], task: "Fechamento de folha", date: "2026-10-05" }
  }, admin);
  const atividade = criada.payload.items[0];

  // Antes de concluir, não há o que corrigir.
  const cedo = await request(baseUrl, `/api/activities/${atividade.id}/notes`, {
    method: "POST", body: { notes: "Tentativa antes da hora" }
  }, contas.mayara.sessao);
  assert.equal(cedo.response.status, 400);

  await request(baseUrl, `/api/activities/${atividade.id}/start`, { method: "POST", body: {} }, contas.mayara.sessao);
  const concluida = await request(baseUrl, `/api/activities/${atividade.id}/finish`, {
    method: "POST", body: { notes: "Observção com erro de digitção" }
  }, contas.mayara.sessao);
  assert.equal(concluida.payload.item.status, "CONCLUÍDO");
  const minutos = concluida.payload.item.totalMinutes;

  // Quem executou corrige o texto, e o tempo trabalhado não muda.
  const corrigida = await request(baseUrl, `/api/activities/${atividade.id}/notes`, {
    method: "POST", body: { notes: "Observação corrigida, folha fechada e conferida." }
  }, contas.mayara.sessao);
  assert.equal(corrigida.response.status, 200);
  assert.equal(corrigida.payload.item.notes, "Observação corrigida, folha fechada e conferida.");
  assert.equal(corrigida.payload.item.totalMinutes, minutos);
  assert.equal(corrigida.payload.item.status, "CONCLUÍDO");
  assert.ok(corrigida.payload.item.notesEditedAt);

  // O texto anterior fica guardado na auditoria.
  const auditoria = await request(baseUrl, "/api/audit", {}, admin);
  const registro = auditoria.payload.items.find(item => item.action === "CORRIGIR_OBSERVACAO");
  assert.ok(registro, "a correção precisa aparecer na auditoria");
  assert.match(registro.details, /erro de digit/i);

  // Outro colaborador não corrige observação alheia; a gestão corrige.
  const intruso = await request(baseUrl, `/api/activities/${atividade.id}/notes`, {
    method: "POST", body: { notes: "Texto de outra pessoa" }
  }, contas.wesley.sessao);
  assert.equal(intruso.response.status, 403);
  const pelaGestao = await request(baseUrl, `/api/activities/${atividade.id}/notes`, {
    method: "POST", body: { notes: "Ajuste final feito pela Gestão." }
  }, contas.rebeca.sessao);
  assert.equal(pelaGestao.response.status, 200);
});
