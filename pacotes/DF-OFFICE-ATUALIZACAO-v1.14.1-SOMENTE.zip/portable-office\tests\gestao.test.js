"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs/promises");
const os = require("node:os");
const path = require("node:path");
const { createApplication } = require("../server");

async function startTestApp(dataDir) {
  const app = await createApplication({
    dataDir, host: "127.0.0.1", port: 0, sessionHours: 1,
    importBundledClients: false, importBundledTeam: false
  });
  const info = await app.listen();
  return { app, baseUrl: info.localUrl.replace("localhost", "127.0.0.1") };
}

async function request(baseUrl, route, options = {}, session = {}) {
  const headers = { Accept: "application/json", ...(options.headers || {}) };
  if (session.cookie) headers.Cookie = session.cookie;
  if (session.csrf && !["GET", "HEAD"].includes(options.method || "GET")) headers["X-CSRF-Token"] = session.csrf;
  let body = options.body;
  if (body && typeof body !== "string") {
    headers["Content-Type"] = "application/json";
    body = JSON.stringify(body);
  }
  const response = await fetch(`${baseUrl}${route}`, { ...options, headers, body });
  const setCookie = response.headers.get("set-cookie");
  if (setCookie) session.cookie = setCookie.split(";")[0];
  const contentType = response.headers.get("content-type") || "";
  const payload = contentType.includes("application/json") ? await response.json()
    : contentType.includes("text/") ? await response.text()
    : Buffer.from(await response.arrayBuffer());
  if (payload?.csrf) session.csrf = payload.csrf;
  return { response, payload };
}

// Cria o ambiente base: admin, gestora, colaborador e um cliente.
async function prepare(baseUrl) {
  const admin = {};
  await request(baseUrl, "/api/setup", {
    method: "POST", body: { officeName: "FG Consultoria", name: "Gerson", username: "admin", password: "Senha!Forte123" }
  }, admin);

  const contas = {};
  for (const [nome, username, sector] of [["Rebeca", "rebeca", "GESTAO"], ["Mayara", "mayara", "DP"], ["Wesley", "wesley", "FISCAL/CONTABIL"]]) {
    const criado = await request(baseUrl, "/api/users", { method: "POST", body: { name: nome, username, sector, password: "Inicial!Teste123" } }, admin);
    const sessao = {};
    await request(baseUrl, "/api/login", { method: "POST", body: { sector, username, password: "Inicial!Teste123" } }, sessao);
    await request(baseUrl, `/api/users/${criado.payload.item.id}/password`, { method: "PUT", body: { password: "Definitiva!Teste123" } }, sessao);
    contas[username] = { sessao, item: criado.payload.item };
  }

  const cliente = await request(baseUrl, "/api/clients", {
    method: "POST", body: { name: "Empresa Teste Ltda", cnpj: "11222333000181", taxRegime: "SIMPLES NACIONAL" }
  }, admin);

  return { admin, contas, cliente: cliente.payload.item };
}

test("gestão não bate ponto e o login não registra entrada automática", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "df-ponto-gestao-"));
  const { app, baseUrl } = await startTestApp(dataDir);
  t.after(async () => { await app.close().catch(() => {}); await fs.rm(dataDir, { recursive: true, force: true }); });
  const { admin, contas } = await prepare(baseUrl);

  // O login da colaboradora não cria mais nenhuma marcação.
  const mayara = {};
  const login = await request(baseUrl, "/api/login", { method: "POST", body: { sector: "DP", username: "mayara", password: "Definitiva!Teste123" } }, mayara);
  assert.equal(login.response.status, 200);
  assert.equal(login.payload.autoPunch, undefined);
  let ponto = await request(baseUrl, "/api/time-clock", {}, mayara);
  assert.equal(ponto.payload.today.entries.length, 0);
  assert.equal(ponto.payload.today.nextAction, "ENTRADA");

  // A colaboradora registra normalmente.
  const batida = await request(baseUrl, "/api/time-clock/punch", { method: "POST", body: { type: "ENTRADA" } }, mayara);
  assert.equal(batida.response.status, 201);

  // A gestora e o administrador não registram ponto.
  const gestora = await request(baseUrl, "/api/time-clock/punch", { method: "POST", body: { type: "ENTRADA" } }, contas.rebeca.sessao);
  assert.equal(gestora.response.status, 403);
  assert.match(gestora.payload.error, /não registram ponto/i);
  const administrador = await request(baseUrl, "/api/time-clock/punch", { method: "POST", body: { type: "ENTRADA" } }, admin);
  assert.equal(administrador.response.status, 403);

  // A gestora continua enxergando e corrigindo o ponto da equipe.
  ponto = await request(baseUrl, "/api/time-clock", {}, contas.rebeca.sessao);
  assert.equal(ponto.response.status, 200);
  const ajuste = await request(baseUrl, "/api/time-clock/manual", {
    method: "POST",
    body: { userId: contas.mayara.item.id, date: ponto.payload.today.date, type: "SAIDA_ALMOCO", time: "12:00", reason: "Esqueceu de marcar" }
  }, contas.rebeca.sessao);
  assert.ok(ajuste.response.ok, "a gestora corrige a marcacao da equipe");
});

test("atividades podem ser atribuídas a gestores", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "df-atividade-gestor-"));
  const { app, baseUrl } = await startTestApp(dataDir);
  t.after(async () => { await app.close().catch(() => {}); await fs.rm(dataDir, { recursive: true, force: true }); });
  const { admin, contas, cliente } = await prepare(baseUrl);

  const paraGestora = await request(baseUrl, "/api/activities", {
    method: "POST",
    body: { clientIds: [cliente.id], userIds: [contas.rebeca.item.id], task: "Revisar distribuição das obrigações", date: "2026-09-10" }
  }, admin);
  assert.equal(paraGestora.response.status, 201);
  assert.equal(paraGestora.payload.items[0].userId, contas.rebeca.item.id);

  // A gestora inicia e conclui a própria atividade.
  const atividadeId = paraGestora.payload.items[0].id;
  const iniciada = await request(baseUrl, `/api/activities/${atividadeId}/start`, { method: "POST", body: {} }, contas.rebeca.sessao);
  assert.equal(iniciada.response.status, 200);

  // Atribuir a um administrador continua bloqueado.
  const usuarios = await request(baseUrl, "/api/users", {}, admin);
  const administrador = usuarios.payload.items.find(item => item.username === "admin");
  const paraAdmin = await request(baseUrl, "/api/activities", {
    method: "POST",
    body: { clientIds: [cliente.id], userIds: [administrador.id], task: "Teste inválido", date: "2026-09-10" }
  }, admin);
  assert.equal(paraAdmin.response.status, 400);
});

test("gestão tem a mesma visão e os mesmos direitos da administração", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "df-gestao-usuarios-"));
  const { app, baseUrl } = await startTestApp(dataDir);
  t.after(async () => { await app.close().catch(() => {}); await fs.rm(dataDir, { recursive: true, force: true }); });
  const { admin, contas } = await prepare(baseUrl);
  const rebeca = contas.rebeca.sessao;

  // A gestora enxerga a equipe e cria usuários de qualquer setor, inclusive administrativo.
  const lista = await request(baseUrl, "/api/users", {}, rebeca);
  assert.equal(lista.response.status, 200);
  const colaborador = await request(baseUrl, "/api/users", {
    method: "POST", body: { name: "Eduarda", username: "eduarda", sector: "FISCAL/CONTABIL", password: "Inicial!Teste123" }
  }, rebeca);
  assert.equal(colaborador.response.status, 201);
  const novoAdmin = await request(baseUrl, "/api/users", {
    method: "POST", body: { name: "Outro Admin", username: "outro.admin", sector: "ADMIN", password: "Inicial!Teste123" }
  }, rebeca);
  assert.equal(novoAdmin.response.status, 201);
  assert.equal(novoAdmin.payload.item.role, "ADMIN");

  // Redefine senha de colaborador e também de conta administrativa.
  const redefinida = await request(baseUrl, `/api/users/${contas.wesley.item.id}/password`, {
    method: "PUT", body: { password: "Redefinida!123" }
  }, rebeca);
  assert.equal(redefinida.response.status, 200);
  const entrou = await request(baseUrl, "/api/login", { method: "POST", body: { sector: "FISCAL/CONTABIL", username: "wesley", password: "Redefinida!123" } });
  assert.equal(entrou.response.status, 200);

  const usuarios = await request(baseUrl, "/api/users", {}, admin);
  const administrador = usuarios.payload.items.find(item => item.username === "admin");
  const senhaDoAdmin = await request(baseUrl, `/api/users/${administrador.id}/password`, {
    method: "PUT", body: { password: "Redefinida!Admin123" }
  }, rebeca);
  assert.equal(senhaDoAdmin.response.status, 200);
  const desativarAdmin = await request(baseUrl, `/api/users/${administrador.id}`, { method: "PUT", body: { active: false } }, rebeca);
  assert.equal(desativarAdmin.response.status, 200);
  await request(baseUrl, `/api/users/${administrador.id}`, { method: "PUT", body: { active: true } }, rebeca);

  // E libera acesso bloqueado de qualquer conta.
  const liberar = await request(baseUrl, `/api/users/${administrador.id}/unlock`, { method: "POST", body: {} }, rebeca);
  assert.equal(liberar.response.status, 200);

  // As telas antes exclusivas do administrador respondem para a gestora.
  for (const rota of [
    "/api/administrative?period=2026-09",
    "/api/budgets?period=2026-09",
    "/api/audit",
    "/api/branding"
  ]) {
    const resposta = await request(baseUrl, rota, {}, rebeca);
    assert.equal(resposta.response.status, 200, `a gestora deveria acessar ${rota}`);
  }

  // Inclusive as que alteram configuração do escritório.
  const identidade = await request(baseUrl, "/api/branding", {
    method: "POST", body: { companyName: "FG Consultoria", primaryColor: "#123456" }
  }, rebeca);
  assert.equal(identidade.response.status, 200);
  const despesa = await request(baseUrl, "/api/administrative/entries", {
    method: "POST", body: { period: "2026-09", amount: 1200, category: "SISTEMAS", correlation: "Assinatura mensal" }
  }, rebeca);
  assert.equal(despesa.response.status, 201);
  const integracao = await request(baseUrl, "/api/whatsapp-integration", { method: "POST", body: { provider: "PARCEIRO" } }, rebeca);
  assert.equal(integracao.response.status, 200);

  // Colaborador comum continua sem nada disso.
  const negadoUsuarios = await request(baseUrl, "/api/users", {}, contas.mayara.sessao);
  assert.equal(negadoUsuarios.response.status, 403);
  const negadoFinanceiro = await request(baseUrl, "/api/budgets?period=2026-09", {}, contas.mayara.sessao);
  assert.equal(negadoFinanceiro.response.status, 403);
  const negadaIdentidade = await request(baseUrl, "/api/branding", { method: "POST", body: { primaryColor: "#000000" } }, contas.mayara.sessao);
  assert.equal(negadaIdentidade.response.status, 403);
});

test("passo a passo das obrigações: modelo, herança e marcação pelo responsável", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "df-etapas-"));
  const { app, baseUrl } = await startTestApp(dataDir);
  t.after(async () => { await app.close().catch(() => {}); await fs.rm(dataDir, { recursive: true, force: true }); });
  const { admin, contas, cliente } = await prepare(baseUrl);

  const modelo = await request(baseUrl, "/api/obligation-steps", {
    method: "POST", body: { name: "EFD CONTRIBUIÇÕES", steps: "Conferir documentos\nApurar\nTransmitir\nEnviar ao cliente" }
  }, contas.rebeca.sessao);
  assert.equal(modelo.response.status, 200);
  assert.equal(modelo.payload.item.steps.length, 4);

  const obrigacao = await request(baseUrl, "/api/obligations", {
    method: "POST",
    body: {
      clientIds: [cliente.id], responsibleIds: [contas.mayara.item.id], type: "EFD CONTRIBUIÇÕES",
      period: "2026-09", dueDate: "2026-10-15", status: "PENDENTE"
    }
  }, admin);
  assert.equal(obrigacao.response.status, 201);
  const criada = obrigacao.payload.items[0];
  assert.equal(criada.steps.length, 4, "a obrigação nasce com as etapas do modelo");
  assert.equal(criada.steps[0].done, false);

  // A responsável marca a primeira etapa.
  const marcada = await request(baseUrl, `/api/obligations/${criada.id}/steps/${criada.steps[0].id}`, {
    method: "POST", body: { done: true }
  }, contas.mayara.sessao);
  assert.equal(marcada.response.status, 200);
  assert.equal(marcada.payload.item.steps[0].done, true);
  assert.equal(marcada.payload.item.steps[0].userId, contas.mayara.item.id);
  assert.ok(marcada.payload.item.steps[0].doneAt);

  // Outro colaborador não marca etapa de obrigação alheia.
  const intruso = await request(baseUrl, `/api/obligations/${criada.id}/steps/${criada.steps[1].id}`, {
    method: "POST", body: { done: true }
  }, contas.wesley.sessao);
  assert.equal(intruso.response.status, 403);

  // A etapa pode ser reaberta.
  const reaberta = await request(baseUrl, `/api/obligations/${criada.id}/steps/${criada.steps[0].id}`, {
    method: "POST", body: { done: false }
  }, contas.rebeca.sessao);
  assert.equal(reaberta.payload.item.steps[0].done, false);

  // Obrigação de tipo sem modelo nasce sem etapas.
  const semModelo = await request(baseUrl, "/api/obligations", {
    method: "POST",
    body: { clientIds: [cliente.id], type: "DIRBI", period: "2026-09", dueDate: "2026-10-20", status: "PENDENTE" }
  }, admin);
  assert.equal(semModelo.payload.items[0].steps.length, 0);
});

test("painel mensal de obrigações resume situação, atraso e responsáveis", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "df-painel-"));
  const { app, baseUrl } = await startTestApp(dataDir);
  t.after(async () => { await app.close().catch(() => {}); await fs.rm(dataDir, { recursive: true, force: true }); });
  const { admin, contas, cliente } = await prepare(baseUrl);

  const base = { clientIds: [cliente.id], period: "2026-09", responsibleIds: [contas.mayara.item.id] };
  await request(baseUrl, "/api/obligations", { method: "POST", body: { ...base, type: "EFD REINF", dueDate: "2020-01-10", status: "PENDENTE" } }, admin);
  await request(baseUrl, "/api/obligations", { method: "POST", body: { ...base, type: "DIRBI", dueDate: "2090-01-10", status: "PENDENTE" } }, admin);
  await request(baseUrl, "/api/obligations", { method: "POST", body: { ...base, type: "MIT", dueDate: "2090-01-10", status: "TRANSMITIDO" } }, admin);
  await request(baseUrl, "/api/obligations", { method: "POST", body: { clientIds: [cliente.id], period: "2026-08", type: "DTE", dueDate: "2090-01-10", status: "PENDENTE" } }, admin);

  const painel = await request(baseUrl, "/api/obligations-panel?period=2026-09", {}, contas.rebeca.sessao);
  assert.equal(painel.response.status, 200);
  assert.equal(painel.payload.summary.total, 3, "só entram as obrigações da competência pedida");
  assert.equal(painel.payload.summary.concluded, 1);
  assert.equal(painel.payload.summary.pending, 2);
  assert.equal(painel.payload.summary.late, 1, "a de prazo vencido e não concluída conta como atrasada");
  assert.equal(painel.payload.summary.percent, 33.3);

  const porResponsavel = painel.payload.byResponsible.find(row => row.label === "Mayara");
  assert.equal(porResponsavel.total, 3);
  assert.equal(porResponsavel.concluded, 1);
  assert.equal(porResponsavel.late, 1);
  assert.ok(painel.payload.byType.some(row => row.label === "EFD REINF"));

  // Colaborador não acessa o painel gerencial.
  const negado = await request(baseUrl, "/api/obligations-panel?period=2026-09", {}, contas.mayara.sessao);
  assert.equal(negado.response.status, 403);
});

test("exportação de movimentações filtra por usuário, data e tipo", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "df-exportacoes-"));
  const { app, baseUrl } = await startTestApp(dataDir);
  t.after(async () => { await app.close().catch(() => {}); await fs.rm(dataDir, { recursive: true, force: true }); });
  const { admin, contas, cliente } = await prepare(baseUrl);

  await request(baseUrl, "/api/activities", {
    method: "POST", body: { clientIds: [cliente.id], userIds: [contas.mayara.item.id], task: "Folha de agosto", date: "2026-08-10" }
  }, admin);
  await request(baseUrl, "/api/activities", {
    method: "POST", body: { clientIds: [cliente.id], userIds: [contas.wesley.item.id], task: "Apuração de setembro", date: "2026-09-10" }
  }, admin);

  let resultado = await request(baseUrl, "/api/movimentacoes?type=atividades", {}, admin);
  assert.equal(resultado.payload.total, 2);
  assert.ok(resultado.payload.columns.some(column => column.label === "Responsável"));

  resultado = await request(baseUrl, `/api/movimentacoes?type=atividades&userId=${contas.mayara.item.id}`, {}, admin);
  assert.equal(resultado.payload.total, 1);
  assert.equal(resultado.payload.items[0].atividade, "Folha de agosto");

  resultado = await request(baseUrl, "/api/movimentacoes?type=atividades&from=2026-09-01&to=2026-09-30", {}, admin);
  assert.equal(resultado.payload.total, 1);
  assert.equal(resultado.payload.items[0].atividade, "Apuração de setembro");

  // O CSV sai com cabeçalho traduzido e separador do Excel brasileiro.
  const csv = await request(baseUrl, "/api/export/movimentacoes?type=atividades", {}, admin);
  assert.equal(csv.response.headers.get("content-type"), "text/csv; charset=utf-8");
  assert.ok(String(csv.payload).includes("Responsável;"));
  assert.ok(String(csv.payload).includes("Folha de agosto"));

  // Tipos inválidos são recusados e colaborador não exporta.
  const invalido = await request(baseUrl, "/api/movimentacoes?type=qualquer", {}, admin);
  assert.equal(invalido.response.status, 400);
  const negado = await request(baseUrl, "/api/movimentacoes?type=atividades", {}, contas.mayara.sessao);
  assert.equal(negado.response.status, 403);

  // Os demais tipos respondem sem erro.
  for (const tipo of ["obrigacoes", "ponto", "atendimentos", "auditoria"]) {
    const saida = await request(baseUrl, `/api/movimentacoes?type=${tipo}`, {}, admin);
    assert.equal(saida.response.status, 200, `tipo ${tipo} deveria responder`);
  }
});

test("sistema ja nasce com a marca da FG Consultoria", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "df-marca-padrao-"));
  const { app, baseUrl } = await startTestApp(dataDir);
  t.after(async () => { await app.close().catch(() => {}); await fs.rm(dataDir, { recursive: true, force: true }); });

  // Sem nenhuma configuracao e sem login, a identidade padrao ja responde.
  const identidade = await request(baseUrl, "/api/branding");
  assert.equal(identidade.response.status, 200);
  assert.equal(identidade.payload.companyName, "FG Consultoria");
  assert.equal(identidade.payload.primaryColor, "#2d2e6e");
  assert.equal(identidade.payload.usingDefaultLogo, true);

  const logo = await request(baseUrl, "/api/branding/logo");
  assert.equal(logo.response.status, 200);
  assert.equal(logo.response.headers.get("content-type"), "image/png");
  assert.ok(logo.payload.length > 5000, "a logo padrao deve ter conteudo");
});

test("identidade visual guarda cor e logo e fica disponível antes do login", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "df-identidade-"));
  const { app, baseUrl } = await startTestApp(dataDir);
  t.after(async () => { await app.close().catch(() => {}); await fs.rm(dataDir, { recursive: true, force: true }); });
  const { admin, contas } = await prepare(baseUrl);

  // Um PNG mínimo de 1x1 pixel.
  const png = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==";
  const salvo = await request(baseUrl, "/api/branding", {
    method: "POST",
    body: { companyName: "FG Consultoria", primaryColor: "#1b4f8a", logo: { type: "image/png", data: `data:image/png;base64,${png}` } }
  }, admin);
  assert.equal(salvo.response.status, 200);
  assert.equal(salvo.payload.primaryColor, "#1b4f8a");
  assert.ok(salvo.payload.logoUrl.startsWith("/api/branding/logo"));

  // A tela de login lê a identidade sem estar autenticada.
  const publico = await request(baseUrl, "/api/branding");
  assert.equal(publico.response.status, 200);
  assert.equal(publico.payload.companyName, "FG Consultoria");
  assert.equal(publico.payload.primaryColor, "#1b4f8a");

  const imagem = await request(baseUrl, "/api/branding/logo");
  assert.equal(imagem.response.status, 200);
  assert.equal(imagem.response.headers.get("content-type"), "image/png");

  // Cor inválida é recusada; a Gestão altera, o colaborador não.
  const corRuim = await request(baseUrl, "/api/branding", { method: "POST", body: { primaryColor: "azul" } }, admin);
  assert.equal(corRuim.response.status, 400);
  const pelaGestao = await request(baseUrl, "/api/branding", { method: "POST", body: { companyName: "FG Consultoria", primaryColor: "#1b4f8a" } }, contas.rebeca.sessao);
  assert.equal(pelaGestao.response.status, 200);
  const negado = await request(baseUrl, "/api/branding", { method: "POST", body: { primaryColor: "#000000" } }, contas.mayara.sessao);
  assert.equal(negado.response.status, 403);

  // Voltar a logo padrao mantem o resto da identidade e devolve a marca da FG.
  const removida = await request(baseUrl, "/api/branding", { method: "POST", body: { removeLogo: true, companyName: "FG Consultoria", primaryColor: "#1b4f8a" } }, admin);
  assert.equal(removida.payload.usingDefaultLogo, true);
  assert.ok(removida.payload.logoUrl.startsWith("/api/branding/logo"));
  assert.equal(removida.payload.primaryColor, "#1b4f8a");
  const padrao = await request(baseUrl, "/api/branding/logo");
  assert.equal(padrao.response.status, 200, "a logo padrao da FG continua disponivel");
  assert.equal(padrao.response.headers.get("content-type"), "image/png");
});

test("ícones da marca são entregues pelo servidor", async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "df-icones-"));
  const { app, baseUrl } = await startTestApp(dataDir);
  t.after(async () => { await app.close().catch(() => {}); await fs.rm(dataDir, { recursive: true, force: true }); });

  // A aba do navegador e o aplicativo instalado dependem destes arquivos.
  for (const caminho of ["/icons/icon-192.png", "/icons/icon-512.png"]) {
    const resposta = await request(baseUrl, caminho);
    assert.equal(resposta.response.status, 200, `${caminho} deveria ser servido`);
    assert.equal(resposta.response.headers.get("content-type"), "image/png");
    assert.ok(resposta.payload.length > 3000, `${caminho} deveria ter conteúdo`);
  }

  const manifesto = await request(baseUrl, "/manifest.webmanifest");
  assert.equal(manifesto.response.status, 200);
  const conteudo = JSON.parse(Buffer.isBuffer(manifesto.payload) ? manifesto.payload.toString("utf8") : String(manifesto.payload));
  assert.equal(conteudo.name, "FG Consultoria");
  assert.equal(conteudo.theme_color, "#2d2e6e");
  assert.ok(conteudo.icons.every(icone => icone.src.endsWith(".png")));
});
