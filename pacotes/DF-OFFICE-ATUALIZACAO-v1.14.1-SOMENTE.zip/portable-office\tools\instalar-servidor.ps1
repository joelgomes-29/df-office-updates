param(
  [string]$ShortcutDirectory,
  [switch]$NoPause
)

. (Join-Path $PSScriptRoot "common.ps1")

$root = Get-DashboardRoot
[void](Get-DashboardConfig -Root $root)
[void](Get-DashboardNode -Root $root)

if ([string]::IsNullOrWhiteSpace($ShortcutDirectory)) {
  $ShortcutDirectory = [Environment]::GetFolderPath("Desktop")
}
New-Item -ItemType Directory -Path $ShortcutDirectory -Force | Out-Null
$shell = New-Object -ComObject WScript.Shell
$icone = Join-Path $root "seed\branding\logo-fg.ico"
$temIcone = Test-Path -LiteralPath $icone

$startShortcut = $shell.CreateShortcut((Join-Path $ShortcutDirectory "Dashboard Fiscal - Iniciar.lnk"))
$startShortcut.TargetPath = Join-Path $root "INICIAR_SERVIDOR.cmd"
$startShortcut.WorkingDirectory = $root
$startShortcut.Description = "Inicia o servidor do Dashboard Fiscal Office"
if ($temIcone) { $startShortcut.IconLocation = "$icone,0" }
$startShortcut.Save()

$stopShortcut = $shell.CreateShortcut((Join-Path $ShortcutDirectory "Dashboard Fiscal - Parar.lnk"))
$stopShortcut.TargetPath = Join-Path $root "PARAR_SERVIDOR.cmd"
$stopShortcut.WorkingDirectory = $root
$stopShortcut.Description = "Encerra o servidor do Dashboard Fiscal Office"
if ($temIcone) { $stopShortcut.IconLocation = "$icone,0" }
$stopShortcut.Save()

$updateShortcut = $shell.CreateShortcut((Join-Path $ShortcutDirectory "Dashboard Fiscal - Atualizar.lnk"))
$updateShortcut.TargetPath = Join-Path $root "ATUALIZAR_SERVIDOR.cmd"
$updateShortcut.WorkingDirectory = $root
$updateShortcut.Description = "Atualiza o Dashboard Fiscal preservando dados e configurações"
if ($temIcone) { $updateShortcut.IconLocation = "$icone,0" }
$updateShortcut.Save()

Write-Host "Atalhos de iniciar, parar e atualizar instalados na Área de Trabalho." -ForegroundColor Green
Write-Host "Agora execute CONFIGURAR_FIREWALL.cmd como administrador e depois INICIAR_SERVIDOR.cmd."
if (-not $NoPause) { Read-Host "Pressione Enter para concluir" | Out-Null }
