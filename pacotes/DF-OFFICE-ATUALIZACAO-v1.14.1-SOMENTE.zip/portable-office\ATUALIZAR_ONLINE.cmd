@echo off
setlocal
cd /d "%~dp0"

net session >nul 2>&1
if errorlevel 1 (
  echo.
  echo  Este programa precisa ser executado como administrador.
  echo  Feche esta janela, clique com o botao direito em ATUALIZAR_ONLINE.cmd
  echo  e escolha "Executar como administrador".
  echo.
  pause
  exit /b 1
)

echo.
echo  Procurando atualizacao do DF Office...
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\atualizar-online.ps1" %*
endlocal
